;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicerror.asm,v 1.21 2015/09/22 09:39:01 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   Basic error codes and error handling 		**
;;; **********************************************************************

	.include "basicmacros.i"
	.include "basicerror.i"
	.include "basicio.i"
	.include "basicstatements.i"
	.include "basicexecution.i"
	.include "basicstack.i"
	.include "basicmain.i"
	.include "basicmemory.i"
	.include "basicparser.i"
	.include "constants.i"
	.include "syntax.i"
	.include "mathpack.i"
	.include "editor.i"
	.include "irq.i"
	
	.segment "BasMain"
	
;;; *** CallError
;;; *** Retrieves the error number from the stack and stores
;;; *** it in the TrappedErrorNumber
	.global CallError
.proc	CallError
	pla
	sta PrintPtr
	pla
	sta PrintPtr+1
	ldy #1
	lda (PrintPtr),y
	sta TrappedErrorNumber
	;; runs into the following
.endproc
;;; *** Error	(Atari Basic ERROR)
;;; *** Generate the error code in CurrentErrorNumber
	.global Error
.proc	Error
	ldy LoadFlag
	bne stopprogramload	;if in the middle of a load, do not execute trap
	lda EnterIOCB
	pha			;keep the current IOCB we read from
	jsr Stop		;stop program execution (resets the IOCB)
	;; here check whether the error was caused in the direct mode. This is
	;; the case if the input channel is #0 (and not redirected by ENTER) and
	;; the line pointer is set to line 32768.
	pla			;if non-zero, may trap. We are ENTERing
	bne maytrap
	jsr TestIfDirect	;are we currently executing in direct mode?
	bmi stopprogram		;ok, then do not trap into "surprise mode".
maytrap:	
	ldy TrapLine+1		;is TRAP active?
	bmi stopprogram
	;; here not: Execute the TRAP command
	ldx #$80
	stx TrapLine+1		;turn off trapping
	;; target line number is now in A=hi,Y=lo
	lda TrapLine
	jmp GotoLineYA		;execute the goto command, also restores the stack
	;; ok, no trapping. Print the error and stop the program
stopprogramload:
stopprogram:
	sty BreakFlag		;reset the break flag so we can print (otherwise the PRINT itself BREAKS).
	jsr PrintCR		;print a line feed
	lda #ErrorToken		;get the token for ERROR
	jsr PrintStatement
	ldx #0
	lda TrappedErrorNumber
	jsr PrintNumber
	;; runs into the following
.endproc
;;; *** AbortAtLineMessage (Atari Basic ERRM2)
;;; *** Prints the line number if in program mode,
;;; *** aborts program execution and returns to the
;;; *** syntax parser without printing READY
;;; *** This is also used by STOP
	.global AbortAtLineMessage
.proc	AbortAtLineMessage
	lda LoadFlag
	bne cold	        ;do not attempt to print a line number if loading
	jsr TestIfDirect	;are we currently executing in direct mode?
	bmi done		;ok, nothing else
	lda #>AtLineMsg
	ldy #<AtLineMsg
	jsr PrintStringAY
	jsr PrintLineNumber
	;; since line offsets may change due to editing the
	;; source, invalidate absolute addresses
	inc GenerationCounter
done:
	jsr PrintCR		;another line feed
	jmp Syntax		;restart syntax parser, awaiting user input
cold:
	jmp BasicColdStart	;rather, erase the program if that happens during loading.
.endproc


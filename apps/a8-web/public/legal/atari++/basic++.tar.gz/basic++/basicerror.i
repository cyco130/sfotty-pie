;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicerror.i,v 1.6 2015/09/15 14:00:28 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Basic error codes and error handling 		**
;;; **********************************************************************

;;; zpage equates
TrappedErrorNumber	=	$c3	;keeps the last error for basic programs to peek for (ERRSAV in Atari Basic)

	
.macro	Error err
	jsr CallError
	.byte err
.endmacro

	;; basic error values
	
BasicOutOfMemory	=	2	;no memory left
ValueError		=	3	;value is out of range
VariableTableOverflow	=	4	;no room in the variable table
StringLengthError	=	5	;string index is out of range
ReadOutOfData		=	6	;no DATA for read
LineNumberOverflow	=	7	;line number is out of range (must be <32768)
InputTypeMismatch	=	8	;input type does not match expected type
DIMMismatch		=	9	;DIM missing or out of range
ArgStackOverflow	=	10	;expression too complex
NumericOverflow		=	11	;floating point overflow
LineNotFound		=	12	;the inidicated line was not found
ForNotFound		=	13	;did not find a matching FOR statement for a NEXT statement
LineTooLong		=	14	;a line is too long, cannot parse
TargetLineDeleted	=	15	;the target of a RETURN or NEXT statement has been deleted
GosubNotFound		=	16	;the GOSUB of a RETURN is not found.
InvalidToken		=	17	;executing an ERROR token
StringNotNumeric	=	18	;VAL cannot convert a string
ProgramTooLarge		=	19	;cannot load the program because it is too big
IOCBOverflow		=	20	;IOCB is out of range, must be 1..6
InvalidSaveFormat	=	21	;no Atari basic LOAD file

;;; **** Functions defined here
	
	.global CallError
	.global	Error
	.global AbortAtLineMessage

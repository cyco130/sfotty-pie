;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicexecution.asm,v 1.21 2017/02/11 21:16:58 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   Support for executing statements               **
;;; **********************************************************************

	.include "basicmacros.i"
	.include "basicexecution.i"
	.include "basicmath.i"
	.include "basicstatements.i"
	.include "basicmemory.i"
	.include "basicerror.i"
	.include "basicstack.i"
	.include "basicio.i"
	.include "basicmain.i"
	.include "statementvector.i"
	.include "syntax.i"
	.include "irq.i"
	.include "reset.i"
	
	.segment "BasMain"

;;; *** FindTargetLineYA
;;; *** Search the line whose line number is in Y=hi, A=lo
	.global FindTargetLineYA
.proc	FindTargetLineYA
	sta TargetLineNumber
	sty TargetLineNumber+1
	;; runs into the following
.endproc
;;; *** FindTargetLine (GETSTMT in Atari Basic)
;;; *** Search the tokenized source for the given line number in TargetLineNumer, return with
;;; *** C set in case the line could not be found. In case the line is not found
;;; *** the CurrentLinePtr points to the place where it should go.
	.global FindTargetLine
.proc	FindTargetLine
	lda CurrentLinePtr
	sta JumpOriginLinePtr
	lda CurrentLinePtr+1
	sta JumpOriginLinePtr+1	;keep a backup
	;; check whether the line we seek for is below the current line.
	;; if so, start from the current line and not the first line
	ldy #0
	lda TargetLineNumber
	cmp (CurrentLinePtr),y
	iny
	lda TargetLineNumber+1
	sbc (CurrentLinePtr),y
	bcs start		;if larger or equal than the current line, start from the current line
	;; start from the top of the table
	lda StatementPtr
	sta CurrentLinePtr
	lda StatementPtr+1
	sta CurrentLinePtr+1
	bne start		;start the scan
;; here: too low, loop again. This is inlined
;; because it is really very speed critical.
loop:
	ldy #2	      		;sits at offset #2
	lda (CurrentLinePtr),y
	dey
	adc CurrentLinePtr
	sta CurrentLinePtr
	bcc start
	inc CurrentLinePtr+1
start:	
	lda (CurrentLinePtr),y	;does the high-byte match?
	cmp TargetLineNumber+1	;does it match?
	bcc loop
	bne exit		;not found
	dey
	lda (CurrentLinePtr),y
	cmp TargetLineNumber	;does it match?
	bcc loop
	bne exit
	clc			;found!
exit:
	rts
.endproc
;;; *** GetLineLength (GETLL in Atari Basic)
;;; *** Extract the line length from the tokenized line
	.global GetLineLength
.proc	GetLineLength
	ldy #2	      ;sits at offset #2
	Skip2
	;; runs into the following
.endproc
;;; *** TestIfDirect (Atari Basic TENDST)
;;; *** Test whether we are currently executing a DIRECT line, namely
;;; *** line number 32768 or above
;;; *** Returns the N flag set if so
	.global TestIfDirect
.proc	TestIfDirect
	ldy #1
	lda (CurrentLinePtr),y
	rts
.endproc
;;; *** GetNextLine (GNXTL in Atari Basic)
;;; *** Advance the current line pointer by the size of the current line
;;; *** given in the A register
	.global GetNextLine
.proc	GetNextLine
	clc
	adc CurrentLinePtr
	sta CurrentLinePtr
	bcc exit
	inc CurrentLinePtr+1
exit:	
	rts
.endproc
;;; *** TestStatementEnd (TSTEND in Atari Basic)
;;; *** Test whether the end of the statement has been reached.
;;; *** Returns C=1 if the end of the statement has been reached
;;; *** MUST NOT CHANGE A or Y.
	.global TestStatementEnd
.proc	TestStatementEnd
	ldx StatementOffset
	inx
	cpx StatementEnd
	rts
.endproc
;;; *** Stop (Atari Basic STOP)
;;; *** This is part of the logic to stop program execution
;;; *** It keeps the line where we stopped to allow a continue
;;; *** from that line.
	.global Stop
.proc	Stop
	jsr TestIfDirect
	bmi directmode	     ; on direct mode, there is nothing to be stopped
	sta StopLine+1
	dey
	lda (CurrentLinePtr),y	;and the low-byte of the line number
	sta StopLine
directmode:
	jmp ResetEnterListIOCB	; reset stdin,stdout
.endproc
;;; *** ExecuteProgram (EXECNL in AtariBasic)
;;; *** This function executes the current line
	.global ExecuteProgram
.proc	ExecuteProgram
nextline:	
	jsr SetupLineOffsets
nextstatement:	
	jsr TestForBreak	;has the break key been pressed?
	bne breakabort
	ldy StatementEnd 	;current statement
	cpy LineLength		;end of line reached?
	bcs endofline
	lda (CurrentLinePtr),y	;get the next statement offset
	sta StatementEnd
	iny
	lda (CurrentLinePtr),y	;get the token for the statement
	iny
	sty StatementOffset 	;arguments of the statement start here
	jsr ExecuteStatement	;execute the statement
	clc
	bcc nextstatement
endofline:
	jsr TestIfDirect	;running off the end of the direct line?
	bmi indirect		;reached the direct line, then abort
	lda LineLength
	jsr GetNextLine		;advance to the next line
	jsr TestIfDirect	;test if there is an END statement
	bpl nextline		;execute the next line
	;; ok, reached the end of the program. Execute END
	jmp ExecuteEnd
breakabort:
	jmp ExecuteStop		;execute a STOP statement
indirect:			;reached end of the direct code
	jmp ExpectInput
.endproc
;;; *** ExecuteStatement (STGO in AtariBasic)
;;; *** Execute a single statement of a line
.proc	ExecuteStatement
	cmp #DirToken		;this is just behind the error token
	bne regular
	lda #ErrorToken+1
regular:	
	tax
	lda StatementVectorHi,x	;high byte
	pha
	lda StatementVectorLo,x	;low-byte
	pha
	rts			;and call
.endproc
;;; *** SetupLine (SETLINE in Atari Basic)
;;; *** Find the line given by TargetLine, initialize the line length
;;; *** and the current statement to the start of the line
	.global SetupLine
.proc	SetupLine
	jsr FindTargetLine
	;; runs into the following
.endproc
;;; *** Initialize the start of the line 
;;; *** SetupLineOffsets (SETLN1 in Atari Basic)
;;; *** Setup the line length and the statement offset
;;; *** for the current line
;;; *** MUST NOT alter the C flag. MUST return with Z=0
	.global SetupLineOffsets
.proc	SetupLineOffsets
	ldy #2
	lda (CurrentLinePtr),y
	sta LineLength		;extract the line length from the current line
	iny
	sty StatementEnd 	;offset to the current statement
	rts
.endproc
;;; *** InitializeMemory
;;; *** This is part of the NEW functionality - it initializes
;;; *** all variables and from the Os memory pointers
	.global InitializeMemory
.proc	InitializeMemory
	ldx MemLo
	ldy MemLo+1
	stx LoMem
	sty LoMem+1
	jsr ResetEnterListIOCB	;select IOCB #0
	sta LoadFlag
	sta GenerationCounter
	iny			;add 256: 256 bytes for the output buffer which starts at TokenBuffer
	txa			;get low-byte to A
	ldx #HiMem-LoMem	;fill all pointers up to the end
cs1:	
	sta LoMem,x		;initialize basic pointers, low byte
	sty LoMem+1,x		;and high-byte
	dex
	dex
	bne cs1			;clear them up
	ldx #VarValuePtr	;variable pointer table
	ldy #1
	jsr AllocMemLow		;allocate one byte for the expansion table
	
	ldx #ArrayTablePtr	;string/array table pointer
	ldy #3
	jsr AllocMemLow		;allocate three bytes for the array/strings

	;; now zero out buffers
	lda #0
	tay
	sta (VarNameEndPtr),y	;indicate the end of the variable names
	sta (CurrentLinePtr),y
	iny
	lda #$80
	sta (CurrentLinePtr),y		;indicate line #32768: direct line!
	iny
	lda #$03
	sta (CurrentLinePtr),y
	;; runs into the following
.endproc
;;; *** RunInit (RUNINIT in Atari Basic)
;;; *** Initialize storage locations for RUN
	.global RunInit
.proc	RunInit
	;; reset some other internal variables
	lda #10
	sta PrintColonWidth	;number of blanks for "," in PRINT
	ldy #0			;stopline does not require a reset
	sty RadFlag		;switch to radiants
	sty DataOffset		;current line to be read by READ in DATA lines
	sty DataLine
	sty DataLine+1		;clear data line as well
	dey
	sty TrapLine+1		;no error trapping
	sty StopLine+1		;not stopped anywhere (THOR: was reset to line #0, which is not really useful)
	sty BreakFlag		;clear break key flag
	rts
.endproc

;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicexecution.i,v 1.6 2015/09/15 21:36:33 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   Support for executing statements               **
;;; **********************************************************************

LineLength		=	$9f	;also used as line length (LLNGTH in Atari Basic)
TargetLineNumber	=	$a0	;line number to search for (TSLNUM in Atari basic)
StatementEnd		=	$a7	;offset of the length byte in the output buffer (STMLB or NXTSTD in Atari basic), also StatementLen
StatementOffset		=	$a8	;offset within the current statement (STMSTRT,STINDEX in Atari basic), also StatementStart
DataOffset		=	$b6	;offset into DataLine where the next READ will take place (DATAD in Atari Basic)
DataLine		=	$b7	;line # of the next READ containing DATA lines (DATALN in Atari Basic)
TrapLine		=	$bc	;target line for error trapping (TRAPLN in Atari Basic)
StopLine		=	$ba	;the line of program abortion (STOPLN in Atari Basic)
	
	.global FindTargetLineYA
	.global FindTargetLine	
	.global GetLineLength
	.global GetNextLine
	.global TestStatementEnd
	.global TestIfDirect
	.global Stop
	.global ExecuteProgram
	.global SetupLine
	.global SetupLineOffsets
	.global RunInit
	.global InitializeMemory


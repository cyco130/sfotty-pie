;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicexpression.asm,v 1.52 2017/04/15 16:28:12 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   Evaluation of Expressions			**
;;; **********************************************************************

	.include "basicmacros.i"
	.include "basicexpression.i"
	.include "operatorvector.i"
	.include "basicmemory.i"
	.include "basicerror.i"
	.include "basicexecution.i"
	.include "basicoperators.i"
	.include "basicmath.i"
	.include "mathpack.i"
	.include "basicio.i"
	.include "syntax.i"
	
	.segment "BasMain"
	
;;; *** GetToken (GETTOK in Atari Basic, and :EGTOKEN)
;;; *** read the next token from the current line
;;; *** Returns with C=0 if the token represents a value and the value
;;; *** is already loaded into VariableType and following. Otherwise,
;;; *** it still lacks evaluation, and the token is returned in A.
	.global GetToken
.proc	GetToken
	ldy StatementOffset
	inc StatementOffset
	lda (CurrentLinePtr),y
	bmi GetVariable		;all tokens of 80 and beyond are variables
	cmp #StringToken	;a string or a numeric variable?
	bcc numeric		;if below this token, it is a numeric constant
	bne expression		;if not a string either, we found a generic expression
	;; here a string token
	iny
	lda (CurrentLinePtr),y	;get the length of the string
	ldx #CurrentLinePtr	;make a string variable
	bne makestringconst	;load the string pointer into the internal buffer
	;; here a numeric token
numeric:
	jsr GetNextBCD
	iny
	tya			;updated statement index
	ldx #VTYPE_Numeric	;this is zero
	stx VariableType
	beq skiptokens
makestringconst:
	jsr StringConstFromPointerAndSize
	;; now update the index
	tya
	adc StringLength
	;; runs into the following
skiptokens:
	sta StatementOffset
	clc
expression:
	rts
.endproc
;;; *** GetVariable (GETVAR in Atari Basic)
;;; *** Extract the value of a variable #A from the variable table
;;; *** and place it into VariableType and friends
;;; *** MUST return with C=0, MUST not touch X
	.global GetVariable
.proc	GetVariable
	jsr GetVariableAddress	;get address in the variable table
copyvalue:	
	lda (VarTableEntryPtr),y
	sta VariableType,y
	dey
	bpl copyvalue
	rts
.endproc
;;; *** GetVariableAddress (GVVTADR in Atari Basic)
;;; *** load the address of the variable #A to VarTableEntryPtr,
;;; *** must return with C=0,Y=7
.proc GetVariableAddress
	;; now mutliply by eight
	asl a			;ignore MSB in first shift
	rol a
	rol a
	rol a			;carry contains now bit #3
	tay			;keep high-order bits
	and #$f0
	ror a			;this also clears the carry
	adc VarValuePtr
	sta VarTableEntryPtr
	tya
	and #03			;only the lower order bits have been rotated in.
	adc VarValuePtr+1
	sta VarTableEntryPtr+1
	ldy #7			;required for the following calls.
	rts
.endproc
;;; *** GetNextBCD (NCTOFR0 is not exactly equivalent, it does a bit more)
;;; *** Read a BCD number from the statement table at offset Y
;;; *** and return it in fr0
	.global GetNextBCD
.proc	GetNextBCD
	ldx #-6+256
cploop:
	iny
	lda (CurrentLinePtr),y
	sta fr0+6,x
	inx
	bne cploop
	rts
.endproc
;;; *** StringConstFromPointer
;;; *** Create a string constant by setting the zero-page
;;; *** pointers accordingly. Arguments are X=the location of the string
;;; *** where it is relative to, A=the size of the string, Y:the offset
;;; *** relative to the zero-page location in X where the string is, including
;;; *** the length byte for the string constant.
;;; *** MUST exist with C=0
	.global StringConstFromPointerAndSize
.proc	StringConstFromPointerAndSize
	sta StringLength
	sta StringDimension
	iny
	tya
	clc
	adc 0,x
	sta VariablePointer
	lda #0
	sta StringLength+1
	sta StringDimension+1
	sta VariableIndex	;none of the internal
	adc 1,x
	sta VariablePointer+1
	;; now update the index
	ldx #VTYPE_Absolute|VTYPE_String|VTYPE_Dimensioned
	stx VariableType
	rts
.endproc
;;; *** GetValidIOCB (GIODVC in Atari Basic)
;;; *** Read the IOCB channel as argument,
;;; *** validate that it is not zero, and error
;;; *** in case it is.
	.global GetValidIOCB
.proc	GetValidIOCB
	jsr GetIOCB
	tax
	beq iocberror
	cmp #8
	bcs iocberror
	sta IOCB
	jmp LoadIOCBOffset
iocberror:	
	Error IOCBOverflow
.endproc
;;; *** GetLineNumber (GETPINT in Atari Basic)
;;; *** Parse off a numeric expression, round to the next
;;; *** integer, check whether it is smaller than 32768.
;;; *** Actually, negative numbers are outright rejected
;;; *** as part of the BCD->Int Conversion
;;; *** Returns low in A, high in Y (new)
;;; *** MUST return with N=0
	.global GetLineNumber
.proc	GetLineNumber
	jsr GetInteger		;first load the integer
	bmi lnerror
	rts
lnerror:
	Error LineNumberOverflow
.endproc
;;; *** PopStringIndex (XSPV in Atari Basic)
;;; *** Get a positive non-zero index used as string offset
;;; *** create an error on failure. Return the index in (Y,A)
	.global PopStringIndex
.proc	PopStringIndex
	jsr PopInteger
	bne exit
	tax
	beq error
exit:
	rts
error:
	Error StringLengthError
.endproc
;;; *** PopByte (Not in Atari Basic)
;;; *** Pop a byte from the argument stack, error if this is out of range.
	.global PopByte
.proc PopByte
	jsr PopInteger
	bne CauseValueError
	rts
.endproc
;;; *** GetArgument (POP1 in Atari Basic)
;;; *** Evaluate an expression, and pop the result to
;;; *** the variable buffer in Z page (fr0, basically)
	.global GetArgument
.proc	GetArgument
	jsr EvaluateExpression
	jmp PopArgument
.endproc
;;; *** GetInteger (GETINT in Atari Basic)
;;; *** Evaluate an expression, then convert it to integer
;;; *** Returns Hi in Y and Lo in A, sets flags from Y
	.global GetInteger
.proc	GetInteger
	jsr EvaluateExpression
	;; runs into the following
.endproc
;;; *** PopInteger (GTINTO in Atari Basic)
;;; *** Pop the topmost argument from the argument stack
;;; *** and convert to integer
;;; *** Returns Hi in Y and Lo in A, sets flags from Y
	.global PopInteger
.proc	PopInteger
	jsr PopArgument
	;; runs into the following
.endproc
;;; *** ConvertToInteger
;;; *** Convert fr0 to integer, fail if not possible,
;;; *** return the number in A,Y, set flags from Y
;;; *** Must return with C=0
	.global ConvertToInteger
.proc	ConvertToInteger
	jsr ConvertBCDToInt
	lda fr0
	ldy fr0+1
	rts
.endproc
;;; *** GetIOCB (GIOPRM in Atari Basic)
;;; *** Return the IOCB channel from a #iocb token
;;; *** NOTE: Various hacks use IOCB #16 for PRINT and INPUT, and
;;; *** only these two enter here directly.
	.global GetIOCB
.proc	GetIOCB
	inc StatementOffset 	;skip over the # token
	;; runs into the following
.endproc
;;; *** GetByte (GET1INT in Atari Basic)
;;; *** Evaluatute an expression, convert it to integer,
;;; *** fail if this is larger than 255
	.global GetByte
.proc	GetByte
	jsr GetInteger
	bne CauseValueError
	rts
.endproc
;;; *** CauseValueError
;;; *** Creates an error on incorrect value
.proc	CauseValueError
	Error ValueError
.endproc
;;; *** Pop2Arguments (ARGP2 in Atari Basic)
;;; *** Pop two arguments, the topmost goes to FR1, the second to FR0
	.global Pop2Arguments
.proc	Pop2Arguments
	jsr PopArgument
	jsr Fr0ToFr1Vector
	;; runs into the following
.endproc
;;; *** PopArgument (ARGPOP in Atari Basic)
;;; *** Pop one argument from the argument stack, put it into the variable type buffer
;;; *** starting at fr0. Must return with fr0 in A.
	.global PopArgument
.proc	PopArgument
	dec ArgumentStackPtr
	ldx ArgumentStackPtr
	lda ArgumentStack+$00,x
	sta VariableType
	lda ArgumentStack+$20,x
	sta VariableIndex
	lda ArgumentStack+$40,x
	sta fr0
	lda ArgumentStack+$60,x
	sta fr0+1
	lda ArgumentStack+$80,x
	sta fr0+2
	lda ArgumentStack+$a0,x
	sta fr0+3
	lda ArgumentStack+$c0,x
	sta fr0+4
	lda ArgumentStack+$e0,x
	sta fr0+5
	rts
.endproc
;;; *** PushIntegerAY (XPIFP in AtariBasic)
;;; *** Push the integer (Y,A) onto the argument stack
	.global PushIntegerAY
.proc	PushIntegerAY
	sta fr0
	sty fr0+1
	;; runs into the following
.endproc
;;; *** PushInteger (XPIFP1 in AtariBasic)
;;; *** Push the integer in fr0,fr0+1
	.global PushInteger
.proc	PushInteger
	jsr IntToBCDVector	;to BCD
	;; runs  into the following
.endproc
;;; *** PushBCD (XPIFP2 in Atari Basic)
;;; *** Push the BCD number in fr0
	.global PushBCD
.proc PushBCD
	lda #0
	sta VariableType	;numeric
	;; sta VariableIndex	;not really required.
	;; runs into the following
.endproc
;;; *** PushArgument (ARGPUSH in Atari Basic)
;;; *** Push one argument from the VariableType and following onto the argument stack
;;; *** MUST return with NE (Z=0)
	.global PushArgument
.proc PushArgument
	ldx ArgumentStackPtr
	lda VariableType
	sta ArgumentStack+$00,x
	lda VariableIndex
	sta ArgumentStack+$20,x
	lda fr0
	sta ArgumentStack+$40,x
	lda fr0+1
	sta ArgumentStack+$60,x
	lda fr0+2
	sta ArgumentStack+$80,x
	lda fr0+3
	sta ArgumentStack+$a0,x
	lda fr0+4
	sta ArgumentStack+$c0,x
	lda fr0+5
	sta ArgumentStack+$e0,x
	inc ArgumentStackPtr
	beq stackoverflow
	rts
stackoverflow:
	Error ArgStackOverflow
.endproc
;;; *** SetVariableToIntLo (ISVAR1 in Atari basic)
;;; *** Set the variable given as argument to
;;; *** the value in A, with the high part
;;; *** set to zero.
	.global SetVariableToIntLo
.proc	SetVariableToIntLo
	ldy #0
	;; runs into the following
.endproc
;;; *** SetVariableToInt (ISVAR in atari basic)
;;; *** Set the variable indicated by the next token
;;; *** to the value in (Y,A)
	.global SetVariableToInt
.proc	SetVariableToInt
	sta fr0
	sty fr0+1
	jsr IntToBCDVector
	;; runs into the following
.endproc
;;; *** SetVariableToFr0 (not in Atari basic)
;;; *** Set a variable (still to be parsed)
;;; *** to the value in fr0
	.global SetVariableToFr0
.proc	SetVariableToFr0
	jsr PushArgument
	lda VariableType		;this is still valid from the evaluator
	beq AssignVariable		;a simple assignment?
	bmi stringassignment
	;; here an array
	jsr SetAssignFlag
	jmp EvaluateNumericArrayBracketOpen
stringassignment:
	jmp EvaluateStringAssignment
.endproc
;;; *** EvaluateNumericAssignment (XPAASN in Atari Basic)
;;; *** Evaluate the = sign in its role of the assignment
;;; *** operator
	.global EvaluateNumericAssignment
.proc	EvaluateNumericAssignment
	ldy OperatorStackPtr	;anything on the stack?
	beq AssignVariable
	;; runs into the following
.endproc
;;; *** SetAssignFlag
;;; *** Set the assign flag to indicate that an
;;; *** assignment to an array element is pending
	.global	SetAssignFlag
.proc	SetAssignFlag
	lda #$80
	sta AssignFlag
	rts
.endproc
;;; *** AssignVariable
;;; *** Perform a simple variable assignment
;;; *** with the value and the variable
;;; *** both on the stack
.proc	AssignVariable
	jsr Pop2Arguments	;load fr0 from the argument, the variable index is stored already
	jsr Fr1ToFr0
	;; runs into the following
.endproc
;;; *** SetVariable (AtariBasic RTNVAR)
;;; *** Install the value of fr0 into the variable
;;; *** whose index is given in VariableIndex
;;; *** MUST return with N=1,C=0
	.global SetVariable
.proc	SetVariable
	lda VariableIndex
	jsr GetVariableAddress
cploop:
	lda VariableType,y
	sta (VarTableEntryPtr),y
	dey
	bpl cploop
	rts
.endproc	
;;; *** GetLValue
;;; *** extract an LValue from the basic program
;;; *** and store it on the stack
	.global GetLValue
.proc	GetLValue
	;; runs into the following
.endproc
;;; *** EvaluateLValue (not present in Atari Basic)
;;; *** Execute an expression such that the value of the
;;; *** variable to be assigned to is expected on the
;;; *** the bottom of the stack. This allows consistent
;;; *** return values into variables.
.proc	EvaluateLValue
	lda #$40
	Skip2
	;; runs into the following
.endproc
;;; *** ExecuteLet (XLET in Atari Basic)
;;; *** Execute the LET instruction, generic assignment
.proc	ExecuteLet
	;; runs into the following
.endproc
;;; *** EvaluateExpression (EXEXPR in Atari Basic,0xaada in rev.C)
;;; *** Evaluate an expression, push it onto the stack
	.global EvaluateExpression
.proc	EvaluateExpression
	lda #$0
	sta AssignFlag		;reset the assigment flag
	ldy #0			;size of the stack
	lda #EndOfExpression	;push this on the end of the stack
	sta (OperatorStack),y
	sty OperatorStackPtr
	sty CommaCount		;reset the comma count
	sty ArgumentStackPtr	;reset the stack pointer
	;; runs into the following (sets always EQ)
.endproc
;;; *** ContinueEvaluation (EXOPOP in Atari Basic)
;;; *** Continue the evaluation with the next token on the stack
	.global ContinueEvaluation
.proc	ContinueEvaluation
	ldy OperatorStackPtr	;this is only zero at the start of the stack evaluation
	bne exopop
getnext:	
	jsr GetToken		;get the next token, whatever it might be
	bcs evaluateoperator	;if it is an operator, evaluate it then
	;; here it is already a value
	jsr PushArgument
	bne getnext		;jumps always
evaluateoperator:
	sta OperatorToken
	tax
	lda OperatorPriorityTable-16,x ;get the priority (note that all real operators start with offset 16)
	lsr a
	lsr a
	lsr a
	lsr a			;right priority is in upper nibble
	sta OperatorPriority
	;; now check which operator to evaluate first
evalloop:
	ldy OperatorStackPtr	;end of the stack - start of the operator list
	lda (OperatorStack),y	;get the operator on the stack
	tax
	lda OperatorPriorityTable-16,x ;lower or higher?
	and #$0f		;get the left priority from the lower nibble
	cmp OperatorPriority	;compare the priority of the operator on stack with the priority of this operator
	bcc pushargument	;if lower, store the argument for the time being
	tax
	beq exit		;if zero, then the last operator is done: This is the priority of EndofExpression
	;; here: Evaluate the operator by popping from stack
exopop:	
	lda (OperatorStack),y	;get operator again
	dec OperatorStackPtr	;remove from the operator stack
	jsr EvaluateOperator	;evaluate this single operator (EXOP in Atari Basic)
	clc
	bcc evalloop		;continue with the next operator on the stack, work backwards through the pushed operators
	;; here the operator is not ready, must first evaluate some higher priority operator
pushargument:
	iny
	sty OperatorStackPtr
	lda OperatorToken
	sta (OperatorStack),y	;push onto the operator stack
	bcc getnext		;get next (jump always)
exit:
	rts
.endproc
;;; *** EvaluateOperator (EXOP in Atari Basic)
;;; *** Evaluate an operator, taking arguments from the stack and pushing the result onto the stack
.proc	EvaluateOperator
	tax
	lda OperatorVectorHi-LessOrEqualToken,x	;high byte
	pha
	lda OperatorVectorLo-LessOrEqualToken,x	;low-byte
	pha
	rts			;and call
.endproc
;;; *** CompareOperator (XCMP in AtariBasic)
;;; *** This implements the string and numeric operators
;;; *** Returns N=1 if the left operator is smaller than the right
;;; *** Returns Z=1 if the two operators are identical
;;; *** This expects that X still contains the operator type
	.global CompareOperator
.proc	CompareOperator
	cpx #StringLessOrEqualToken
	bcs CompareOperatorString
	jsr Pop2Arguments
	;; runs into the following
.endproc
;;; *** CompareOperatorNumeric (FRCMP in Atari Basic)
;;; *** Compare two floating point values, return condition codes
;;; *** according how they compare
	.global CompareOperatorNumeric
.proc	CompareOperatorNumeric
	lda fr0
	sec
	eor fr1
	bmi signsdiffer
	beq mantissa
	lda fr1
	sbc fr0			;determine difference
adjustsign:
	ror a			;move carry into bit 7: carry clear if fr1<fr0
adjustsign7:	
	eor fr0			;adjust order by the signs
	ora #$01		;certainly never zero
	rts
signsdiffer:
	ora fr0
;;; if the result is 0x80, then the lower bits of fr0 must be zero, then so must be the bits of fr1 -> denormalized
	eor #$80		;check for denormalized numbers
	beq precise
	bne adjustsign7		;otherwise, take the sign from fr0
mantissa:	
	lda fr1+1
	sbc fr0+1
	bne adjustsign
precise:	
	jsr SubtractNumeric	;compute the difference
	;; runs into the following
.endproc
;;; *** TestFr0Sign
;;; *** Returns N=1 if fr0 is negative, Z=1 if it is zero
;;; *** and NZ if non-zero
	.global TestFr0Sign
.proc	TestFr0Sign
	ldx #fr0
	Skip2
	;; runs into the following
.endproc
;;; *** TestFr1Sign
;;; *** Test the sign of Fr1
	.global TestFr1Sign
.proc	TestFr1Sign
	ldx #fr1
.endproc
;;; *** TestFrXSign
;;; *** Test the sign of the floating point variable X
	.global TestFrXSign
.proc	TestFrXSign
	lda 0,x
	and #$7f	;test without the sign
	bne nonzero	;if non-zero, or negative, result is given and in N
	;; here the exponent is zero. Number is zero or denormalized.
	;; now check the mantissa. Could be non-zero
	lda 1,x
	ora 2,x
	ora 3,x
	ora 4,x
	ora 5,x
	beq exit		;if zero, this is zero (plus zero, minus zero)
nonzero:
	ora 0,x			;get the sign from the exponent
exit:
	rts
.endproc
;;; *** CompareOperatorString (STRCMP in Atari Basic)
;;; *** Compare two strings, set flags accordingly
.proc	CompareOperatorString
	jsr PopStringAbsolute
	jsr Fr0ToFr1Vector
	jsr PopStringAbsolute
	ldy #0
cmploop:
	ldx #StringLength
	jsr DecrementZeroPagePtr
	php
	ldx #StringLength+fr1-fr0
	jsr DecrementZeroPagePtr
	beq string2empty
	plp
	beq lessthan
	;; here none of the strings is empty, so compare the pointers
	lda (VariablePointer),y
	cmp (VariablePointer+fr1-fr0),y
	bcc lessthan
	bne greaterthan
	;; here equal. Increment the pointer
	iny
	bne cmploop
	inc VariablePointer+1
	inc VariablePointer+fr1-fr0+1
	bne cmploop
string2empty:
	plp
	bne greaterthan
	;; condition codes are set correctly here for equal
	rts
lessthan:
	lda #$80		;set N=1, Z=0
	rts
greaterthan:
	lda #$1			;set N=0, Z=0
	rts
.endproc
;;; *** DecrementZeroPagePtr (ZPADEC in Atari basic)
;;; *** Decrement a two-byte zero page pointer indexed by X
;;; *** Unlike Atari Basic, DOES NOT touch the Y register
;;; *** Returns Z=1 if the register pair is zero
	.global DecrementZeroPagePtr
.proc	DecrementZeroPagePtr
	lda 0,x
	bne nodec1
	lda 1,x
	beq exit
	dec 1,x
nodec1:
	dec 0,x
	txa			;set NE
exit:
	rts
.endproc
;;; *** PopStringAbsolute (AAPSTR in Atari Basic)
;;; *** pop a string from the stack, and convert its address
;;; *** to an absolute value.
	.global PopStringAbsolute
.proc	PopStringAbsolute
	jsr PopArgument
	;; runs into the following
.endproc
;;; *** GetStringAddress (GSTRAD in Atari Basic)
;;; *** Compute the absolute address of a string variable from
;;; *** the data in VariableType and following. Returns the result
;;; *** in VariablePointer and (A,Y)
	.global GetStringAddress
.proc	GetStringAddress
	lda #VTYPE_Absolute
	bit VariableType		    ;if this bit is already set, we do have an absolute address all the way
	bne exit
	ora VariableType		    ;turn it on now
	sta VariableType
	ror a				    ;check for bit #0, i.e. is the string dim'd?
	bcc GoDimError	    		    ;if not, create an error
	clc
	lda VariablePointer
	adc ArrayTablePtr
	sta VariablePointer
	tay				    ;also return LO in y
	lda VariablePointer+1
	adc ArrayTablePtr+1
	sta VariablePointer+1
exit:	
	rts
.endproc
;;; *** ZTempTimesDim2 (AMUL in Atari Basic)
;;; *** Multiply ZTemp with the contents of Dim2
;;; *** Return in Ztemp1. This is used for two-dimensional
;;; *** arrray accesses.
	.global ZTempTimesDim2
.proc ZTempTimesDim2
	ldy #0
	sty ztemp4
	sty ztemp4+1		;product
	cpy SecondArrayDimension+1 ;is the second array dimension 1? If so, avoid the multiplication
	bne multiply
	iny
	cpy SecondArrayDimension
	beq exit
multiply:
	ldy #$10		;number of bits in the product
mulloop:
	lda ztemp1
	lsr a			;test next bit, multiply from LSB to MSB
	bcc noadd
	clc
	ldx #-2+256		;add the multiplicator to the final product
addloop:
	lda ztemp4+2,x
	adc SecondArrayDimension+2,x
	sta ztemp4+2,x
	inx
	bne addloop
	;; If the add here overflows, the carry will be rotated
	;; into the MSB of the ztemp4+1 register and hence will
	;; end up *at least* in the LSB of ztemp4 and hence will
	;; be detected by the overflow test at the end.
noadd:
	;; shift the next bit in place. Note that ztemp1 and ztemp4 are adjacent
	ldx #3
rorloop:
	ror ztemp1,x
	dex
	bpl rorloop
	dey
	bne mulloop		;until all bits are done
	;; overflow? check whether the upper bits are zero
	lda ztemp4		;check whether the upper bits are zero
	ora ztemp4+1
	bne GoDimError
exit:
	rts
.endproc
;;; *** ZTempTimes6 (AMUL2 in AtariBasic)
;;; *** Multiply ZTemp with 6. This is the size of
;;; *** a BCD variable. FIXME: Should really test for overflows.
	.global ZTempTimes6
.proc	ZTempTimes6
	asl ztemp1
	rol ztemp1+1		;*2
	bcs GoDimError
	ldy ztemp1+1
	lda ztemp1		;keep for adding
	asl ztemp1
	rol ztemp1+1		;*4
	bcs GoDimError
	;; *4 + *2 = *6
	;; runs into the following
.endproc
;;; *** AddToZTemp (AADD in Atari Basic)
;;; *** Add the contents of (Y,A) to Ztemp1
	.global AddToZTemp
.proc	AddToZTemp
	clc
	adc ztemp1
	sta ztemp1
	tya
	adc ztemp1+1
	sta ztemp1+1
	bcs GoDimError
	rts
.endproc
;;; *** GoDimError
;;; *** Create an overflow error in case the size of the array is too large
.proc	GoDimError
	Error DIMMismatch
.endproc
;;; *** GetFileSpec (not in Atari Basic
;;; *** Get a file name from the operator stack
;;; *** append an EOL so we can make use of it.
	.global GetFileSpec
.proc	GetFileSpec
	jsr EvaluateExpression
	;; runs into the following
.endproc
;;; *** AppendEOL (AtariBasic SETEOL)
;;; *** Pop a string from the argument stack, and append an EOL
;;; *** as last character for further processing.
;;; *** Keep the address in inbuff, the original offset and
;;; *** value in index2+1 and index2.
;;; *** This maxes out at string lengths of 255.
	.global AppendEOL
.proc	AppendEOL
	jsr PopStringAbsolute	;get the string
	ldy #255
	lda StringLength+1
	beq isok
	sty StringLength	;max-out at 255 characters (FIXME: This is probably a bad idea!)
isok:
	iny
loop:
	cpy StringLength
	bcs abort
	lda (VariablePointer),y
	sta outbuff,y
	iny
	bpl loop
	dey			;truncate at the 127th character
abort:	
	lda #$9b
	sta outbuff,y
	jmp LoadOutbuffVector
.endproc

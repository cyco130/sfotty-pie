;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicexpression.i,v 1.19 2015/11/27 21:37:17 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   Evaluation of Expressions			**
;;; **********************************************************************

OperatorStack		=	$80	;also used as argument and operator stack for expression evaluation (also LoMem)
StartIndex		=	$f5	;the start index of a string range (also ztemp1)
EndIndex		=	$97	;end index of a string range (INDEX2 in Atari Basic)
Index1			=	$f5	;the first index (also ztemp1)
Index2			=	$97	;second index for arrays (also INDEX2 in Atari Basic)
VarTableEntryPtr	=	$9d	;pointer to the variable entry in the variable value table (WVVTPT in Atari Basic)
OperatorStackPtr	=	$a9	;start of the operator stack (OPSTKX in Atari Basic) (argument stack grows up, operator stack grows down)
ArgumentStackPtr	=	$aa	;the stack pointer of the argument stack (ARSLVL in Atari Basic) (the two stacks share the same memory)
OperatorToken		=	$ab	;for the expression evaluator: the last token to evaluate (EXSVOP in Atari Basic)
OperatorPriority	=	$ac	;for the expression evaluator: the priority of the last operator (EXSVPR)
USRArgCount		=	$c6	;counts the number of arguments for the USR function
CommaCount		=	$b0	;counts the number of commas (and hence arguments) of a statement (COMCNT in Atari Basic)
AssignFlag		=	$b1	;flag that is set for Lvalues? (ADFLAG in Atari Basic)
	;; the following eight locations are identical to the entries in the variable value table
VariableType		=	$d2	;$80 if the parser expects to find a string variable, $00 otherwise, $40 for an array
VariableIndex		=	$d3	;the number of the found variable (TVNUM in Atari Basic)
	;; the following is not by accident identical to the fr0 storage of the mathpack
VariablePointer		=	$d4	;position of the string or array (VTYPE+EVSADR in Atari Basic)
StringLength		=	$d6	;size of the string (two bytes) (VTYPE+EVSLEN in Atari Basic)
StringDimension		=	$d8	;reserved space of the string (two bytes) (VTYPE+EVSDIM)
FirstArrayDimension	=	$d6	;for arrays: first dimension size of the array+1
SecondArrayDimension	=	$d8	;for arrays: second array dimension+1
	;; variable types
VTYPE_Numeric		=	$00
VTYPE_String		=	$80
VTYPE_Array		=	$40
VTYPE_Dimensioned	=	$01     ;is DIM'd
VTYPE_Absolute		=	$02	;address is not relative to variable buffer
ArgumentStack		=	$480	;a separate argument stack
VariableTemp		=	$5f8 	;another location used for storing a single variable temporarily
	
	.global GetToken
	.global EvaluateExpression
	.global ContinueEvaluation
	.global GetArgument
	.global GetIOCB
	.global GetValidIOCB	
	.global GetLineNumber
	.global GetInteger
	.global GetByte
	.global GetStringAddress
	.global GetVariable
	.global SetVariableToIntLo
	.global SetVariableToInt
	.global SetVariable
	.global SetVariableToFr0
	.global GetLValue
	.global AssignString
	.global StringConstFromPointerAndSize
	.global GetFileSpec
	.global AppendEOL
	.global ZTempTimesDim2
	.global ZTempTimes6
	.global AddToZTemp
	.global CompareOperatorNumeric
	.global TestFr0Sign
	.global TestFr1Sign
	.global TestFrXSign
	.global DecrementZeroPagePtr
	.global GetNextBCD
	.global CompareOperator
	
	.global PushIntegerAY
	.global PushInteger
	.global PushArgument
	.global PushBCD
	.global PopArgument
	.global Pop2Arguments
	.global PopStringAbsolute
	.global PopInteger
	.global PopByte
	.global PopStringIndex
	.global ConvertToInteger
	
	.global ExecuteLet
	.global	SetAssignFlag
	.global EvaluateNumericAssignment
	

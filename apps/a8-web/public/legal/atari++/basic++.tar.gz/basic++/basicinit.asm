;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** $Id: basicinit.asm,v 1.4 2017/04/09 08:51:31 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Relocatable loader				**
;;; **********************************************************************

	.segment "BasInit"
	.include "reset.i"
	.include "kernel.i"
	.include "basicinit.i"
	
;;; This module is the relocatable loader for Basic++
;;; in case it is run from a binary executable. It
;;; takes the binary dump and relocates it to a free memory location.

;;; *** Entry point:
;;; *** Find memlo, place the init function there, then relocate basic to the next free page
	.proc Start
	lda MemLo
	sta MemBase
	lda MemLo+1
	sta MemBase+1
	;; MemBase is where our reset-resident part goes
	lda MemLo
	clc
	adc #<RelocSize
	sta CartBase
	lda MemLo+1
	adc #>RelocSize
	sta CartBase+1
	;; CartBase is where the cart goes. Now align up to the next
	;; page boundary.
	lda CartBase
	beq ispage
	inc CartBase+1
	lda #0
	sta CartBase
ispage:
	;; Insert the cart base into the reset-resident part
	lda CartBase
	sta RunAddress
	lda CartBase+1
	sta RunAddress+1
	;; and insert the new MemLo into the reset-resident part as well
	lda CartBase
	sta CartEnd
	lda CartBase+1
	clc
	adc #>CartSize
	sta CartEnd+1
	;; Set the old DOSINI in the initializer
	ldx #<RTSVector
	ldy #>RTSVector
	lda BootFlag
	beq keepreset
	ldx DosInit
	ldy DosInit+1
keepreset:
	stx OldDosInit+1
	sty OldDosInit+2
	lda BootFlag
	ora #$01
	sta BootFlag
	lda MemBase
	sta DosInit
	lda MemBase+1
	sta DosInit+1
	;; Ready with this stuff. Now copy the relocatable part.
	lda #<RelocStart
	sta SourcePtr
	lda #>RelocStart
	sta SourcePtr+1
	lda MemBase
	sta DestPtr
	lda MemBase+1
	sta DestPtr+1
	lda #<RelocSize
	ldx #>RelocSize
	jsr CopyMem		;copy to the target location
	;; now copy the cart data itself.
	lda #<BasicLoadBase
	sta SourcePtr
	lda #>BasicLoadBase
	sta SourcePtr+1
	lda CartBase
	sta DestPtr
	lda CartBase+1
	sta DestPtr+1
	lda #<CartSize
	ldx #>CartSize
	jsr CopyMem
	;; Now relocate the cartridge
	lda CartBase
	sta DestPtr
	lda CartBase+1
	sta DestPtr+1
	lda #<RelocData
	sta SourcePtr
	lda #>RelocData
	sta SourcePtr+1
	jsr Relocate
	;; relocate the reset part manually.
	lda #<RelocOffsets
	sta SourcePtr
	lda #>RelocOffsets
	sta SourcePtr+1
	lda MemBase
	sta DestPtr
	lda MemBase+1
	sta DestPtr+1
	jsr RelocateFine
	;; Move the reset and run function to page 4
	ldx #RunCodeLength
cprset:
	lda ResetAndRun-1,x
	sta ClearTarget-1,x
	dex
	bne cprset
	jmp ClearTarget
.endproc
;;; *** Reset the memory that is not part of basic, then
;;; *** then run the basic cart
.proc	ResetAndRun
	lda CartEnd
	sta DestPtr
	lda CartEnd+1
	sta DestPtr+1
	ldy #0
clrloop:
	tya
	sta (DestPtr),y
	inc DestPtr
	bne nohi
	inc DestPtr+1
nohi:
	lda DestPtr
	cmp MemTop
	lda DestPtr+1
	sbc MemTop+1
	bcc clrloop
	;; Finally, run the binary
	lda MemBase
	clc
	adc #3
	sta SourcePtr
	lda MemBase+1
	adc #0
	sta SourcePtr+1
	;; signal a coldstart to basic++
	lda #0
	sta WarmStartFlag
	jmp (SourcePtr)
.endproc
RunCodeLength	=	*-ResetAndRun
;;; *** CopyMem
;;; *** Copy memory from SourcePtr to DestPtr
;;; *** size in A (lo), X(Hi)
.proc	CopyMem
	eor #$ff
	tay
	iny			;two's completement
	sty MoveTemp		;this is what the iteration will start with.
	;; subtract this from the source and destination ptr since
	;; we will start copying with the above value of the Y register
	lda SourcePtr
	sec
	sbc MoveTemp
	sta SourcePtr
	bcs isoks
	dec SourcePtr+1
isoks:
	lda DestPtr
	sec
	sbc MoveTemp
	sta DestPtr
	bcs isokd
	dec DestPtr+1
isokd:
	inx
	tya
	bne copyloop
	dex
	bne copyloop
pageloop:
	inc SourcePtr+1
	inc DestPtr+1
copyloop:
	lda (SourcePtr),y
	sta (DestPtr),y
	iny
	bne copyloop
	dex
	bne pageloop
	rts
.endproc
;;; *** Relocate
;;; *** Relocate the binary at DestPtr with the relocation
;;; *** data at SourcePtr
.proc	Relocate
	ldy #0
	ldx #0
	lda CartBase+1
	sec
	sbc #>BasicNative
	sta MoveTemp
	lda (SourcePtr),y
relocloop:
	clc
	adc DestPtr
	sta DestPtr
	bcc isokd
	inc DestPtr+1
isokd:
	clc
	lda (DestPtr,x)
	adc MoveTemp
	sta (DestPtr,x)
	iny
	bne relocnext
	inc SourcePtr+1
relocnext:
	lda (SourcePtr),y
	bne relocloop
	rts
.endproc
;;; *** RelocateFine
;;; *** Relocate a program with word-offsets
.proc	RelocateFine
	ldx #0
	lda MemBase
	sec
	sbc #<RelocStart
	sta MoveTemp
	lda MemBase+1
	sbc #>RelocStart
	sta MoveTemp+1
	ldy #0
	lda (SourcePtr),y
relocloop:
	clc
	adc DestPtr
	sta DestPtr
	bcc isokd
	inc DestPtr+1
isokd:
	clc
	lda (DestPtr,x)
	adc MoveTemp
	sta (DestPtr,x)
	inc DestPtr
	bne noinc
	inc DestPtr+1
noinc:
	lda (DestPtr,x)
	adc MoveTemp+1
	sta (DestPtr,x)
	iny
	bne noiny
	inc SourcePtr+1
noiny:
	lda (SourcePtr),y
	bne relocloop
	rts
.endproc
;;; *** The init program starts here
RelocStart:
	jmp ResetInit		;started here on reset
	jmp RunInit		;started here on run
;;; *** ResetInit:
;;; *** Code enters here after a reset.
ResetInit:	
	jsr AdjustMemLo
	bit FmsBootFlag
	bvc OldDosInit
	rts			;here Basic tries to run DUP
OldDosInit:
	jsr RTSVector
;;; *** RunInit: Run Basic++
RunInit:	
	jsr AdjustMemLo
	jmp (RunAddress)
;;; *** AdjustMemLo
;;; *** This function adjusts the Os memlo so basic can go there instead.
.proc AdjustMemLo
	lda MemLo
	cmp CartEnd
	lda MemLo+1
	sbc CartEnd+1
	bcs isadjusted
	lda CartEnd
	sta MemLo
	lda CartEnd+1
	sta MemLo+1
isadjusted:
	rts
.endproc
RunAddress:
	.word 0
CartEnd:
	.word 0
RelocSize	=	*-RelocStart
	;; this short table contains the offsets to relocate for this binary itself.
RelocOffsets:
	.byte 1,2,2,11,2,5,5,4,5,0 
RelocData:
	;; the makefile places the relocation data here.

	
	

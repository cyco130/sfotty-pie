;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** $Id: basicinit.i,v 1.3 2017/04/09 08:51:31 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Relocatable loader				**
;;; **********************************************************************

;;; This module is the relocatable loader for Basic++
;;; in case it is run from a binary executable. It
;;; takes the binary dump and relocates it to a free memory location.

BasicLoadBase	=	$7000	;this is where the loader places the basic binary and where we get the source
MemBase		=	$80
CartBase	=	$82	
SourcePtr	=	$99
DestPtr		=	$9b
MoveTemp	=	$97
CartSize	=	$2000	;size of the cartridge: 8K
BasicNative	=	$a000	;this is where the cart would usually go
ClearTarget	=	$0480	;where the clear routine goes
	
	

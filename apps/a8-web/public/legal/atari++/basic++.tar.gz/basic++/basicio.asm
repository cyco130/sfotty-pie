;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicio.asm,v 1.30 2015/11/22 11:05:35 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   IO related support functions 			**
;;; **********************************************************************

	.include "basicmacros.i"
	.include "basicio.i"
	.include "basicerror.i"
	.include "basicstack.i"
	.include "basicmemory.i"
	.include "basicstatements.i"
	.include "basicmain.i"
	.include "basicexecution.i"
	.include "basicmath.i"
	.include "constants.i"
	.include "errors.i"
	.include "kernel.i"
	.include "mathpack.i"
	.include "cio.i"
	.include "editor.i"
	.include "irq.i"
	.include "pokey.i"

	
	.segment "BasMain"

;;; *** CloseAll
;;; *** Close all IOCBs, turn off sound channels (CLSALL in Atari Basic)
	.global CloseAll
.proc	CloseAll
	lda #0
	ldx #7
	stx IOCB
pkloop:
	sta AudFreq0,x
	dex
	bpl pkloop
clloop:
	jsr CloseIOCB
	dec IOCB
	bne clloop
	rts
.endproc
;;; *** CloseIOCB7
;;; *** Close the channel #7
.proc 	CloseIOCB7
	ldx #$7
	stx IOCB
	;; runs into the following
.endproc
;;; *** CloseIOCB
;;; *** Close the IOCB whose channel is given in IOCB (CLSYSD and CLSYS1 in Atari Basic)
	.global CloseIOCB
.proc	CloseIOCB
	jsr LoadIOCBOffset	;get the IOCB # to X
	beq keepopen
	lda #CmdClose
	bne CallCIOCmd
keepopen:
	rts
.endproc
;;; *** OpenTape (almost COPEN in Atari Basic)
;;; *** Open the tape with Aux1=Y
;;; *** FIXME: This is probably something that should or could go.
	.global OpenTape
.proc	OpenTape
	pha
	jsr CloseIOCB7
	lda #<TapeName
	ldy #>TapeName
	jsr Loadinbuff
	pla
	tay
	lda #$80		;short records
	jsr OpenIOCB7
	jmp TestForIOError
.endproc
;;; *** OpenIOCB7Aux2Z
;;; *** Open the IOCB #7 with the filespec in inbuff, with AUX1=A,AUX2=0
	.global OpenIOCB7Aux2Z
.proc	OpenIOCB7Aux2Z
	pha
	jsr CloseIOCB7
	pla
	tay
	lda #0
	;; runs into the following
.endproc
;;; *** OpenIOCB7
;;; *** Opens channel #7 with Aux1=Y,AUX2=A
.proc OpenIOCB7
	ldx #7
	;; runs into the following
.endproc
;;; *** OpenIOCB (SOPEN in Atari Basic)
;;; *** Open the IOCB #X with the filespec in inbuff, with AUX1=Y,AUX2=A
	.global OpenIOCB
.proc	OpenIOCB
	pha
	lda #CmdOpen
	jsr LoadIOCBCmdAndOffset
	pla
	sta IOCBAux2,x		;AUX2
	tya
	sta IOCBAux1,x		;AUX1
	;; Atari Basic resets inbuff here. Why?
	;; runs into the following. Size does not
	;; matter, but why not. Avoids a jump
.endproc
;;; *** CallCIOOnInputBuffer	(Atari Basic IO1)
;;; *** Run a CIO command on the input buffer, with buffer size = 255
	.global CallCIOOnInputBuffer
.proc	CallCIOOnInputBuffer
	ldy #255
	Skip2
.endproc
;;; *** CallCIOOnZeroBuffer	(Atari Basic IO2)
;;; *** Run a CIO command on the input buffer with the buffer size = 0
.proc	CallCIOOnZeroBuffer
	ldy #0
	;; runs into the following
.endproc
;;; *** CallCIOOnShortBuffer	(Atari Basic IO3)
;;; *** Run a CIO command on the input buffer with the buffer size = Y
	.global CallCIOOnShortBuffer
.proc	CallCIOOnShortBuffer
	lda #0			;hi-byte = 0
	;; runs into the following
.endproc
;;; *** CallCIOOnSizedBuffer	(Atari Basic IO4)
;;; *** Run a CIO command on the input buffer with the buffer size in (A,Y)
;;; *** A=Hi, Y=Lo
	.global CallCIOOnSizedBuffer
.proc	CallCIOOnSizedBuffer
	sta IOCBLen+1,x
	tya
	sta IOCBLen,x
	;; runs into the following
.endproc
;;; *** CallCIOOnUnsizedBuffer	(Atari Basic IO5)
;;; *** Run a CIO command on the input buffer, with size already set
.proc	CallCIOOnUnsizedBuffer
	lda inbuff+1
	ldy inbuff
	;; runs into the following
.endproc
;;; *** CallCIOOnBuffer (Atari Basic IO6)
;;; *** Run a CIO command on the buffer pointed to by A,Y
.proc	CallCIOOnBuffer
	sta IOCBAdr+1,x		;hi
	tya
	sta IOCBAdr,x		;lo
	;; runs into the following
.endproc
;;; *** CallCIOIOCmd
;;; *** Execute the CIO IOCmd (IO7 in Atari Basic)
	.global CallCIOIOCmd
.proc	CallCIOIOCmd
	lda IOCommand
	;; runs into the following
.endproc
;;; *** CallCIOCmd
;;; *** Execute an CIO call with the CIO command in A and the IOCB offset in X (IO8 in Atari Basic)
	.global CallCIOCmd
.proc	CallCIOCmd
	sta IOCBCmd,x
	jmp CIOVector
.endproc
;;; *** GetIOCBStatus (LDIOSTA in Atari Basic)
;;; *** Return the IOCB status in A
	.global GetIOCBStatus
.proc	GetIOCBStatus
	jsr LoadIOCBOffset
	lda IOCBStatus,x
	rts
.endproc
;;; *** LoadIOCBCmdAndOffset
;;; *** Load the IOCB offset given in the X register,
;;; *** set the next IOCB command from the accumlator (GLPXC in Atari Basic)
	.global LoadIOCBCmdAndOffset
.proc	LoadIOCBCmdAndOffset
	sta IOCommand
	;; runs into the following
.endproc
;;; *** LoadIOCBOffsetFromX
;;; *** Load the IOCB offset given in the X register (GLPX in Atari Basic)
	.global LoadIOCBOffsetFromX
.proc	LoadIOCBOffsetFromX
	stx IOCB
	;; runs into the following...
.endproc
;;; *** LoadIOCBOffset
;;; *** Load the IOCB as offset into the X register (LDDVX in Atari Basic)
	.global LoadIOCBOffset
.proc	LoadIOCBOffset
	lda IOCB
	asl a
	asl a
	asl a
	asl a			;*16
	tax
	bmi badiocb
	rts
badiocb:
	Error IOCBOverflow
.endproc
;;; *** PrintLineNumber
;;; *** Print the line number of the current line pointer
	.global PrintLineNumber
.proc PrintLineNumber
	ldy #1
	lda (CurrentLinePtr),y
	tax
	dey
	lda (CurrentLinePtr),y
	;; runs into the following
.endproc
;;; *** PrintNumber
;;; *** Print the number in (A = lo, X = hi) over the stdoutput
;;; *** followed by a blank
	.global PrintNumber
.proc	PrintNumber
	sta fr0
	stx fr0+1
	jsr IntToBCDVector	;convert to float
	jsr FixedBCDToAscii	;float to ASCII
	jsr LoadinbuffToPrintPtr
	bne PrintStringAndBlank
.endproc
;;; *** PrintBlankStringAndBlank	(Atari Basic LPTWB)
;;; *** Prints a blank, the string and the blank
	.global PrintBlankStringAndBlank
.proc	PrintBlankStringAndBlank
	jsr PrintBlank		;print the blank space
	;; and run into the following
.endproc
;;; *** PrintStringAndBlank (Atari Basic LPTTB)
;;; *** Prints the string in the PrintPtr and a blank over the ListIOCB
	.global PrintStringAndBlank
.proc	PrintStringAndBlank
	jsr PrintString	        ;first the token
	;; runs into the following
.endproc
;;; *** PrintBlank (not in Atari Basic)
;;; *** Print a single blank space to the editor
.proc	PrintBlank
	lda #' '
	bne PrintChar	        ;then the blank
.endproc
;;; *** PrintStringAY (No equivalent in Atari Basic)
;;; *** Print the string whose address is in A,Y
	.global PrintStringAY
.proc	PrintStringAY
	sta PrintPtr+1
	sty PrintPtr
	;; runs into the following
.endproc
;;; *** PrintString (Atari Basic LPRTOKEN)
;;; *** Print a string pointed to by PrintPtr and that is terminated by a byte whose LSB is set
;;; *** Returns the last character in A
	.global PrintString
.proc	PrintString
	ldy #$ff
	sty PrintOffset
printloop:
	inc PrintOffset
	ldy PrintOffset
	lda (PrintPtr),y	;get the character
	pha
	cmp #$9b		;is it EOL?
	beq prme		;if so, do directly
	and #$7f		;otherwise, remove MSB
	beq skip		;ignore unprintable characters
prme:
	jsr PrintChar		;print the character
skip:	
	pla
	bpl printloop		;and get the next character
	rts
.endproc
;;; *** PutOneByte (PDUM in Atari Basic)
;;; *** Call the put-one-byte vector of the current IOCB in X to output the character in Y
;;; *** This is clearly a big Yuck!
.proc	PutOneByte
	lda IOCBPut+1,x
	pha
	lda IOCBPut,x
	pha
	tya
	ldy #UnsupportedCmd
	rts			;go go, into the handler!
.endproc
;;; *** PrintCR (Atari Basic PRCR)
;;; *** Print an EOL (line feed) over the editor
;;; *** Also resets the LIST IOCB to the editor
	.global PrintCR
.proc	PrintCR
	lda #$9b		;the ATASCII EOL character
	ldx #0			;over the editor, please
	beq PrintCharIOCB
.endproc
;;; *** CountAndPrintChar (Atari Basic :XPRC1)
;;; *** Count the number of characters printed in COX, then
;;; *** print the character
	.global CountAndPrintChar
.proc	CountAndPrintChar
	inc PrintCounter
	;; runs into the following
.endproc
;;; *** PrintChar (Atari BASIC PRCHAR and PUTCHAR)
;;; *** Print a character over the current list device
;;; *** Must exit with N=0.
	.global PrintChar
.proc	PrintChar
	ldx ListIOCB
	;; runs into the following
.endproc
;;; *** PrintCharIOCB	(AtariBasic PRCX)
;;; *** Print a character over the IOCB loaded in the X register
	.global PrintCharIOCB
.proc	PrintCharIOCB
	pha
	jsr LoadIOCBOffsetFromX	;move to X
	;; Yuck,yuck,yuck! 
	lda IOCBAux1,x
	sta ZAux1
	lda IOCBAux2,x
	sta ZAux2
	pla
	tay
	jsr PutOneByte
	tya
	bmi ReportIOError
	rts
.endproc
;;; *** GetLine (Atari Basic GLGO)
;;; *** Read a line of input from stdin to the buffer pointed to by inpbuffer
	.global GetLine
.proc	GetLine
	jsr LoadOutbuffVector
	ldx EnterIOCB
	lda #CmdGetRecord
	jsr LoadIOCBCmdAndOffset
	jsr CallCIOOnInputBuffer ;read a line into the input buffer
	;; runs into the following
.endproc	
;;; *** TestForIOError (IOTEST in Atari Basic)
;;; *** Check whether the last IO operation succeeded. Report an IO error
;;; *** if so, otherwise return.
	.global TestForIOError
.proc	TestForIOError
	jsr GetIOCBStatus
	bmi ReportIOError
	rts
.endproc
;;; *** ReportIOError (SICKIO in Atari Basic)
;;; *** Report the IO error in the A register
;;; *** Must exit with N=0 unless it jumps to the error handler or coldstart
.proc	ReportIOError
	ldy IOCB
	cmp #EndOfFile		;End of file reached?
	bne report
	;; cpy #7
	;; bne report
	tsx			;check whether we were called top-level
	cpx #$fd		;stack frame from top level input, i.e. via ENTER?
	;; here coming from a command. Do not erase the program. (KAISER)
	;; KAISER unfortunately sets the LoadFlag, indicating that this
	;; is coming from a program load, which it does not (clearly)
report:
	php			;if we come here with Z=1, ENTER is aborted by EOF
	sta TrappedErrorNumber
	cpy #7			;was from IOCB #7, the load/save IOCB
	bne notloadsave
	jsr CloseIOCB		;shut the IOCB #7 down then
notloadsave:
	jsr ResetEnterListIOCB	;reset stdin/stdout to the editor
	plp			;EOF error on ENTER?
	beq enterinput
	lda TrappedErrorNumber
	cmp #128		;if this is break
	bne plainerror		;just do the regular error
	lda LoadFlag
	bne plainerror	   	;and if everything else is ok
	sta BreakFlag		;signal break to the interpreter
	rts
plainerror:	
	jmp Error		;go to the error handler
enterinput:
	;; otherwise, we are reading input from ENTER.
	;; do not report the error, just reset the enter IOCB.
	;; ENTER has a race condition here: The next EOF on the console
	;; records the error in the last line received by ENTER, and not
	;; just a blank output. Scanning of the direct input line here
	;; resolves that, but also breaks list-protected programs that
	;; enter data. So at this time, we leave it as is.
	;; ldy #$00
	;; lda #$80
	;; jsr FindTargetLineAY	;make sure we position ourselfes at the input line so the next error comes out right
	;; since line offsets may change due to editing the
	;; source, invalidate absolute addresses
	;; actually, calling ENTER already does that
	;; inc GenerationCounter
	jmp ExpectInput
.endproc
;;; *** TestForBreak (TSTBRK in Atari Basic)
;;; *** test whether the break key has been pressed,
;;; *** returns with Z, A=0 flag cleared if so
	.global TestForBreak
.proc	TestForBreak
	ldy #0
	lda BreakFlag
	bne nobreak
	dey
	sty BreakFlag
nobreak:
	tya	     ;set NE on break
	rts
.endproc
;;; *** ResetEnterListIOCB (SETDZ in Atari Basic)
;;; *** Reset the LIST and ENTER IOCBs to their default values, namely let them point to the editor
;;; *** MUST return with A=0. MUST NOT overwrite X and Y.
	.global ResetEnterListIOCB
.proc	ResetEnterListIOCB
	lda #0
	sta EnterIOCB
	sta ListIOCB
	rts
.endproc
;;; *** Loadinbuff (not in Atari Basic)
;;; *** load the input buffer by A=lo,Y=hi
	.global Loadinbuff
.proc	Loadinbuff
	sta inbuff
	sty inbuff+1
	rts
.endproc
;;; *** LoadinbuffToPrintPtr
;;; *** set the print pointer to the BCD input buffer pointer
;;; *** for preparing a string in inbuf
	.global LoadinbuffToPrintPtr
.proc	LoadinbuffToPrintPtr
	lda inbuff
	sta PrintPtr
	lda inbuff+1
	sta PrintPtr+1
	rts
.endproc

;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicio.i,v 1.7 2015/10/27 21:21:53 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   IO related support functions 			**
;;; **********************************************************************

PrintCounter		=	$94     ;counts the characters for PRINT (also cox)
PrintPtr		=	$95	;pointer to a message to be printed (SRCADR in Atari basic)
PrintOffset		=	$af	;temporary offset into the print buffer (SCANT in Atari basic)
EnterIOCB		=	$b4	;IOCB to be used for ENTERin (ENTDTD in Atari basic)
ListIOCB		=	$b5	;IOCB to be used for LISTing (LISTDTD in Atari basic)
IOCommand		=	$c0	;the next IO command to be issued (IOCMD in Atari Basic)
IOCB			=	$c1	;current channel number to operate on (IODVC in Atari Basic)

	;; exported symbols
	.global ResetEnterListIOCB
	.global PrintString
	.global PrintStringAY
	.global PrintCR
	.global PrintCharIOCB
	.global PrintChar
	.global CountAndPrintChar
	.global PrintNumber
	.global PrintLineNumber
	.global PrintBlankStringAndBlank
	.global PrintStringAndBlank
	.global GetLine
	.global LoadinbuffToPrintPtr
	.global OpenIOCB7Aux2Z
	.global OpenIOCB
	.global CloseIOCB
	.global	CloseIOCB7
	.global CloseAll
	.global GetIOCBStatus
	.global TestForIOError
	.global TestForBreak
	.global CallCIOOnSizedBuffer
	.global Loadinbuff
	.global LoadIOCBCmdAndOffset
	.global LoadIOCBOffset
	.global LoadIOCBOffsetFromX
	.global OpenTape
	.global CallCIOOnShortBuffer
	.global CallCIOOnInputBuffer
	.global CallCIOCmd
	.global CallCIOIOCmd

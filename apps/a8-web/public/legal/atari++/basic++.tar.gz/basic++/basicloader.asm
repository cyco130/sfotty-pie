;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** $Id: basicloader.asm,v 1.3 2015/12/19 19:05:41 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Relocatable loader				**
;;; **********************************************************************

	.segment "BasInit"
	.include "kernel.i"
	.include "reset.i"
	.include "pia.i"
	.include "cio.i"
	.include "screen.i"
	.include "basicloader.i"

;;; *** Start
;;; *** This is the start of the loader program. It moves the
;;; *** basic to place, installs the resident program and
;;; *** initializes it and the backup area.
Start:	
	;; disable the build-in basic
	lda PIAPortB
	ora #$02
	sta PIAPortB
	sta BasicDisabled
	jsr ResetMemHi
	ldx #<RTSVector
	ldy #>RTSVector
	lda #1
	bit BootFlag
	beq nodos
	ldx DosInit
	ldy DosInit+1
nodos:
	ora BootFlag
	sta BootFlag
	stx OldDosInit+1
	sty OldDosInit+2
	lda MemLo
	sta DosInit
	clc
	adc #ResidentSize
	sta NewMemLo
	sta MemLo
	lda MemLo+1
	sta DosInit+1
	adc #4			;number of pages to save for Basic
	sta NewMemLo+1
	sta MemLo+1
	
	;; Copy the resident part over
	lda #<ResidentInit
	sta SourcePtr
	lda #>ResidentInit
	sta SourcePtr+1
	lda DosInit
	sta DestPtr
	lda DosInit+1
	sta DestPtr+1
	ldy #ResidentSize-1
cpres:
	lda (SourcePtr),y
	sta (DestPtr),y
	dey
	bpl cpres
	ldx #RelocateSize-1
	lda DosInit
	sec
	sbc #<ResidentInit
	sta SourcePtr
	lda DosInit+1
	sbc #>ResidentInit
	sta SourcePtr+1
reloc:
	lda RelocOffset,x
	tay
	clc
	lda (DestPtr),y
	adc SourcePtr
	sta (DestPtr),y
	iny
	lda (DestPtr),y
	adc SourcePtr+1
	sta (DestPtr),y
	dex
	bpl reloc
	;; Now copy the basic in place.
	lda #<BasicLoadBase
	sta SourcePtr
	lda #>BasicLoadBase
	sta SourcePtr+1
	lda #<BasicNative
	sta DestPtr
	lda #>BasicNative
	sta DestPtr+1
	ldx #$20
	ldy #0
cpbasic:
	lda (SourcePtr),y
	sta (DestPtr),y
	iny
	bne cpbasic
	inc SourcePtr+1
	inc DestPtr+1
	dex
	bne cpbasic
	;; copy the basic into the backup-buffer
	lda DosInit
	clc
	adc #ResidentSize
	sta DestPtr
	lda DosInit+1
	adc #0
	sta DestPtr+1
	lda #<(BasicNative+$1c00)
	sta SourcePtr
	lda #>(BasicNative+$1c00)
	sta SourcePtr+1
	ldx #$4
	ldy #0
cpbackup:
	lda (SourcePtr),y
	sta (DestPtr),y
	iny
	bne cpbackup
	inc SourcePtr+1
	inc DestPtr+1
	dex
	bne cpbackup
	;; now copy the memclear program
	ldx #MemClearSize-1
cpclear:
	lda MemClear,x
	sta MemClearDest,x
	dex
	bpl cpclear
	lda #0
	sta WarmStartFlag	;ensure AUTORUN.BAS is loaded
	jmp MemClearDest
;;; *** MemClear
;;; *** This is a memory clearer to make sure basic finds its memory
;;; *** reset to zero (or actually, some broken programs)
MemClear:
	lda MemLo
	sta DestPtr
	lda MemLo+1
	sta DestPtr+1
	ldy #0
clrlp:
	tya
	sta (DestPtr),y
	inc DestPtr
	bne noinc
	inc DestPtr+1
noinc:
	lda DestPtr
	cmp MemTop
	lda DestPtr+1
	sbc MemTop+1
	bcc clrlp
	jmp (CartRun)		;start basic through the run-vector
MemClearSize	=	*-MemClear
;;; *** ResidentInit
;;; *** This is the resident part of Basic
ResidentInit:	
rl1:	jsr ResetMemHi		;move E: lower
rl2:	jsr AdjustMemLo
rl3:	jsr CopyFromBackup
OldDosInit:	
	jsr RTSVector
rl4:	jsr AdjustMemLo
	bit FmsBootFlag
	bvc RunBasic
	rts			;here Basic tries to run DUP
RunBasic:	
	jmp (CartRun)
ResetMemHi:			;adjust the position of the E: handler
	lda #>BasicNative
	sta RamTop
	lda #12
	sta ZAux1
	;; open the E: device again.
	lda EditorTable+1
	pha
	lda EditorTable
	pha
	rts
AdjustMemLo:			;adjust the position of memlo
rl5:	lda NewMemLo
	sta SourcePtr
rl6:	lda NewMemLo+1
	sta SourcePtr+1
	lda MemLo
	cmp SourcePtr
	lda MemLo+1
	sbc SourcePtr+1
	bcs noadjust
	lda SourcePtr
	sta MemLo
	lda SourcePtr+1
	sta MemLo+1
noadjust:
	rts
CopyFromBackup:
rl7:	lda NewMemLo
	sta SourcePtr
rl8:	lda NewMemLo+1
	sec
	sbc #4			;four pages
	sta SourcePtr+1
	lda #<(BasicNative+$1c00)
	sta DestPtr
	lda #>(BasicNative+$1c00)
	sta DestPtr+1
	ldy #0
	ldx #4
restbasic:
	lda (SourcePtr),y
	sta (DestPtr),y
	iny
	bne restbasic
	inc SourcePtr+1
	inc DestPtr+1
	dex
	bne restbasic
	rts
NewMemLo:	.word 0
ResidentSize	=	*-ResidentInit
RelocOffset:
	.byte rl1-ResidentInit+1
	.byte rl2-ResidentInit+1
	.byte rl3-ResidentInit+1
	.byte rl4-ResidentInit+1
	.byte rl5-ResidentInit+1
	.byte rl6-ResidentInit+1
	.byte rl7-ResidentInit+1
	.byte rl8-ResidentInit+1
RelocateSize	=	*-RelocOffset
	

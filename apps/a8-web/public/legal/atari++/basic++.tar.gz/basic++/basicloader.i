;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** $Id: basicloader.i,v 1.2 2015/12/19 15:24:51 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Relocatable loader				**
;;; **********************************************************************

;;; This module is the relocatable loader for Basic++
;;; in case it is run from a binary executable. It
;;; takes the binary dump and relocates it to a free memory location.

BasicLoadBase	=	$7000	;this is where the loader places the basic binary and where we get the source
MemBase		=	$80
CartBase	=	$82	
SourcePtr	=	$99
DestPtr		=	$9b
MoveTemp	=	$97
CartSize	=	$2000	;size of the cartridge: 8K
BasicNative	=	$a000	;this is where the cart would usually go
MemClearDest	=	$480	
	

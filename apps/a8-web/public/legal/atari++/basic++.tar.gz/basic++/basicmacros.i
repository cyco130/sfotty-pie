;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicmacros.i,v 1.3 2015/09/05 21:58:08 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Macros for Basic, used in all modules		**
;;; **********************************************************************

;;; *** Create a basic string with the last byte MSB inverted
	
.macro	bstring	Arg
	.repeat .strlen(Arg)-1, I
        .byte   .strat(Arg, I)
        .endrep
	.byte	.strat(Arg,.strlen(Arg)-1)|$80
.endmacro

.macro  Skip2
        .byte $2c
.endmacro
.macro  Skip1
        .byte $24
.endmacro

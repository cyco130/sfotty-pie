;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicmain.asm,v 1.24 2016/03/05 20:49:54 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Main program					**
;;; **********************************************************************

	.include "basicmacros.i"
	.include "basicmemory.i"
	.include "basicstack.i"
	.include "basicexecution.i"
	.include "basicparser.i"
	.include "basicio.i"
	.include "basicexpression.i"
	.include "basicstatements.i"
	.include "basicmain.i"
	.include "syntax.i"
	.include "constants.i"
	.include "mathpack.i"
	.include "reset.i"
	.include "editor.i"

	.segment "BasMain"

;;; *** BasicColdStart
;;; *** The basic enters here on a reset
	.global BasicColdStart
.proc	BasicColdStart
	lda LoadFlag		;program is corrupt? Try, try again.
	bne cold1
	inc GenerationCounter	;restarting the system, absolute addresses may get wrong
	lda WarmStartFlag
	bne WarmerStart
cold1:				;ok, completely from start, NEW out the system.
	pha			;keep the loadflag
	jsr InitializeMemory	;also resets the generation counter
	pla
	bne WarmerStart		;if the load flag was set, do not try again
	lda #>TitleMsg
	ldy #<TitleMsg
	jsr PrintStringAY
	jsr RunAutorun
	;; runs into the following
.endproc
;;; *** WarmerStart (SNX1 in Atari Basic)
;;; *** Closes all channels, resets stdin/stdout
;;; *** but does not RESTORE
	.global WarmerStart
.proc	WarmerStart
	jsr CloseAll
	jsr ResetEnterListIOCB	;select IOCB #0
	;; runs into the following
.endproc
;;; *** ExpectInput (SNX3 in AtariBasic)
;;; *** Print the READY prompt and await input to be parsed, then parse
	.global ExpectInput
.proc	ExpectInput
	jsr PrintCR
	lda #>ReadyMsg
	ldy #<ReadyMsg
	jsr PrintStringAY	;Print the famous READY string
	;; runs into the following
.endproc
;;; *** Syntax (SYNTAX in Atari Basic)
;;; *** This is the main loop of the Atari Basic editor mode, i.e.
;;; *** the place where statements are received and executed in direct mode,
;;; *** or where lines are read, tokenized and inserted into the statement
;;; *** table.
	.global Syntax
.proc	Syntax
	ldx #$ff		;reset stack
	txs
	lda LoadFlag		;interrupted and jumped into here while loading was in progress?
	bne BasicColdStart
	sta DirectFlag		;allow cursor movement again
	jsr GetLine		;read a line from the editor
	jsr TestForBreak	;BREAK key pressed?
	beq continue
	lda IOCB
	beq Syntax		;if this is comming from ENTER, print at least a message
	jsr CloseIOCB		;make sure the input IOCB is closed
	jmp ExecuteStop
continue:
	;; prepare now parsing the input buffer
	sta cix			;offset in the input buffer
	sta MaxValidcix		;clear this as well
	sta cox			;reset output buffer index
	sta DirectModeFlag	;execut directly or insert a line?
	sta LastOperatorcix	;no operator parsed yet
	sta AdditionalVariables
	;; make a copy of the endptr
	lda VarNameEndPtr
	sta PreviousVarNameEndPtr
	lda VarNameEndPtr+1
	sta PreviousVarNameEndPtr+1
	;; parsing starts now
	jsr SkipBlanksVector	;skip over blanks in the input buffer (advancing cix)
	jsr ParseLineNumber	;try to parse off the line number
	jsr InsertToken		;reserve space for the line length
	lda TargetLineNumber+1	;was this a line number >32768 and hence are we in direct mode?
	bpl isedit
	sta DirectModeFlag	;yes, is a direct command to be executed immediately
isedit:
	jsr SkipBlanksVector	;skip over the following blanks
	ldy cix
	sty StatementStart 	;keep me, here we start looking for statements
	lda (inbuff),y		;get next character
	cmp #$9b		;is it EOL?
	bne statementloop	;got an empty line?
	bit DirectModeFlag	;are we in direct mode?
	bmi Syntax		;if so, just an empty line, do nothing
	jsr FindTargetLine	;go search for the line
	bcs nosuchline		;if not found, do not bother
	jsr GetLineLength
	jsr DeleteThisLine	;otherwise, delete the line
nosuchline:	
	jmp Syntax		;continue parsing
;;; Now parse one token after another.
;;; This loop goes over the statements in a line, as separated by ":"
;;; and parses them.
statementloop:
	lda cox
	sta StatementLen 	;keep offset of the length byte
	jsr InsertToken		;reserve room for the statement length
	jsr SkipBlanksVector	;more blanks to avoid
	jsr SearchStatement
	;; if this does not find the statement, it will use the token of the ERROR statement...
	stx cix			;update cix, points now behind the statement (or at statement, if not found)
	lda ScanOffset		;this is now the statement offset
	jsr InsertToken		;add to output buffer
	jsr SkipBlanksVector
	jsr ParseArguments	;parse now the arguments of the statement
	bcc syntaxok
	;; here: invalid syntax, mark with ERROR
	;; check how far we got with the syntax parsing
	jsr InsertError
syntaxok:
	;; now fixup the statement end offset
	lda cox			;end position of the current statement
	ldy StatementLen
	sta (TokenBuffer),y	;adjust the end offset of the statement.
	;; check now whether we reached the end of the line (and not only the statement)
	ldy cix
	dey
	lda (inbuff),y
	cmp #$9b		;found EOL here?
	bne statementloop
;;; The line is now complete.
;;; Now decide whether to just insert
;;; it or execute it right away.
	;; ok, here the line is complete.
	ldy #2			;this is where we need to set the line size
	lda cox
	sta (TokenBuffer),y	;insert here
	;; insert into the statement table
	jsr InsertLine

	;; check for synax errors or direct execution
	bit DirectModeFlag
	bvc noerror
	;; here we have found a parsing error
	lda AdditionalVariables	;remove variables allocated on the go?
	asl a
	asl a
	asl a
	tay			;8 bytes per variable
	ldx #StatementPtr	;move statement table down
	jsr FreeMemLow		;and release the new values again
	sec
	lda VarNameEndPtr
	sbc PreviousVarNameEndPtr
	tay
	lda VarNameEndPtr+1
	sbc PreviousVarNameEndPtr+1
	ldx #VarNameEndPtr
	jsr FreeMem		;and release also the variable names that came here due to error

	bit DirectModeFlag	;are we in direct mode?
	bmi direct
	;; here with a line number
	jsr PrintLineNumber
direct:
	jsr ListDirectLine	;list the faulty line
	bcs gosyntax
noerror:
	bpl gosyntax		;if not direct, just continue parsing
	;; here: A direct command, execute now
	jmp ExecuteProgram
gosyntax:	
	jmp Syntax		;repeat the main loop
.endproc
;;; *** InsertLine (:SYNOK in Atari Basic, but not a subroutine)
;;; *** Insert the currently parsed line into the statement table
;;; *** move the statement table as necessary
.proc 	InsertLine
	;; now check whether we possibly need to replace the line in the statement table
	jsr FindTargetLine
	lda #0			;size of the old line if none found
	bcs insertnew		;branch if not present
	;; here: replace line
	jsr GetLineLength	;length of the old line
insertnew:			;or zero if there was no previous line before
	sec
	sbc cox			;do we need to reserve more or release memory?
	beq replace		;same storage requirment->copy over
	bcs release		;old line size is larger->release memory
	eor #$ff
	tay
	iny			;two's complement: number of bytes to reserve
	ldx #CurrentLinePtr	;move in here
	jsr AllocMemLow		;reserve memory
	lda AllocMemPtr		;get the address of the newly available memory
	sta CurrentLinePtr
	lda AllocMemPtr+1
	sta CurrentLinePtr+1
	bne replace		;and copy the line parsed in just into there
release:			;here: new line is shorter than old line
	jsr DeleteThisLine
replace:			;here: memory has been moved, now copy data over
	ldy cox
cploop:
	dey
	lda (TokenBuffer),y
	sta (CurrentLinePtr),y
	tya
	bne cploop		;until the last byte copied
	rts
.endproc
;;; *** DeleteThisLine (almost :SDEL in Atari Basic, but not a subroutine)
;;; *** Delete the current line of size A
.proc	DeleteThisLine
	pha			;store
	jsr GetNextLine		;advance to the end
	pla
	tay			;move line length to Y again
	ldx #CurrentLinePtr	;move this line out of memory
	jmp FreeMemLow
.endproc

;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicmain.i,v 1.7 2017/02/10 20:44:44 thor Exp $          **
;;; **                                                                  **
;;; ** In this module:   Main program					**
;;; **********************************************************************

DirectModeFlag		=	$a6	;flag on direct mode execution (DIRFLG in Atari basic)
PreviousVarNameEndPtr	=	$ad	;backup of VarNameEndPtr (SVVNT in Atari Basic), for removing variables created when parsing erranous input
AdditionalVariables	=	$b1	;(SVVVTE in Atari Basic) counts variables created while parsing, for the same purpose

	;; exported symbols
	.global	BasicColdStart
	.global WarmerStart
	.global Syntax
	.global ExpectInput
	.global SetupLine
	.global GetToken
	.global TestStatementEnd
	.global SetupLineOffsets
	

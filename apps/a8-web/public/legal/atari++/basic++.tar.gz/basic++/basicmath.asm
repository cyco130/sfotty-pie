;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicmath.asm,v 1.20 2017/04/09 08:51:31 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Math support functions				**
;;; **********************************************************************

	.include "basicmacros.i"
	.include "basicmath.i"
	.include "basicerror.i"
	.include "basicstack.i"
	.include "basicexpression.i"
	.include "constants.i"
	.include "mathpack.i"
	
	.segment "BasMain"
;;; *************************************** Math support functions start here **************************************
;;; *** All the following stuff are functions that did not make it into the math pack
;;; *** and that are unfortunately here.

;;; *** ConvertBCDToInt (Atari Basic CVFPI)
;;; *** Convert the BCD number in fr0 to an integer value in fr0,fr0+1 if this is
;;; *** possible. Generate a ValueError if this is not.
	.global ConvertBCDToInt
.proc	ConvertBCDToInt
	jsr BCDToIntVector
	bcs CauseOverflow		;create an error
	rts
.endproc
;;; *** AddNumeric (FRADD in Atari Basic)
;;; *** compute fr0+fr1->fr0, error on overflow
	.global AddNumeric
.proc	AddNumeric
	jsr BCDAddVector
	bcs CauseOverflow
	rts
.endproc
;;; *** SubtractNumeric (FRSUB in Atari Basic)
;;; *** compute fr0+fr1->fr0, error on overflow
	.global SubtractNumeric
.proc	SubtractNumeric
	jsr BCDSubVector
	bcs CauseOverflow
	rts
.endproc
;;; *** SquareFr0
;;; *** compute fr0^2, return with C=1 on error.
.proc	SquareFr0
	jsr Fr0ToFr1Vector	;to Fr1
	jmp BCDMulVector	;cannot run into the following, must
.endproc	
;;; *** MultiplyNumeric (FRMUL in Atari Basic)
;;; *** compute fr0+fr1->fr0, error on overflow
	.global MultiplyNumeric
.proc	MultiplyNumeric
	jsr BCDMulVector
	bcs CauseOverflow
	rts
.endproc
;;; *** DivideNumeric (FRMUL in Atari Basic)
;;; *** compute fr0+fr1->fr0, error on overflow
	.global DivideNumeric
.proc	DivideNumeric
	jsr BCDDivVector
	bcs CauseOverflow
	rts
.endproc
;;; *** CauseOverflow
;;; *** Creates an error on incorrect value
.proc	CauseOverflow
	Error NumericOverflow
.endproc
;;; *** BCDFloor (XINT in Atari Basic)
;;; *** round the argument in fr0 to the next smaller integer
;;; *** Returns with C=1 in case of failure (unlike the original)
	.global BCDFloor
.proc	BCDFloor
	lda fr0			;mask out the sign
	ldy #0
	and #$7f
	sec
	sbc #$3f		;compensate exponent bias
	bcs notsmall		;at least 1.0 then.
	tya			;set everything to zero
notsmall:
	tax			;index into fr0, i.e. everything below that is set to zero
	tya			;reset mask that checks everything below the dot
loop:
	cpx #5			;all digits done?
	bcs done
	ora fr0+1,x		;is something in the mantissa non-zero?
	sty fr0+1,x		;truncate by setting the mantissa to zero
	inx			;and continue with the mantissa
	bne loop
done:
	ldx fr0			;was negative?
	bpl normexit
	tax			;if all removed bytes were zero, fine then
	beq normexit
	;; add -1 as we only truncated the number, i.e. rounded towards zero
	;; however, this should be floor, so we need to round towards -infinity
	jsr Fr0ToFr1Vector
	jsr MinusOneToFr0
	jmp BCDAddVector	;includes a normalization
normexit:
	jmp NormalizeVector
.endproc
;;; *** InvertSign
;;; *** Invert the sign of fr0, i.e. return -fr0
	.global InvertSign
.proc	InvertSign
	lda fr0
	eor #$80
	sta fr0
	rts
.endproc
;;; *** BCDPowMain
;;; *** Compute fr0^fr1. fr1 is positive, fr0 is non-zero
;;; *** Returns C=1 on overflow. If not computable, error
;;; *** directly.
	.global BCDPowMain
.proc	BCDPowMain
	jsr PushArgument	;store fr0 on the argument stack
	;; compute the integer part of the exponent
	jsr Fr1ToFr0
	jsr BCDFloor		;compute the floor
	bcs seterrorpop
	jsr PushArgument	;keep the rounded down value
	jsr BCDToIntVector	;round to integer
	bcs seterrorpop2	;if this is too large (>65535), then we surely overrun anyhow....
	lda fr0
	sta IntegerExponent
	lda fr0+1
	sta IntegerExponent+1	;store exponent for later
	jsr PopArgument		;return the rounded result, fr1 still fine
	;; fr0 is now floor(fr1), fr1 is still unaltered
	;; the fractional part is now fr1-floor(fr0) = fr1-fr0 = -(fr0-fr1)
	jsr SubtractNumeric	;compute the fractional part. This should never fail
	jsr InvertSign
	;; fr0 is now the fractional part, the integer part is on the stack
	jsr SwapAndPop		;fractional->fr1, basis to fr0
	ldx #<FPSrc3
	ldy #>FPSrc3
	jsr StoreFr0IndXYVector
	jsr PowFrac		;compute fr0^fr1 for the fractional part. This *WILL* fail if fr0 is negative and fr0 is non-zero!
	bcs seterror
	;; here fr0 is the fractional part. This needs to go on the stack.
	jsr PushArgument
	;; Restore fr0
	ldx #<FPSrc3
	ldy #>FPSrc3
	jsr LoadFr0IndXYVector
	;; rotation done
	jsr PowInt		;compute fr0^IntegerExponent
	bcs seterrorpop
	jsr SwapAndPop		;to fr1 with the integer part, fractional part to fr0
	jsr BCDMulVector	;and multiply the two results: That is it!
	rts			;done (or error)
seterrorpop2:
	dec ArgumentStackPtr
seterrorpop:
	dec ArgumentStackPtr
seterror:			;carry is already set.
	rts
;;; *** SwapAndPop
;;; *** Move Fr0 to Fr1 and pop a value from the stack
;;; *** to fr0.
SwapAndPop:
	jsr Fr0ToFr1Vector	;to fr1 with the integer part
	jmp PopArgument		;return fractional part from HW stack
;;; *** PowFrac
;;; *** Compute fr0^fr1 by the traditional formula as
;;; *** res = exp(log(fr0)*fr1). Here fr0 is positive
;;; *** If fr1 is zero, return immediately with the result 1.0
;;; *** Returns with C=1 on overflow.
PowFrac:
	jsr TestFr1Sign
	beq oneisfine		;return 1.0 if the exponent is zero.
	jsr StoreFr1FPSrc2	
	jsr BCDLog10Vector	;take the logarithm
	bcs errval		;on error, exit immediately. This happens if the argument is zero or negative, as intended!
	jsr LoadFr1FPSrc2	;restore fr1
	jsr BCDMulVector	;this could potentially overflow (which is ok)
	bcs exit
	jsr BCDPow10Vector	;and raise 10 to the power of it (may also overflow)
exit:
	rts
errval:
	Error ValueError
;;; *** OneIsFine
;;; *** Store one in fr0, return with C=0 to indicate that
;;; *** this is the correct result.
oneisfine:
	jsr OneToFr0
exitok:	
	clc
	rts
;;; *** PowInt
;;; *** Compute fr0 to the power of IntegerExponent
;;; *** return with C=1 on overflow.
PowInt:	
	lda IntegerExponent+1	;non-zero?
	bne nontrivial
	ldy IntegerExponent	;zero exponent?
	beq oneisfine		;return 1.0 if the exponent is zero
notzero:	
	dey			;if one, so return the argument
	beq exitok
nontrivial:	
	lsr IntegerExponent+1	;divide the exponent by two
	ror IntegerExponent
	php			;keep the even/odd flag
	jsr PushArgument	;push fr0 onto the stack for later use
	jsr PowInt
	bcs popexit		;on error, abort
	jsr SquareFr0		;compute x^2n = x^n * x^n
	bcs popexit
	plp
	bcc even
	jsr SwapAndPop		;move to fr1, temp from stack
	;; here odd: fr0 is x, fr1 is x^2n, so multiply
	jmp BCDMulVector	;then that is all, carry over the result
even:				;here the final result is already in fr0
	dec ArgumentStackPtr	;no need to get the result from the argument stack
	rts			;done, carry is clear anyhow
popexit:
	;; clean up the argument stack and the CPU stack
	dec ArgumentStackPtr
	plp
	sec			;an error
	rts
.endproc
;;; *** MinusOneToFr0
;;; *** Place a -1.0 in fr0
	.global MinusOneToFr0
.proc	MinusOneToFr0
	lda #$c0		;exponent of -1
	Skip2
	;; runs into the following
.endproc
;;; *** OneToFr0
;;; *** Place a 1.0 in fr0
	.global OneToFr0
.proc 	OneToFr0
	lda #$40
	ldy #1			;mantissa
	;; runs into the following
.endproc
;;; *** SetExponentMantissaOfFr0
;;; *** Push a floating point number to the argument
;;; *** stack whose exponent is in A and whose mantissa
;;; *** is in Y. The rest is all zero.
;;; *** Must return with Z=1
	.global SetExponentMantissaOfFr0
.proc	SetExponentMantissaOfFr0
	sta fr0
	sty fr0+1
	ldy #4			;rest of the fr0 register
	ldx #fr0+2
	jmp ZeroRgsVector
.endproc
;;; *** Fr1ToFr0
;;; *** Move Register fr1 to register fr0
	.global Fr1ToFr0
.proc	Fr1ToFr0
	ldx #<fr1
	ldy #>fr1
	jmp LoadFr0IndXYVector	;transport back
.endproc
;;; *** StoreFr0FPSrc
;;; *** Store Fr0 in the page 5 temporary in FPSrc
.proc	StoreFr0FPSrc
	ldx #<FPSrc
	ldy #>FPSrc
	jmp StoreFr0IndXYVector
.endproc
;;; *** LoadFr1FPSrc
;;; *** LoadFr1 from the page 5 temporary in FPSrc
.proc	LoadFr1FPSrc
	ldx #<FPSrc
	ldy #>FPSrc
	jmp LoadFr1IndXYVector
.endproc
;;; *** StoreFr1FPSrc2
;;; *** copy fr1 to FPSrc2, a backup location
.proc	StoreFr1FPSrc2
	ldx #5
pushl:
	lda fr1,x
	sta FPSrc2,x
	dex
	bpl pushl
	rts
.endproc
;;; *** LoadFr1FPSrc2
;;; *** restore fr1 from the backup location
.proc	LoadFr1FPSrc2
	ldx #<FPSrc2
	ldy #>FPSrc2
	jmp LoadFr1IndXYVector	;restore fr1
.endproc
;;; *** BCDArcTan (ATAN in Atari Basic)
;;; *** Compute the arc tanget of the value in fr0
;;; *** return with C=1 in case of error.
	.global BCDArcTan
.proc	BCDArcTan
	lda #0
	sta SignFlag
	;; check the absolute value of the argument
	;; if > 1.0, compute the argtan of the inverse
	lda fr0
	and #$7f
	cmp #$40		;larger than 1.0?
	bcc small		;here small: Use the series approximation
	tax			;keep without the sign
	lda fr0
	and #$80		;keep the sign
	ora #$40		;indicate the transformation
	sta SignFlag		;here
	stx fr0			;store absolute value
	;; now invert. THOR FIXME: why not 1.0 precisely?
	ldx #<NearOneVector
	ldy #>NearOneVector
	jsr BCDFractVector	;compute (x-1)/(x+1)
	bcs exit
	;; is now in range
small:	
	jsr StoreFr0FPSrc	;keep for a while
	jsr SquareFr0		;compute x^2
	;; cannot overflow, is bounded
	lda #11			;this is the polynomial order (too high!)
	ldx #<AtnPolyVector
	ldy #>AtnPolyVector	;the coefficients of the polynomial
	jsr EvalPolyVector	;evaluate the polynomial
	;; cannot overflow, is bounded
	jsr LoadFr1FPSrc	;restore Fr1 back
	jsr BCDMulVector	;is an odd polynomial
	;; cannot overflow, is bounded
	bit SignFlag		;was this inverted?
	bvc isfine
	;; here: Use the functional equation of atan to evaluate outside of |x|<1
	ldx #<PiOver4Vector
	ldy #>PiOver4Vector
	jsr LoadFr1IndXYVector
	jsr BCDAddVector	;add up
	;; since ATAN is bounded, this cannot overflow
	lda SignFlag
	and #$80		;get the sign flag
	ora fr0
	sta fr0			;restore the sign
isfine:
	;; here convert from radiants to degrees
	lda RadFlag
	beq israd
	ldx #<RadToDeg
	ldy #>RadToDeg
	jsr LoadFr1IndXYVector
	jsr BCDMulVector	;atari Basic divided here (stupid idea)
	lda fr0
	and #$7f
	eor #$40		;is the result 90 degrees or -90?
	bne israd
	lda fr0+1
	eor #$90
	bne israd
	sta fr0+5		;round down to 90 sharply
israd:
exit:
	rts
.endproc
;;; *** BCDSin (SIN in Atari Basic)
;;; *** Compute the sin of fr0
;;; *** Return with C=1 in case of error
	.global BCDSin
.proc	BCDSin
	lda #4			;flag for sin(+x)
	bit fr0			;positive?
	bpl compute
	lda #2			;flag for sin(-x)
compute:
	Skip2
	;; Runs into the following
.endproc
;;; *** BCDCos (COS in Atari Basic)
;;; *** Compute the cosine of fr0
	.global BCDCos
.proc	BCDCos
	lda #1			;skipped over. Flag for cos
	sta SignFlag		;keep the sign
	lda fr0
	and #$7f
	sta fr0			;compute the absolute value
	;; now reduce to the period of sin/cos by multiplying with 2/Pi for radiants or 2/180 for degrees
	lda #<PiHalf
	clc
	adc RadFlag
	tax
	ldy #>PiHalf
	;; hopefully, no carry possible here!
	jsr LoadFr1IndXYVector
	jsr BCDDivVector	;reduce quarter period to 1
	bcs exit		;on error
	;; now get the quadrant of the argument: [0..1] is first, [1..2] is second, [2..3] is third, [3..4] is last
	lda fr0
	and #$7f		;absolute value
	sec
	sbc #$40		;exponent of one
	bcc small		;first quadrant if below 1
	cmp #4			;check whether we have a chance to even find the quadrant
	bcs exit		;if above that, no chance whatsoever, complete loss of precision -> error
	tax
	lda fr0+1,x		;get the digits that forms the quadrant
	;; we now need to compute the remainer when divided by four.
	sta TransformFlag	;keep it
	and #$10		;is the tenth digit even or odd?
	beq evenoctant
	lda #2			;otherwise odd
evenoctant:			;carry is clear here
	adc TransformFlag
	;; cannot overflow due to BCD arithmetic
	and #3
	adc SignFlag		;compute the remainder now
	sta SignFlag
	;; now remove the irrelevant digits upfront the decimal point
	lda #0
clrl:
	sta fr0+1,x		;next digit
	dex
	bpl clrl		;up to, but not including the exponent
	;; number is now not normalized
	jsr NormalizeVector	;remove leading zeros
small:
	;; now we have reduced the argument to [-1..1]
	;; check whether we have have an odd remainder
	lsr SignFlag
	bcc even
	jsr Fr0ToFr1Vector
	jsr OneToFr0
	jsr BCDSubVector	;compute 1.0 - X, i.e. use symmetry
even:
	jsr StoreFr0FPSrc	;store temporary
	;; approximate by an odd polynomial
	jsr SquareFr0		;this cannot overflow: Compute x^2
	lda #6
	ldx #<SinPolynomial
	ldy #>SinPolynomial
	jsr EvalPolyVector	;Polynomial approximation again
	;; cannot overflow
	jsr LoadFr1FPSrc	;one multiplication by X missing
	jsr BCDMulVector	;again bounded, no overflow
	;; check again the quadrant. Requires possibly an inversion
	lsr SignFlag
	bcc exit
	jsr InvertSign		;apply point-symmetric extension
	clc			;no error, still!
exit:
	rts
.endproc
;;; *** BCDSqrt (SQRT in Atari Basic)
;;; *** This is an (all-new, much faster square root algorithm)
	.global BCDSqrt
.proc	BCDSqrt
	jsr TestFr0Sign
	beq zero		;zero gives zero
	sec			;negative?
	bmi error		;if so, fail
	lda fr0
	sbc #$40		;correct bias
	sta eexp		;store exponent
	ldy #0
	ldx #4
	;; now layout the registers such that the source
	;; integer bits go into the LSBs of fr1 and the
	;; rest into fr2. Clear fr0 for the result
clloop:
	lda fr0+1,x		;get the mantissa of the input
	sta fr2-1,x		;store in the LSBs of fr1 and the rest of fr2
	sty fr1,x		;clear up the leading digits of fr1
	sty fr0+1,x		;clear up fr0
	dex
	bpl clloop
	sty fr2+4		;clear up the rest of fr2
	sty fr2+5		;ditto
	;; setup the number of digits to compute. Typically 9, though 10 if
	;; the exponent is odd. This also compensates for the additional
	;; one-digit shift
	ldx #9
	lsr eexp		;exponent of the result
	bcc even
	inx			;one additional digit
even:	
	stx digrt		;keep as digit shift
	sed
sqrtloop:
	jsr StoreFr1FPSrc2	;make a backup of the integer part
	clc
	jsr SubtractFr0		;subtract y+1
	bcc toomuch		;tried one square too much
	;; carry is set
	jsr SubtractFr0		;subtract 2y+1: Note that the sum of odd numbers gives squares
	bcc toomuch
	;; here subtraction succeeded, add up one digit to the mantissa
	;; carry is set
	ldx #5
addloop:
	lda fr0,x
	adc #$00
	sta fr0,x
	dex
	bne addloop
	beq sqrtloop		;done, try the next larger square
toomuch:			;here the last square was large enough
	dec digrt		;generated one additional digit
	beq done		;if done, just fill in the exponent
	jsr LoadFr1FPSrc2	;restore the mantissa
	;; now upshift fr1,fr2 by two digits
	;; and fr0 by one digit. This moves the next digit
	;; into the computing position
	ldx #0
up1:	lda fr1+1,x
	sta fr1,x
	inx
	cpx #11			;this includes fr2
	bcc up1
	;; now mantissa * 10
	jsr Fr0TimesTenVector	;there is a mathpack function for that
	lda #0
	sta fr2+5		;shift in zeros
	beq sqrtloop		;go for the next digit
done:
	cld
	;; carry should be clear here.
	lda eexp
	adc #$40		;add offset
	and #$7f
	sta fr0
zero:	
	jsr NormalizeVector	;and fixup the exponent (should not be necessary)
error:
	;; carry is already set
	rts
.endproc
;;; *** SubtractFr0
;;; *** subract fr0 from fr1. Carry may be set or clear to
;;; *** subtract an additional one
.proc	SubtractFr0
	ldx #5
slp:
	lda fr1,x
	sbc fr0,x
	sta fr1,x
	dex
	bne slp
	rts
.endproc
;;; *** FixedBCDToASCII
;;; *** Convert fr0 to ASCII, masking signed zeros
	.global FixedBCDToAscii
.proc	FixedBCDToAscii
	jsr TestFr0Sign
	bne plain
	sta fr0			;zero out the sign
plain:
	jmp BCDToAsciiVector
.endproc
	

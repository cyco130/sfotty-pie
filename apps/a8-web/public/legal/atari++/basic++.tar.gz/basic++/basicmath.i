;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicmath.i,v 1.7 2015/11/22 11:05:35 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Math support functions				**
;;; **********************************************************************

IntegerExponent		=	$99	;also used as integer exponent (new here)
PowError		=	$9b	;also used as error indicator in POW
RadFlag			=	$fb 	;the DEG/RAD switch (RADFLG in Atari Basic)
SignFlag		=	$f0	;the sign of the arc tangent (uses fchflg of the mathpack, SIGNFLAG in Atari Basic)
TransformFlag		=	$f1	;additional inversion of atan (uses digrt of the mathpack, XFMFLG in Atari Basic)

FPSrc			=	$5e6	;a floating point store (FPSRC in Atari Basic)
FPSrc2			=	$5ec	;a second floating point store (new here)
FPSrc3			=	$5f2	;a third buffer location (new here)

	.global ConvertBCDToInt
	.global AddNumeric
	.global SubtractNumeric
	.global MultiplyNumeric
	.global DivideNumeric
	.global	InvertSign
	.global BCDFloor
	.global BCDPowMain
	.global MinusOneToFr0
	.global OneToFr0
	.global Fr1ToFr0
	.global SetExponentMantissaOfFr0
	.global BCDArcTan
	.global BCDSin
	.global BCDCos
	.global BCDSqrt
	.global FixedBCDToAscii
	

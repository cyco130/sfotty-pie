;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicmemory.asm,v 1.13 2017/01/18 21:47:42 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   Memory allocation and memory copy		**
;;; **********************************************************************

	.include "basicmacros.i"
	.include "basicmemory.i"
	.include "basicerror.i"
	.include "basicstack.i"
	.include "reset.i"

	.segment "BasMain"

;;; *** EnlargeRunStack (REXPAN in Atari Basic)
;;; *** Enlarge the run stack by A bytes
	.global EnlargeRunStack
.proc	EnlargeRunStack
	jsr SaveStackPtr	;keep the current stack position
	ldx #HiMem		;and enlarge himem by this number
	;; runs into the following
.endproc
;;; *** AllocMemLow
;;; *** Allocate for the table starting at X Y bytes (EXPLOW in Atari Basic)
;;; *** The newly allocated area is returned in AllocMemPtr,AllocMemPtr+1
	.global AllocMemLow
.proc	AllocMemLow
	lda #0			;set the high-byte to zero
	;; runs into the following
.endproc
;;; *** AllocMem
;;; *** Allocate for the table starting at X (A,Y) bytes, where A is high and Y is low (EXPAND in Atari Basic)
;;; *** The newly allocated area is returned in AllocMemPtr,AllocMemPtr+1
	.global AllocMem
.proc	AllocMem
	sty AllocSize		;keep the size
	sta AllocSize+1
	;; test whether there is enough memory to satisfy the allocation
	clc
	lda HiMem
	adc AllocSize
	tay			;new basic memory end
	lda HiMem+1
	adc AllocSize+1
	bcs overrun
	cpy MemTop
	sbc MemTop+1
	bcc fits
overrun:
	Error BasicOutOfMemory
fits:
	adc MemTop+1
	;; Reserve already the memory
	sty AppMemHi
	sta AppMemHi+1
	;; compute the number of bytes to move: Everything between the table and the end of the basic area
	cpx #ArrayTablePtr	;if we're only manipulating the array values, acceptable
	bcs consistent
	inc LoadFlag		;memory gets inconsistent now
consistent:
	sec
	lda HiMem
	sbc 0,x
	sta MoveSize
	lda HiMem+1
	sbc 1,x
	sta MoveSize+1

	;; A contains now the number of pages to move
	;; Compute the start of the memory move. We must be copying from the end
	;; to the beginning to avoid overwriting stuff
	clc
	adc 1,x
	sta MoveSourcePtr+1
	;; this hopefully keeps the carry cleared!
	lda 0,x
	sta AllocMemPtr		;old area start is what we just allocated
	;; this ensures that MoveSourcePtr(lo,hi) + MoveSize(lo) = old HiMem. The MoveSize(lo) comes from the index register in the move.
	sta MoveSourcePtr
	adc AllocSize
	sta MoveDestPtr
	
	lda 1,x
	sta AllocMemPtr+1	;high-byte of the freshly allocated area
	adc AllocSize+1		;plus carry gives MouseDestPtr = MoveSourcePtr + AllocSize
	;; hopefully keeps the carry cleared, no overflow
	adc MoveSize+1		;to the end of the area
	sta MoveDestPtr+1	;is the destination
	;;
	;; at this point:
	;; AllocMemPtr is the pointer to the start of the newly available area 
	;; AllocSize is the size of bytes made available
	;; MoveSize is the total size of the area to be moved along
	;; MoveSourcePtr + MoveSize points behind the first byte to be read on the copy
	;; MoveDestPtr + MoveSize points behind the first byte to be written to on the copy

	;; now adjust the pointers.
adjustloop:
	;; hopefully no overflow here
	lda 0,x
	adc AllocSize
	sta 0,x
	lda 1,x
	adc AllocSize+1
	sta 1,x
	inx
	inx
	cpx #HiMem+2
	bcc adjustloop

	;; Variables adjusted now. Perform now the copy
	ldx MoveSize+1		;high-byte, number of bytes to copy
	inx			;+1
	ldy MoveSize		;low-byte
	bne movestart		;note that our move pointers point behind the end of the data
	beq nextpage
copypageloop:
	dec MoveSourcePtr+1
	dec MoveDestPtr+1
	dey			;y was zero, start with offset 255
copyloop:
	lda (MoveSourcePtr),y
	sta (MoveDestPtr),y
movestart:
	dey
	bne copyloop
	;; and the last byte
	lda (MoveSourcePtr),y
	sta (MoveDestPtr),y
nextpage:
	dex			;advance to the next page (if any)
	bne copypageloop
	stx LoadFlag		;consistent again
	rts
.endproc
;;; FreeMemLow (Atari Basic calls this CONTLOW)
;;; *** Release Y bytes for the table at offset X
	.global FreeMemLow
.proc	FreeMemLow
	lda #0			;high-byte is zero
	;; runs into the following
.endproc
;;; FreeMem (Atari Basic calls this CONTRACT)
;;; *** Release (Y,A) bytes from the table at offset X
	.global FreeMem
.proc	FreeMem
	sty AllocSize
	sta AllocSize+1
	cpx #ArrayTablePtr
	bcs consistent
	stx LoadFlag		;pointers get inconsistent now
consistent:	
	;; compute number of bytes to move
	;; Note that we move upwards, so the first byte to move
	;; will be indexed by MoveSourcePtr + y, where y counts up to 256
	sec
	lda HiMem
	sbc 0,x			;low byte
	sta MoveSize		;
	lda HiMem+1
	sbc 1,x
	sta MoveSize+1
	;; Compute the source of the move: the current address.
	;; C=1 here hopefully.
	lda 0,x
	sta MoveSourcePtr
	lda 1,x
	sta MoveSourcePtr+1
	
	txa
	pha			;keep for a while
	;; adjust now all the pointers
adjustloop:
	sec
	lda 0,x
	sbc AllocSize
	sta 0,x
	lda 1,x
	sbc AllocSize+1
	sta 1,x
	inx
	inx
	cpx #HiMem+2
	bcc adjustloop
	;; tell the os what we need
	sta AppMemHi+1
	lda HiMem
	sta AppMemHi
	;; restore the index
	pla
	tax
.endproc
;;; *** FastMemoryCopy (FMOVER in Atari Basic)
;;; *** Move memory from MoveSourcePtr to 00,x, MoveSize bytes
;;; *** The destination of the move is in register X.
	.global FastMemoryCopy
.proc	FastMemoryCopy
	;; compute now the source of the region
	;; Note that we add low of MoveSize as index register to it,
	;; so subtract it now.
	sec
	lda #0
	sbc MoveSize
	sta MoveSize		;compute two's complement
	sec			;correct for the adjustment
	lda MoveSourcePtr	;due to the Y register offset.
	sbc MoveSize
	sta MoveSourcePtr
	lda MoveSourcePtr+1
	sbc #0
	sta MoveSourcePtr+1
	;; C is set (hopefully!)
	lda 0,x
	sbc MoveSize		;also subtract the first index
	sta MoveDestPtr
	lda 1,x
	sbc #0
	sta MoveDestPtr+1

	ldx MoveSize+1
	inx
	ldy MoveSize
	;; here Y is a multiple of 256. However, the carry was not carried over to
	;; the high-byte and hence source and destination pointers do not require
	;; an initial increment by 256.
	beq nextpage
copyloop:
	lda (MoveSourcePtr),y
	sta (MoveDestPtr),y
	iny			;copy in increasing direction
	bne copyloop
	inc MoveSourcePtr+1
	inc MoveDestPtr+1
nextpage:
	dex
	bne copyloop
done:	
	stx LoadFlag		;is now consistent again
	rts
.endproc

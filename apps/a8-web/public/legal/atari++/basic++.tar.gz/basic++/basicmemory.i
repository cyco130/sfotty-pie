;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicmemory.i,v 1.6 2015/09/06 08:11:44 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Memory allocation and memory copy		**
;;; **********************************************************************

	;; memory layout
	
LoMem			=	$80 	;start of the basic memory area
VarNamePtr		=	$82	;pointer to the table containing the variable names (VNTP in Atari Basic)
VarNameEndPtr		=	$84	;pointer to the end of the variable names (VNTD in Atari basic)
VarValuePtr		=	$86	;pointer to variable values and pointers (VVTP in Atari Basic)
StatementPtr		=	$88	;pointer to tokenized statements (STMTAB in Atari basic)
CurrentLinePtr		=	$8a	;pointer to the current line (STMCUR in Atari Basic)
ArrayTablePtr		=	$8c	;pointer to the values of the strings and arrays (STARP in Atari Basic)
RunStack		=	$8e	;pointer to the top of the run stack
HiMem			=	$90	;end of basic area (MEMTOP in Atari basic)
	
	;; for the memory allocator
AllocMemPtr		=	$97 	;source pointer for a memory move (SVESA in Atari Basic)
MoveSourcePtr		=	$99 	;pointer to start the move from (MVFA in Atari Basic)
MoveDestPtr		=	$9b	;pointer to the target of the move (MVTA in Atari Basic)
MoveSize		=	$a2 	;number of bytes to copy in a specific area (MVLNG in Atari Basic)
AllocSize		=	$a4 	;size of a memory allocation (ECSIZE in Atari Basic)
LoadFlag		=	$ca	;if this flag is set, then loading or memory move is in progress

	.global EnlargeRunStack
	.global AllocMemLow
	.global AllocMem
	.global ShrinkRunStack
	.global FreeMemLow
	.global FreeMem
	.global FastMemoryCopy

;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicoperators.asm,v 1.44 2017/04/15 16:28:12 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   Implementation of Basic Operators		**
;;; **********************************************************************

	.include "basicmacros.i"
	.include "basicoperators.i"
	.include "basicerror.i"
	.include "basicmath.i"
	.include "basicexpression.i"
	.include "basicmemory.i"
	.include "mathpack.i"
	.include "constants.i"
	.include "nmi.i"
	.include "reset.i"
	.include "pokey.i"
	
	.segment "BasMain"
	
;;; *** EvaluateLessOrEqual (XPLE in Atari Basic)
;;; *** Evaluate the <= operation
	.global EvaluateLessOrEqual
.proc	EvaluateLessOrEqual
	jsr CompareOperator
	bmi EvaluateToTrue
	beq EvaluateToTrue
	bpl EvaluateToFalse
.endproc
;;; *** EvaluateNotEqual (XPNE in Atari Basic)
;;; *** Evaluate the <> operator
	.global EvaluateNotEqual
.proc	EvaluateNotEqual
	jsr CompareOperator
	beq EvaluateToFalse
	bne EvaluateToTrue
.endproc
;;; *** EvaluateLessThan (XPLT in Atari Basic)
;;; *** Evaluate the < operator
	.global EvaluateLessThan
.proc	EvaluateLessThan
	jsr CompareOperator
	bmi EvaluateToTrue
	bpl EvaluateToFalse
.endproc
;;; *** EvaluateGreaterThan (XPGT in Atari Basic)
;;; *** Evaluate the > operator
	.global EvaluateGreaterThan
.proc	EvaluateGreaterThan
	jsr CompareOperator
	bmi EvaluateToFalse
	beq EvaluateToFalse
	bpl EvaluateToTrue
.endproc
;;; *** EvaluateGreaterOrEqual (XPGTE in Atari Basic)
;;; *** Evaluate the >= operator
	.global EvaluateGreaterOrEqual
.proc	EvaluateGreaterOrEqual
	jsr CompareOperator
	bmi EvaluateToFalse
	bpl EvaluateToTrue
.endproc
;;; *** EvaluateEquals (XPEQ in Atari Basic)
;;; *** Evaluate the = operator
	.global EvaluateEquals
.proc	EvaluateEquals
	jsr CompareOperator
	beq EvaluateToTrue
	bne EvaluateToFalse
.endproc
;;; *** EvaluateAnd (XPAND in Atari Basic)
;;; *** Evaluate the logical AND operator
	.global EvaluateAnd
.proc	EvaluateAnd
	jsr Pop2Arguments
	jsr TestFr0Sign
	beq EvaluateToFalse
	bne EvaluateFr1
.endproc
;;; *** EvaluateOr (XPOR in Atari Basic)
;;; *** Evaluate the logical OR operator
	.global EvaluateOr
.proc	EvaluateOr
	jsr Pop2Arguments
	jsr TestFr0Sign
	bne EvaluateToTrue
	;; runs into the following
.endproc
;;; *** EvalutateFr1
;;; *** Test only the value of fr1
.proc	EvaluateFr1
	jsr TestFr1Sign
	bne EvaluateToTrue
	beq EvaluateToFalse
.endproc
;;; *** EvaluateSGN (XPSGN in Atari Basic)
;;; *** Evaluate the SGN function
	.global EvaluateSGN
.proc	EvaluateSGN
	jsr PopArgument
	jsr TestFr0Sign
	bmi EvaluateToMinusOne
	bne EvaluateToTrue
	beq EvaluateToFalse
.endproc
;;; *** EvaluateNot (XPNOT in Atari Basic)
;;; *** Evaluate the logical NOT operator
	.global EvaluateNot
.proc	EvaluateNot
	jsr PopArgument
	jsr TestFr0Sign
	beq EvaluateToTrue
	;; runs into the following
.endproc
;;; *** EvaluateToFalse (XFALSE in Atari Basic)
;;; *** Place a 0.0 on the argument stack
.proc	EvaluateToFalse
	jsr ZeroFr0Vector
	beq GoPush
.endproc
;;; *** EvaluateToMinusOne (required by the SGN operator)
;;; *** Return a -1.0 on the argument stack
.proc	EvaluateToMinusOne
	jsr MinusOneToFr0
	beq GoPush
.endproc
;;; *** EvaluateToTrue (XTRUE in Atari Basic)
;;; *** Place a 1.0 on the argument stack
.proc 	EvaluateToTrue
	jsr OneToFr0
	beq GoPush
.endproc
;;; *** EvaluateABS (XPABS in Atari Basic)
;;; *** Compute the absolute value of a number
	.global EvaluateABS
.proc	EvaluateABS
	jsr PopArgument
	lda fr0
	and #$7f
	sta fr0
	;; runs into the followning
.endproc
;;; *** GoPush
;;; *** Push fr0 to the argument stack
.proc	GoPush
	jmp PushBCD
.endproc
;;; *** EvaluatePlus (XPPLUS in Atari Basic)
;;; *** Evaluate the + operator
	.global EvaluatePlus
.proc	EvaluatePlus
	jsr Pop2Arguments
	jsr AddNumeric
	bcc GoPush
.endproc
;;; *** EvaluateMinus (XPMINUS in Atari Basic)
;;; *** Evaluate the - operator
	.global EvaluateMinus
.proc	EvaluateMinus
	jsr Pop2Arguments
	jsr SubtractNumeric
	bcc GoPush
.endproc
;;; *** EvaluateMultiply (XPMUL in Atari Basic)
;;; *** Evaluate the * operator
	.global EvaluateMultiply
.proc	EvaluateMultiply
	jsr Pop2Arguments
	jsr MultiplyNumeric
	bcc GoPush
.endproc
;;; *** EvaluateDivide (XPDIV in Atari Basic)
;;; *** Evaluate the / operator
	.global EvaluateDivide
.proc	EvaluateDivide
	jsr Pop2Arguments
	jsr DivideNumeric
	bcc GoPush
.endproc
;;; *** EvaluateUnaryMinus (XPUMINUS in Atari Basic)
;;; *** Evaluate the - sign as unary operator
	.global EvaluateUnaryMinus
.proc	EvaluateUnaryMinus
	jsr PopArgument
	jsr InvertSign
	jmp PushBCD
.endproc
;;; *** EvaluateStringAssignment (XSASSN in Atari Basic)
;;; *** Evaluate the = sign in its role of the assignment
;;; *** operator
	.global EvaluateStringAssignment
.proc	EvaluateStringAssignment
	jsr PopStringAbsolute	;first get the string address as an absolute value. This is the right hand side

	lda VariablePointer
	sta MoveSourcePtr
	lda VariablePointer+1
	sta MoveSourcePtr+1
	lda StringLength
	sta MoveSize
	lda StringLength+1
	sta MoveSize+1
	;;
	ldy OperatorStackPtr	;empty operator stack?
	beq haveboth		;if so, we also have the left hand on the stack
	;; here we don't.
	jsr SetAssignFlag
	jsr ContinueEvaluation
	;; now get the left hand size
	ldy StringLength	;target size, evaluated last by the bracket on the left
	ldx StringLength+1
	rol AssignFlag		;got an index on the left?
	bcs havesize		;if so, the size is already computed, otherwise...
haveboth:			;pop the destination off the stack
	jsr PopStringAbsolute
	ldy StringDimension
	ldx StringDimension+1
havesize:	
	;; now potentially clamp the size of bytes to be moved
	cpy MoveSize
	txa
	sbc MoveSize+1
	bcs noclamp
clamp:
	sty MoveSize
 	stx MoveSize+1
noclamp:
	;; number of bytes to move is set
	;; source of the move is set, target
	;; is in the variable pointer of the
	;; left-hand size
	ldx #VariablePointer
	jsr FastMemoryCopy	; performs the copy
	;;
	;; Potentially adjust the length of the destination
	;; string now. This is given by the last byte
	;; set by the copy if we made the size explicit.
	lda VariableIndex
	jsr GetVariable		;load it again
	jsr GetStringAddress
	;; compute the size of the move.
	;; Note that the move leaves the end address +1
	;; in movedest
	sec
	lda MoveDestPtr
	sbc VariablePointer	;get the low displacement
	tay			;to Y
	lda MoveDestPtr+1
	sbc VariablePointer+1	;and the high-displacement
	tax
	;; check whether there was a comma in the destination
	lda #2			;note that the comma count was rotated in here....
	bit AssignFlag
	beq setlength		;if not, set the length
	;; here the comma was given, so only a substring was
	;; assigned. Set the length only in case the string
	;; grew
	;; otherwise, only set the length if it increased
	cpy StringLength
	txa
	sbc StringLength+1
	bcc exit		;if smaller, do nothing
setlength:
	;; here: String changed its size, install new size
	tya
	ldy #StringLength-VariableType
	sta (VarTableEntryPtr),y
	txa
	iny
	sta (VarTableEntryPtr),y
exit:
	;; runs into the following
.endproc
;;; *** ExecuteRem, (XREM in Atari Basic)
;;; *** ExecuteData, (XDATA in Atari Basic)
;;; *** Execute the REM and DATA statements. Plainly, do nothing.
	.global ExecuteRem
.proc	ExecuteRem
	;; runs into the following
.endproc
	.global ExecuteData
.proc	ExecuteData
.endproc
;;; *** EvaluateBracketOpen (XPLPRN in Atari Basic)
;;; *** This does nothing, proper processing is handled
;;; *** by priorities.
	.global EvaluateBracketOpen
.proc	EvaluateBracketOpen
	;; runs into the following
.endproc
;;; *** EvaluateUnaryPlus (XPUPLUS in Atari Basic)
;;; *** Evaluate the + sign as unary operator
	.global EvaluateUnaryPlus
.proc	EvaluateUnaryPlus
	rts  ;nothing to do here.
.endproc
;;; *** EvaluateArrayDimensionComma (XPACOM in Atari Basic)
;;; *** This here evalutes the comma in USR and in the array dimension
	.global EvaluateArrayDimensionComma
.proc	EvaluateArrayDimensionComma
	inc CommaCount		;one more
	;; runs into the following
.endproc
;;; *** EvaluateFunctionBracket (XPFLPRN in Atari Basic)
;;; *** Evaluate the left bracket of the function call
	.global EvaluateFunctionBracket
.proc	EvaluateFunctionBracket
	;; runs into the following
.endproc
;;; *** EvaluateBracketClose (XPRPRN in Atari Basic)
;;; *** Evaluate the right parenthesis
	.global EvaluateBracketClose
.proc	EvaluateBracketClose
	pla			;do not return to the caller, rather continue with the next operand directly.
	pla
	jmp ContinueEvaluation	;bracket is done, now resume what is left behind the bracket
.endproc
;;; *** EvaluateStringBracketOpen (XPSLPRN in Atari Basic)
;;; *** Evaluate the bracket open on strings used to indicate substrings
	.global EvaluateStringBracketOpen
.proc	EvaluateStringBracketOpen
	lda CommaCount		;one or two indices?
	beq onecomma
	jsr PopStringIndex	;get the second (end) index
	sta EndIndex
	sty EndIndex+1
onecomma:
	jsr PopStringIndex	;get the first index, i.e. where to start from
	sec
	sbc #1
	sta StartIndex
	tya
	sbc #0
	sta StartIndex+1	;save the start index, converted to an offset, to StartIndex
	jsr PopArgument		;get the string itself into VariableType etc.
	
	;; now test whether this is to the left or the right of an assignment and clamp accordingly
	;; for the right hand side, clamp by the length, otherwise by the dimension
	ldy StringLength+1
	lda StringLength
	bit AssignFlag
	bpl rightside		;works as an rvalue
	lda AssignFlag
	ora CommaCount
	sta AssignFlag		;keep the count here
	;; clamp by the dimension of the string
	ldy StringDimension+1	;end dimension of the string
	lda StringDimension
rightside:
	ldx CommaCount		;if no comma, then substring up to the end
	beq oneindex		;in that case, the length is already loaded
	dec CommaCount		;reset (THOR: Why?)
	;; now check whether we are beyond the edge of the string
	cmp EndIndex
	tya
	sbc EndIndex+1
	bcc lengtherror		;error if the length < end index
	;; here: end index is ok, use this as
	;; exclusive end delimiter. Otherwise, the length is already loaded.
	lda EndIndex
	ldy EndIndex+1
oneindex:
	;; compute now the length of the string to move
	sec
	sbc StartIndex
	sta StringLength	;will be the string length
	tya
	sbc StartIndex+1	;high-index
	sta StringLength+1
	bcc lengtherror		;also error if the indices are sorted incorrectly.
	;; THOR: There is actually no reason why zero-sized strings should not be allowed here....
	bit AssignFlag		;except when assigning to them...
	bpl zerook
	ora StringLength	;is the length zero?
	beq lengtherror
zerook:	
	;; Now get the address of the string to get it ready for the
	;; assignment and modify it according to the substring
	jsr GetStringAddress	;get me
	clc
	lda VariablePointer
	adc StartIndex		;add start offset
	sta VariablePointer
	lda VariablePointer+1
	adc StartIndex+1
	sta VariablePointer+1

	;; now comes the tricky part: If this is part of an assignment,
	;; let the assignment do the job and grab the data here.
	;; otherwise, we are an Rvalue and just push the computed string
	;; onto the stack
	bit AssignFlag
	bmi assign
	;; here an rvalue, back to the argument stack
	jsr PushArgument
assign:
	rts
lengtherror:
	Error StringLengthError
.endproc
	
;;; *** EvaluateStringBracketOpen (XDPSLP in Atari Basic)
;;; *** Evaluate the left bracket of the DIM of strings
;;; *** fetches the array dimensions into ztemp1,+1
	.global EvaluateDimStringBracket
.proc	EvaluateDimStringBracket
	;; runs into the following
.endproc
;;; *** EvaluateDimNumericBracketOpen (XPDLPRN in Atari Basic)
;;; *** Evaluate the evaluation of the left bracket of DIM,
;;; *** fetches the array dimensions into Index2,+1 and
;;; *** ztemp1,+1. Does not perform the array allocation.
	.global EvaluateDimNumericBracketOpen
.proc	EvaluateDimNumericBracketOpen
	;; runs into the following
.endproc
;;; *** GetArrayDimension
;;; *** pop the array dimensions from the
;;; *** stack and place them into index1,+1 and index2,+1
.proc	GetArrayDimension
	lda #0
	tay			;reset the second dimension
	cmp CommaCount		;no comma, then one-dimensional
	beq onedimensional
	;dec CommaCount		;reset
	jsr PopInteger		;get second dimension
onedimensional:
	sta Index2
	sty Index2+1		;keep the second dimension
	;; get now the first dimension
	jsr PopInteger
	sta Index1		;store in the BCD registers
	sty Index1+1

	jsr PopArgument		;get now the array itself

	;; is the array array dimensioned?
	lda VariableType
	lsr a
	eor CommaCount		;bit #0 is now comparison of comma and dimensionality
	bcc notdimmed
	;; here: it is already dimensioned. Check wether the dimension
	;; and the comma count coincide. The comma flag is now in bit #0
	lsr a
	bcs GoDimError		;if not, this is an error
	bcc continue
notdimmed:			;move the comma flag into bit #1
	asl a
	sta VariableType	;set it
continue:
	rts
.endproc
;;; *** EvaluateNumericArrayBracketOpen (XPALPRN in Atari Basic)
;;; *** Evaluate the left bracket open - array index operation
;;; *** This is also misused by DIM and COM by setting bit 6
;;; *** of the AssignFlag
	.global EvaluateNumericArrayBracketOpen
.proc	EvaluateNumericArrayBracketOpen
	lda ArgumentStackPtr	;make a backup of the argument
	pha
	bit AssignFlag
	bpl rvalue		;if not set, it's an rvalue
	;; the argument stack contains now: value, index (,index), target array
	dec ArgumentStackPtr	;remove the value temporarily
rvalue:
	jsr GetArrayDimension	;evaluate the dimension of the array

	pla			;restore the old argument stack value
	
	bit AssignFlag		;executing DIM or computing an lvalue?
	bvc regular		;not lvalue evaluation
	
	ldy ArgumentStackPtr	;in a subexpression?
	bne AssignToNumericArrayElement
	
	sta ArgumentStackPtr	;no? return with data on the stack.
	rts
regular:
	bpl AssignToNumericArrayElement	;here rvalue
	sta ArgumentStackPtr
	;; contine into the next call
.endproc
;;; *** AssignToNumericArrayElement
;;; *** Assign a value to an element of a numeric array.
;;; *** The array must be in VariableType and following, the
;;; *** first index is in Index1,+1, the second in Index2,+1
	.global AssignToNumericArrayElement
.proc	AssignToNumericArrayElement
	ror VariableType	;is it dimmed
	bcc GoDimError
	;; now check whether we are in range with the dimension
	lda Index1
	cmp FirstArrayDimension
	lda Index1+1
	sbc FirstArrayDimension+1
	bcs GoDimError		;if beyond the array bounds, error

	lda Index2
	cmp SecondArrayDimension
	lda Index2+1
	sbc SecondArrayDimension+1
	bcs GoDimError

	jsr ZTempTimesDim2	;compute the offset to the first dimension
	lda Index2
	ldy Index2+1		;add second dimension
	jsr AddToZTemp
	jsr ZTempTimes6		;and multiply by the size of a BCD variable
	;; now we have here the offset, compute from that the address. First add the
	;; relative offset of the variable
	lda VariablePointer
	ldy VariablePointer+1
	jsr AddToZTemp
	;; then add the start address of the arrays
	lda ArrayTablePtr
	ldy ArrayTablePtr+1
	jsr AddToZTemp		;now that is relative to the start address,

	;; are we assigning?
	bit AssignFlag
	bpl rvalue
	;; here this is an lvalue, i.e. we are on the left hand side of the = sign
	jsr PopArgument		;get the value to assign to
	ldx Index1
	ldy Index1+1		;store in the target space
	jmp StoreFr0IndXYVector	;the argument stack is not initialized here, but never mind
rvalue:
	;; here an rvalue: Instead compute the value, and store it on the stack
	ldx Index1
	ldy Index1+1
	jsr LoadFr0IndXYVector	;load FR0 from the array
	iny			;returns with y=-1
	sty VariableType	;is now just a number
	sty CommaCount		;reset the comma count
	jmp PushArgument	;and push back on the stack.
.endproc
GoDimError:
	Error DIMMismatch
;;; *** EvaluateSTR (XPSTR in Atari Basic)
;;; *** Computes the STR$ function
	.global EvaluateSTR
.proc	EvaluateSTR
	jsr PopArgument		;get the number on the stack
	jsr FixedBCDToAscii	;convert to ASCII
	;; now build a string from it. The address
	;; of the string is in inbuff
	;; compute the length, the last character has the MSB set
	;; Try to find a unique target location for STR such that
	;; str$(a) = str$(b) evaluates false if a != b, and str$
	;; can never be equal to chr$
	lda ArgumentStackPtr
	asl a
	asl a
	asl a
	asl a
	and #$30
	adc #$1f		;actually + $20, but we need X one less for the inx in the loop.
	tax
	stx ztemp4
	ldy #-1+256
loop:
	iny
	inx
	lda (inbuff),y
	sta outbuff,x
	bpl loop
	and #$7f		;remove the MSB, Y is now the length
	sta outbuff,x
	iny
	jsr LoadOutbuffVector	;unfortunately, the original mathpack may put inbuff somewhere else, for negative numbers...
	tya
	ldy ztemp4
	bne PushShortString	;and push back (jumps always)
.endproc
;;; *** EvaluateCHR (XPCHR in Atari Basic)
;;; *** Convert a number to its ASCII code string
	.global EvaluateCHR
.proc	EvaluateCHR
	jsr PopByte		;get the numeric value
	pha
	jsr LoadOutbuffVector
	;; compute a unique location for chr$ such that
	;; chr$(a)=chr$(b) if and only if a=b,
	;; and chr$(a) can never be equal to str$(a)
	lda ArgumentStackPtr
	and #$0f
	ora #$10
	tay
	pla
	sta outbuff,y		;save here
	lda #1			;length
	dey
	;; runs into the following
.endproc
;;; *** PushShortString (:CHR in AtariBasic)
;;; *** Push a short string at inbuff, offset Y size A
;;; *** onto the argument stack
	.global PushShortString
.proc	PushShortString
	ldx #inbuff
	jsr StringConstFromPointerAndSize
	jmp PushArgument	;done
.endproc
;;; *** EvaluateUSR (XPUSR in AtariBasic)
;;; *** run a user defined machine code
	.global EvaluateUSR
.proc	EvaluateUSR
	jsr RunUSR		;create return address on the stack, main loop
	jsr IntToBCDVector	;convert the value the function returned back to BCD
	jmp PushArgument	;and push back onto the argument stack
.endproc
;;; *** RunUSR (:USR in Atari Basic)
;;; *** the main loop of the USR function
.proc	RunUSR
	lda CommaCount		;get the number of arguments
	sta USRArgCount		;keep
pushloop:
	jsr PopInteger		;get the next integer from the argument stack
	dec USRArgCount		;the first argument (and last on stack)
	bmi jump		;is the address to jump to
	lda fr0
	pha
	lda fr0+1		;get argument and push on stack
	pha
	clc
	bcc pushloop		;continue until done
jump:				;all arguments pushed
	lda CommaCount		;now push the number of arguments
	pha
	jmp (fr0)		;and jump to the user function
.endproc
;;; *** EvaluateASC (XPASC in AtariBasic)
;;; *** get the ASCII code of the first argument of a string
	.global EvaluateASC
.proc	EvaluateASC
	jsr PopStringAbsolute	;get the string argument, convert to absolute address
	lda StringLength
	ora StringLength+1
	beq error
	ldy #0
	lda (VariablePointer),y	;get the value
	jmp PushIntegerAY	;push the result onto the argument stack
error:
	Error StringLengthError
.endproc
;;; *** EvaluateADR (XPADR in AtariBasic)
;;; *** get the absolute address of a string
	.global EvaluateADR
.proc	EvaluateADR
	jsr PopStringAbsolute
	lda VariablePointer
	ldy VariablePointer+1
	jmp PushIntegerAY	;and place it on the stack
.endproc
;;; *** EvaluateLEN (XPLEN in AtariBasic)
;;; *** compute the length of a string
	.global EvaluateLEN
.proc	EvaluateLEN
	jsr PopStringAbsolute	;fail if not dim'd
	lda StringLength
	ldy StringLength+1
	jmp PushIntegerAY
.endproc
;;; *** EvaluatePeek (XPPEEK in Atari Basic)
;;; *** Peek in memory
	.global EvaluatePeek
.proc	EvaluatePeek
	jsr PopInteger
	ldy #0			;also the high-byte
	lda (fr0),y		;get the value from memory
	jmp PushIntegerAY
.endproc
;;; *** EvaluateRND (XPRND in Atari Basic)
;;; *** Compute a random number between 0 and 1
	.global EvaluateRND
.proc	EvaluateRND
	ldx #<Const65535
	ldy #>Const65535
	jsr LoadFr1IndXYVector	;load the divisor to fr1
	jsr PopArgument		;get dummy FIXME: We could make some use of this...
	lda Random
	sta fr0+1
	lda Random
	sta fr0
	jsr IntToBCDVector	;convert from integer to float
	jsr BCDDivVector	;divide (basic uses savety net here, but there cannot be an error)
	jmp PushBCD
.endproc
;;; *** EvaluateFRE (XPFRE in Atari Basic)
;;; *** Return the number of free bytes
	.global EvaluateFRE
.proc	EvaluateFRE
	jsr PopArgument		;pop dummy argument
	sec
	lda MemTop
	sbc HiMem
	sta fr0
	lda MemTop+1
	sbc HiMem+1
	sta fr0+1
	jmp PushInteger
.endproc
;;; *** EvaluatePADDLE (XPPDL in Atari Basic)
;;; *** Return the paddle position of the paddle
;;; *** given by the argument
	.global EvaluatePADDLE
.proc	EvaluatePADDLE
	lda #Paddle0-Paddle0	;this is the offset from the page 2 shadow registers
	Skip2
	;; runs into the following
.endproc
;;; *** EvaluateSTICK (XPSTICK in Atari Basic)
;;; *** Return the joystick position given by the argument
	.global EvaluateSTICK
.proc	EvaluateSTICK
	lda #Stick0-Paddle0
	Skip2
	;; runs into the following
.endproc
;;; *** EvaluatePTRIG (XPPTRIG in Atari Basic)
;;; *** Return the status of the paddle button(s)
	.global EvaluatePTRIG
.proc	EvaluatePTRIG
	lda #PTrig0-Paddle0
	Skip2
	;; runs into the following
.endproc
;;; *** EvaluateSTRIG (XPSTRIG in Atari Basic)
;;; *** Return the status of the joystick button
	.global EvaluateSTRIG
.proc	EvaluateSTRIG
	lda #Strig0-Paddle0
	pha			;keep the offset
	jsr PopByte
	;; get the offset. Funny enough, there is only little argument
	;; testing here **FIXME**
	;; should really test the low-byte as well
	pla
	clc
	adc fr0
	tax
	lda Paddle0,x
	ldy #0			;high-byte
	jmp PushIntegerAY
causeerrval:
	Error ValueError
.endproc
;;; *** EvaluateVAL (XPVAL in AtariBasic)
;;; *** convert a sting to a number if possible
	.global EvaluateVAL
.proc	EvaluateVAL
	jsr AppendEOL		;append an EOL to the string
	lda #0
	sta cix			;start converting at the beginning
	jsr AsciiToBCDVector	;and convert
	bcc GoPushBCD		;if valid, push the argument
	Error StringNotNumeric
.endproc
;;; *** EvaluateINT (XPINT in Atari Basic)
;;; *** round the argument to the next integer
	.global EvaluateINT
.proc	EvaluateINT
	jsr PopArgument
	jsr BCDFloor
	bcs GoValueError
	bcc GoPushBCD
.endproc
;;; *** EvaluateEXP (XPEXP in Atari Basic)
;;; *** Compute the exponential function
	.global EvaluateEXP
.proc	EvaluateEXP
	jsr PopArgument
	jsr BCDExpVector
	bcs GoValueError
	bcc GoPushBCD
.endproc
;;; *** EvaluateLOG (XPLOG in Atari Basic)
;;; *** Compute the natural logarithm
	.global EvaluateLOG
.proc	EvaluateLOG
	jsr PopArgument
	jsr TestForOne
	beq GoPushBCD
	jsr BCDLogVector
	bcs GoValueError
	bcc GoPushBCD
.endproc
;;; *** EvaluateCLOG (XPL10 in Atari Basic)
;;; *** Compute the logarithm to the base of ten
	.global EvaluateCLOG
.proc	EvaluateCLOG
	jsr PopArgument
	jsr TestForOne
	beq GoPushBCD
	jsr BCDLog10Vector
	bcs GoValueError
	bcc GoPushBCD
.endproc
;;; *** EvaluateSQR (XPSQR in Atari Basic)
;;; *** Compute the square root function
	.global EvaluateSQR
.proc	EvaluateSQR
	jsr PopArgument
	jsr BCDSqrt
	bcs GoValueError
	bcc GoPushBCD
.endproc
;;; *** EvaluateSIN (XPSIN in Atari Basic)
;;; *** Compute the sin of the argument
	.global EvaluateSIN
.proc	EvaluateSIN
	jsr PopArgument
	jsr BCDSin
	bcs GoValueError
	bcc GoPushBCD
.endproc
;;; *** EvaluateCOS (XPCOS in Atari Basic)
;;; *** compute the cosine of the argument
	.global EvaluateCOS
.proc	EvaluateCOS
	jsr PopArgument
	jsr BCDCos
	bcs GoValueError
	bcc GoPushBCD
.endproc
;;; *** EvaluateATN (XPATN in Atari Basic)
;;; *** compute the arctangent of the argument
	.global EvaluateATN
.proc	EvaluateATN
	jsr PopArgument
	jsr BCDArcTan
	bcs GoValueError
	;; runs into the following
.endproc
;;; *** GoPushBCD a direct jump to PushBCD
.proc	GoPushBCD
	jmp PushBCD
.endproc
;;; *** GoValueError a direct jump to generate the value error
.proc	GoValueError
	Error ValueError
.endproc
;;; *** EvaluatePower (XPPOWER in Atari Basic)
;;; *** Evaluate A^B, i.e. the power function
	.global EvaluatePower
.proc	EvaluatePower
	jsr Pop2Arguments	;get the base into fr0, the exponent into fr1
	;; here the base is zero
	jsr TestFr1Sign		;test the sign of the exponent
	beq returnone		;x^0 is always zero, including 0^0
	php
	jsr TestFr0Sign		;is the base zero
	bne nonzero
	;; here the base is zero
	plp			;is the exponent zero? If so, set 0^0 = 1 (a convention) ;
	bpl GoPushBCD		;if positive, return zero (is already in fr0)
	bmi GoValueError	;if negative, this is an error
returnone:
	jmp EvaluateToTrue	;is 1.0 then
returnzero:
	jmp EvaluateToFalse	;is 0.0 then
nonzero:			;here the base is non-zero
	plp			;positive or negative?
	bpl ispositive
	lda fr1
	and #$7f		;compute the absolute value of the exponent
	sta fr1
	jsr BCDPowMain		;compute with positive exponent
	bcs returnzero		;if overflow, return 0.0 
	;; result is in fr0
	jsr Fr0ToFr1Vector	;move to fr1
	jsr OneToFr0		;1.0 -> fr0
	jsr DivideNumeric	;compute 1.0 / result
	bcc GoPushBCD
ispositive:
	jsr BCDPowMain		;evaluate the main result
	bcs GoValueError	;on overflow, return an error
	bcc GoPushBCD		;otherwise, return the result
.endproc
;;; *** TestForOne
;;; *** Test whether the BCD number in fr0 is 1.0. If so,
;;; *** set it to zero and return with Z=1. Otherwise,
;;; *** return with Z=0.
.proc	TestForOne
	lda fr0
	cmp #$40
	bne notone
	lda fr0+1
	eor #$01
	ora fr0+2
	ora fr0+3
	ora fr0+4
	ora fr0+5
	bne notone
	sta fr0
	sta fr0+1
notone:
	rts
.endproc
	

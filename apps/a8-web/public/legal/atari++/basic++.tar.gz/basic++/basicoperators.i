;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicoperators.i,v 1.6 2015/11/27 21:37:17 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   Implementation of Basic Operators		**
;;; **********************************************************************

	.global EvaluateLessOrEqual
	.global EvaluateNotEqual
	.global EvaluateLessThan
	.global EvaluateGreaterThan
	.global EvaluateGreaterOrEqual
	.global EvaluateEquals
	.global EvaluateAnd
	.global EvaluateOr
	.global EvaluateNot
	.global EvaluateSGN
	.global EvaluateABS
	.global EvaluatePlus
	.global EvaluateMinus
	.global EvaluateMultiply
	.global EvaluateDivide
	.global EvaluateUnaryMinus
	.global EvaluateBracketOpen
	.global EvaluateUnaryPlus
	.global EvaluateStringAssignment
	.global EvaluateArrayDimensionComma
	.global EvaluateFunctionBracket
	.global EvaluateBracketClose
	.global EvaluateStringBracketOpen
	.global EvaluateDimStringBracket
	.global EvaluateDimNumericBracketOpen
	.global EvaluateNumericArrayBracketOpen
	.global AssignToNumericArrayElement
	.global EvaluateSTR
	.global EvaluateCHR
	.global PushShortString
	.global EvaluateUSR
	.global EvaluateASC
	.global EvaluateADR
	.global EvaluateLEN
	.global EvaluatePeek
	.global EvaluateRND
	.global EvaluateFRE
	.global EvaluatePADDLE
	.global EvaluateSTICK
	.global EvaluatePTRIG
	.global EvaluateSTRIG
	.global EvaluateVAL
	.global EvaluateINT
	.global EvaluateEXP
	.global EvaluateLOG
	.global EvaluateCLOG
	.global EvaluateSQR
	.global EvaluateSIN
	.global EvaluateCOS
	.global EvaluateATN
	.global EvaluatePower
	.global ExecuteRem
	.global ExecuteData

;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicparser.asm,v 1.25 2017/02/11 20:02:40 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   Syntax parser of the ABML                      **
;;; **********************************************************************

	.include "basicmacros.i"
	.include "basicparser.i"
	.include "basicerror.i"
	.include "basicmemory.i"
	.include "basicexpression.i"
	.include "basicexecution.i"
	.include "basicmain.i"
	.include "basicmath.i"
	.include "basicio.i"
	.include "mathpack.i"
	.include "syntax.i"
	.include "reset.i"

	.segment "BasMain"
	
;;; *** ParseLineNumber (GETLNUM in Atari basic)
;;; *** Parse off the line number from the input buffer, offset in cix
;;; *** store in TargetLineNumber if good
	.global ParseLineNumber
.proc	ParseLineNumber
	jsr AsciiToBCDVector  	;first, parse off the line number
	bcc isvalid
	;; here: some junk, possibly a direct command
directmode:	
	lda #0
	sta cix		      	;reset parser to start of line
	ldy #$80	      	;line number of the direct mode
	bmi setline
isvalid:		      	;ok, some number at least
	jsr ConvertToInteger	;get A,Y, set flags from Y
	bmi directmode		;if larger than 32768, execute in direct mode
setline:
	sty TargetLineNumber+1
	sta TargetLineNumber	;store the line number here
	jsr InsertToken		;add lo to to the output buffer at cox
	lda TargetLineNumber+1
	;; runs into the following
.endproc
;;; *** InsertToken (SETCODE in Atari basic)
;;; *** Insert the token A (or other object) into the output token buffer at TokenBuffer,
;;; *** and adjust cox accordingly. MUST NOT ALTER THE C FLAG.
	.global InsertToken
.proc	InsertToken
	ldy cox
	sta (TokenBuffer),y	;insert into the output buffer
	inc cox
	beq overflow		;line too long!
	rts
overflow:
	Error LineTooLong
.endproc
;;; *** PrintStatement (AtariBasic LSTMC)
;;; *** Print the command token whose token index is in register A
	.global PrintStatement
.proc	PrintStatement
	tax
	cmp #ImplicitLetToken	;if above that, it gets unorthogonal
	bcc orthogonal
	inx			;is one position higher to make room for LET
	cmp #DirToken		;or was it DIR?
	bne orthogonal
	ldx #ImplicitLetToken	;this moved here
orthogonal:
	stx ScanOffset		;this is where the command is found in the table
	ldx #2			;skip two bytes after each token
	lda #>StatementTable
	ldy #<StatementTable
	jsr SearchForToken	;find the token in a token table (LSCAN)
	;; returns the token address in PrintPtr
	jmp PrintStringAndBlank	;print the token, followed by a blank space
.endproc
;;; *** SearchStatement
;;; *** Convert an ASCII representation from the statement
;;; *** list to a statement token in ScanOffset
;;; *** This handles the rather unorthogonal DirToken which is
;;; *** not exactly continuous
	.global SearchStatement
.proc SearchStatement
	lda #>StatementTable
	ldy #<StatementTable
	ldx #2			;two extra bytes per token
	jsr SearchTable		;found something?
	ldy ScanOffset		;is this one of our special cases?
	bcs letorerror		;not found
	cpy #ImplicitLetToken
	bcc exit		;if below, everything is regular
	clc
	bne letorerror		;otherwise, this is a let or error token
	ldy #DirToken+1		;Dir is in this place
letorerror:
	dey			;skip over the unorthogonal DIR
	sty ScanOffset
exit:
	rts
.endproc
;;; *** SearchTable (AtariBasic SEARCH)
;;; *** Search in the token table for a given token of a name whose
;;; *** name is in the inbuff. The token table starts at address (A,Y), each
;;; *** entry has an addition of X bytes upfront that are skipped
;;; *** Returns with C=0 if the entry has been found, X=updated cix
;;; *** Returns with C=1 and A=0 if no entry has been found.
.proc	SearchTable
	stx TableSkip
	ldx #$ff
	stx ScanOffset		;start with statement #0
	jsr SetScanPtr		;initialize the scan pointers
	;; runs into the following
.endproc
;;; *** SearchTableNext (almost SRC1 in Atari Basic)
;;; *** Continue seaching the table after being interrupted by a (partial) match
.proc	SearchTableNext
loop:	
	inc ScanOffset		;next entry
	ldx cix
	ldy TableSkip
	lda (ScanPtr),y		;end of table?
	sec			;already prepare the error
	beq exit		;return with an error
	lda #0			;set Z
	php
matchloop:
	lda outbuff,x		;get the value from the input buffer
	cmp #$1b
	beq nomatch		;do not confuse EOL with ESC, never match ESC
	and #$7f		;inverseVID is ignored
	cmp #'.'		;wildcard?
	beq wildcard
	eor (ScanPtr),y		;does it match?
	asl a			;ignore MSB match, move MSB into carry
	bne nomatch
	iny			;next entry
fits:
	inx
	bcc matchloop		;until end of token
	plp			;did we find a match?
	beq found		;if so, done
	jsr AddYToScanPtr	;advance to next token entry
	bcc loop
wildcard:			;is this a wildcard match?
	lda TableSkip		;Wild cards allowed?
	bne skippast		;if so, skip over the rest, understood as matching
nomatch:
	pla
	php			;set ne
skippast:
	lda (ScanPtr),y
	iny
	asl a
	bcc skippast		;continue scanning, set C if this is the last entry
	bcs fits		;if it fits, skip over the dot
found:
	clc			;indicate that we found the token
exit:	
	rts
.endproc
;;; *** SearchForToken (AtariBasic LSCAN)
;;; *** Search a token table for a given token index in ScanOffset, return
;;; *** the found token in PrintPtr and PrintPtr+1.
;;; *** The token table starts at address (A,Y), each entry has an addition of X
;;; *** bytes upfront that are to be skipped
	.global SearchForToken
.proc	SearchForToken
	stx TableSkip	        ;keep me
	jsr SetScanPtr
loop:
	ldy TableSkip
	dec ScanOffset		;found me?
	bmi AddYToScanPtr	;if so, finally adjust the pointer to the start of the token
	;; skip over the entry
	dey
skiploop:
	iny
	lda (ScanPtr),y		;next byte of the name
	bpl skiploop
	iny			;and the last byte
	jsr AddYToScanPtr
	bcc loop		;and continue
	;; code never goes here
.endproc
;;; *** AddYToScanPtr (AtariBasic LSINC)
;;; *** Add the contents of the Y register to the SCANPTR and return
.proc	AddYToScanPtr
	tya
	clc
	adc ScanPtr
	tay
	lda #0
	adc ScanPtr+1
	;; runs into the following
.endproc
;;; *** SetScanPtr (AtariBasic LSST)
;;; *** Set the scan/print poiner to (A,Y)
.proc	SetScanPtr
	sta ScanPtr+1
	sty ScanPtr
	rts
.endproc
;;; *** ParseArguments (Atari Basic :SYNENT)
;;; *** Given the current statement in Scanffset, and its description table in ScanPtr,
;;; *** parse off its arguments from inbuff given the argument description at ScanPtr
;;; *** This is the main syntax parser that converts ASCII to the internal token
;;; *** representation.
	.global ParseArguments
.proc	ParseArguments
	ldy #1
	;; get the syntax description
	lda (ScanPtr),y		;syntax table high byte
	pha
	dey
	sty ParsedOperator	;clear the token backup
	lda (ScanPtr),y
	dey
	sty LastOperatorcix	;make sure cix does not match
	tay			;low->Y
	pla			;high->A
	ldx #0
	stx SyntaxStackPtr
	jsr SaveParsePosition	;push the parser position on the stack
	;; start parsing now (NEXT in Atari Basic)
parseloop:
	jsr GetNextSyntaxCode
	bmi relative		;a relative short sub-expression scan?
	;; here no
	cmp #SC_CallNative
	bcc getadr		;code 0: absolute vector (long sub-expression call)
	bne tstsucc
	;; here code 1: customized parser in machine language
	jsr CallCustomParser
	bcc parseloop		;if parsed correctly, continue
	bcs parsingfailed	;if not, fail through
tstsucc:
	cmp #SC_Reserved1+1	;tokens 2,3,4 pop up the syntax parser: Especially, an "or" acts like an rtn now.
	bcc popfromstack
	;; everything else are terminal codes or relative branches
	jsr TestTerminalCode	;check for a terminal code
	bcc parseloop		;if successful, continue there
	bcs parsingfailed	;error otherwise
	;; relative non-terminal token, subexpression
relative:			
	sec
	ldx #0		     	;branch direction is positive
	sbc #$c1		;is this a positive or a negative branch?
	bcs ispositive
	dex			;or negative
ispositive:
	clc
	adc SyntaxPtr
	tay			;lo -> Y
	txa
	adc SyntaxPtr+1
	bne pushonstack		;hi -> A (branches always)
	;; here an absolute vector, i.e. a subexpression
getadr:
	jsr GetNextSyntaxCode	;get low
	tay
	jsr GetNextSyntaxCode	;get high
pushonstack:
	;; place the current SyntaxPtr on the syntax stack, then resume at the new target
	jsr PushOnStack
	bcc parseloop		;branches always
	;; here: parsing failed
	;; If there is an alternative (SC_Alternative, OR), try that instead.
parsingfailed:
	jsr GetNextSyntaxCode
	bmi parsingfailed	;all relative codes are then ignored up to the point were we get the alternative
	cmp #SC_Alternative	;alternative, or end?
	bcs ororrtn
	;; codes 0,1: absolute or custom, are also skipped over and are ignored until the alternative
	jsr GetNextSyntaxCode
	jsr GetNextSyntaxCode	;two bytes in size
	bcc parsingfailed
ororrtn:			;here we reached the alternative or RTN
	cmp #SC_End		;if End, pop this part and abort this subexpression with an error (C is set)
	beq popfromstack
	bcs parsingfailed	;everything above is also ignored and skipped over
	;; here the alterantive.
	;; update the cix maximum
	;; This is where we place the cursor in case parsing failed completely
	;; and an error is generated.
	lda cix
	cmp MaxValidcix
	bcc nomax
	sta MaxValidcix
nomax:
	;; restore cix and cox from stack, try again with the alternative subexpression
	ldx SyntaxStackPtr
	lda SavedSyntaxcix,x
	sta cix
	lda SavedSyntaxcox,x
	sta cox
	bne parseloop
popfromstack:
	;; here: Parsing at this level done, remove data from syntax stack, return
	;; to super parser with C = the condition code
	ldx SyntaxStackPtr	;stack empty?
	beq exit		;if so, parsing done
	lda SavedSyntaxPtrLo,x
	sta SyntaxPtr
	lda SavedSyntaxPtrHi,x
	sta SyntaxPtr+1
	dec SyntaxStackPtr
	bcs parsingfailed	;if the callee failed, fail.
	bcc parseloop
exit:
	rts
.endproc
;;; *** TestTerminalCode (no equivalent)
;;; *** Test for a code that terminates the parsing. This can
;;; *** be either an expression (a complex recursive call) or
;;; *** a token, or a change-to-token. Returns with C=1 in
;;; *** case parsing failed.
;;; *** The syntax token to test for is in A.
.proc	TestTerminalCode
	;; Check the next syntax element in inbuf+cix for a terminal syntax
	;; element in the atari basic meta language
	;; Return with C cleared if parsing is ok, otherwise with C=1
	cmp #SC_ChangeLastToken	;is it a change token?
	beq changetoken		;yup, fixup last token
	bcs MatchOperator
	;; here an expression. Use the expression ABML function.
	ldy #<(ExpressionSyntax-1) ;the -1 compensates for the following increment.
	lda #>(ExpressionSyntax-1)
	bne PushOnStack		;keep old position, continue there
changetoken:
	;; here: change a token in outbuf to another value
	jsr GetNextSyntaxCode
	ldy cox
	dey
	sta (TokenBuffer),y	;insert the changed code back at the last position
	clc			;ok, worked, continue parsing.
	rts			;done
.endproc
;;; *** MatchOperator (SRCONT in Atari basic)
;;; *** Search the current position in the input buffer for an operator in the
;;; *** operand table, return with C=0 if found, then insert this into the tokenized line.
.proc	MatchOperator
	jsr SkipBlanksVector	;ignore blanks in inbuf
	jsr SearchForOperator	;did an operator match?
	bcs exit		;if not, exit
	;; now check whether this is the token we expect according to ABML
	ldy #0
	lda (SyntaxPtr),y	;does it match the expected token in the syntax?
	cmp ParsedOperator	;if so, insert
	beq insert		;yup!
	cmp #GenericFunctionToken ;if we require a generic function...
	bne failexit
	lda ParsedOperator	;that also works for ATN and above....
	cmp #GenericFunctionToken
	bcc failexit
insert:
	;; token matches the expected, insert
	jsr InsertToken		;place it in the basic token buffer
	ldx ParsedOperatorcix
	stx cix			;keep cix updated
	clc			;successful
	rts
failexit:
	sec
exit:	
	rts
.endproc
;;; *** PushOnStack (no equivalent)
;;; *** Push the current syntax parser position
;;; *** on the stack, continue from the address
;;; *** given in A (hi) and Y (lo)
;;; *** MUST return with C=0
.proc	PushOnStack
	inc SyntaxStackPtr
	ldx SyntaxStackPtr	;get me
	cpx #$40
	bcc SaveParsePosition
	;fail if the stack overruns
	Error ArgStackOverflow
.endproc
;;; *** SaveParsePosition
;;; *** Save the current parsing position on the stack
;;; *** with X = the stack pointer of the syntax stack
;;; *** Set the new parse position to A=hi, Y=lo
.proc	SaveParsePosition
	pha
	lda cix
	sta SavedSyntaxcix,x
	lda cox
	sta SavedSyntaxcox,x
	lda SyntaxPtr
	sta SavedSyntaxPtrLo,x
	lda SyntaxPtr+1
	sta SavedSyntaxPtrHi,x
	pla
	sta SyntaxPtr+1		;push on stack
	sty SyntaxPtr
	rts
.endproc
;;; *** CallCustomParser (no equivalent, part of :getadr in Atari basic)
;;; *** calls a customized parser to implement the code SC_ExternalParser=ERST
;;; *** here parsing is not done with the ABML, but in machine code.
.proc CallCustomParser
	jsr GetNextSyntaxCode	;get high-byte
	pha			;keep it
	jsr GetNextSyntaxCode	;get lo-byte
	pha			;push on the stack
	rts			;and call
.endproc
;;; *** GetNextSyntaxCode (NXSC in Atari Basic)
;;; *** Extract the next syntax description code from SyntaxPtr, return in A
;;; *** Does not alter the Y register,does not alter C.
.proc	GetNextSyntaxCode
	inc SyntaxPtr
	bne nocarry
	inc SyntaxPtr+1
nocarry:	
	ldx #0
	lda (SyntaxPtr,x)
	rts
.endproc
;;; *** SearchForOperator (not exactly present as such in Atari Basic)
;;; *** Try to locate whether the text at inbuff+cix matches
;;; *** an operator. If the carry is set, no operator has been found.
;;; *** If the carry is clear, a valid operator has been found and
;;; *** ParsedOperator contains it.
.proc	SearchForOperator
	ldx #0			;no extra elements here
	lda cix
	cmp LastOperatorcix	;do we really have to do again?
	beq maymatch
	sta LastOperatorcix	;if not yet here, go get the operator again
	lda #>OperatorTable
	ldy #<OperatorTable
	jsr SearchTable		;check whether we find the operand
	bcs clearexit		;if not found, no luck
	stx ParsedOperatorcix	;keep cix updated: this is the end of the operator
	lda ScanOffset		;is the operator token
	;; carry is clear
	adc #CommaToken		;almost (everything below is reserved for ABML)
clearexit:
	sta ParsedOperator	;keep if we come again and try again...
	rts
maymatch:
	cpx ParsedOperator	;set carry if zero
	rts
.endproc
;;; *** The following sections contain miscellaneous routines that support the tokenizer. They are called by
;;; *** the ABML callnative syntax element. What is common to all of them is that they return C=1
;;; *** if parsing failed (the code did not match the expectations of the syntax) and C=0 if
;;; *** parsing succeeds.

;;; *** ParseNumber (TNCON in AtariBasic)
;;; *** Parse off a numeric constant.
	.global ParseNumber
.proc	ParseNumber
	jsr AsciiToBCDVector
	bcs error
works:				;here we succeeded, is a number
	lda #ExpressionToken	;is a numExp
	jsr InsertToken		;does not alter C
	;; now copy the number to the outut buffer
	ldx #-6+256
loop:
	lda fr0+6,x
	jsr InsertToken		;this also tests for an overflow
	inx
	bne loop
	;; clc			;worked! (carry is still clear)
error:	
	rts
.endproc
;;; *** GetIsAlpha (TSTALPH in Atari Basic)
;;; *** Unlike IsAlpha, this one also gets the character from inbuf
.proc	GetIsAlpha
	ldy cix
	lda (inbuff),y
	;; runs into the following
.endproc
;;; *** IsAlpha (TSTALPH in AtariBasic)
;;; *** Test whether a character is alphabetic. Returns C=1 if not so
	.global IsAlpha
.proc	IsAlpha
	cmp #'A'
	bcc ParseError
	cmp #'Z'+1		;if larger, not alphabetic (lower print not used here)
	rts
.endproc
;;; *** ParseError
;;; *** A generic error indicator if parsing failed.
.proc	ParseError
	sec
	rts
.endproc
;;; *** ParseString (TSCON in Atari Basic)
;;; *** Parse off a string in double quotes.
	.global ParseString
.proc	ParseString
	jsr SkipBlanksVector
	ldy cix
	lda (inbuff),y
	cmp #$22		;double quotes?
	bne ParseError		;if not, then not a string
works:	
	lda #StringToken
	jsr InsertToken
	lda cox			;keep start of string to compute the length
	sta ParseStartcox
	jsr InsertToken		;reserve the room for the string length
loop:
	inc cix
	ldy cix
	lda (inbuff),y		;get the enxt token
	cmp #$9b		;end of line also works as string terminator
	beq abort
	cmp #$22		;double quotes terminate the string
	beq abortinc
	jsr InsertToken		;place in output buffer
	bne loop		;always returns with Z=0
abortinc:
	inc cix			;skip over double quotes
abort:
	;; now compute the length of the string and insert that
	clc
	lda cox
	sbc ParseStartcox
	ldy ParseStartcox
	sta (TokenBuffer),y	;adjust the output length
	clc
	rts
.endproc
;;; *** ParseNumericVariableName (TNVAR in Atari Basic)
;;; *** Parse off the name of a numeric variable
	.global ParseNumericVariableName
.proc	ParseNumericVariableName
	lda #VTYPE_Numeric
	Skip2
	;; runs into the following
.endproc
;;; *** ParseStringVariableName (TSVAR in Atari Basic)
;;; *** Parse off the name of a string variable
	.global ParseStringVariableName
.proc	ParseStringVariableName
	lda #VTYPE_String
	sta VariableType

	jsr SkipBlanksVector
	lda cix
	sta ParseStartcix	;keep cix

	jsr GetIsAlpha
	bcs failexit		;must surely start with an alphabetic character

	jsr SearchForOperator	;and must not be an operator
	bcc findendofname	;surely not an operator
	;; here: is not an operator. ParsedOperatorcix is "something", left over from last time.
	lda ParseStartcix
	sta ParsedOperatorcix	;operator ends before first character
	;; for that, first find the potential end of the operator match,
	;; and compare that with the variable end. If both are equal,
	;; this is an operator and not a variable.
findendofname:
	inc cix			;otherwise, advance to the
	jsr GetIsAlpha		;as long as it is an alpha character, acceptable
	bcc findendofname
	jsr TestDigitVector	;or is it a digit? That also works as part of the variable name
	bcc findendofname
	;; does it end with a $? If so, it is a variable name
	lda (inbuff),y
	cmp #'$'
	beq stringvar
	bit VariableType	;do we actually expect a numeric variable?
	bpl numeric
failexit:
	sec
	rts
stringvar:
	bit VariableType
	bpl failexit		;here a string variable is expected, but not given
	iny			;skip over the $
	cpy ParsedOperatorcix
	beq failexit		;if the $ is where the operator ends, then this is not valid
	bne found
numeric:
	;; here test for numeric operators. Unlike for string operators CHR$ and STR$, the (
	;; of regular operators is not part of the operator name, and the test must be
	;; made without incrementing over the '('
	cpy ParsedOperatorcix
	beq failexit		;not an operator at all....
	;; here test for an array
	cmp #'('
	bne found		;is a simple numeric variable
	iny			;skip over the array
	lda #VTYPE_Array	;set the variable type
	sta VariableType
found:
	lda ParseStartcix	;restore cix
	sty ParseStartcix	;and save the end
	sta cix
	;; now potentially create a new variable in the variable table
	lda VarNamePtr+1
	ldy VarNamePtr
	ldx #0
	jsr SearchTable		;found it? (includes the array as type)
testagain:
	bcs nosuchvar		;potentially create it if not found
	cpx ParseStartcix	;must also match the end of the name
	beq foundvarname
	jsr AddYToScanPtr	;continue looking
	jsr SearchTableNext	;in the same table entry
	beq testagain		;jumps always
	;; here: variable name not found, so create it.
	;; either as string, or as array, or as plan variable
nosuchvar:
	lda ScanOffset
	bmi full
	;; remember the index of the variable. The type is already
	;; set
	sta VariableIndex
	;; Allocate the entry for the variable first. If this succeeds
	;; but the next allocation works, then the variable is not created
	;; but at least no entry in the variable name table is taken
	;; which could overwrite program memory if somebody tries to
	;; assign to this variable.
	ldy #8			;takes always 8 bytes
	ldx #StatementPtr	;just before the statements
	jsr AllocMemLow
	inc AdditionalVariables	;remember to release it if parsing fails

	sec
	lda ParseStartcix
	sbc cix
	sta cix			;size of the variable
	tay
	ldx #VarNameEndPtr	;allocate memory here, i.e. at the end of the variable names
	jsr AllocMemLow
	;; now copy the variable name into the name table
	ldy cix			;length of the variable name
	ldx ParseStartcix	;end of the variable name 
	dey
	lda #$80		;mark the last character by an inverted MSB
cpname:
	ora outbuff-1,x
	sta (AllocMemPtr),y	;copy to the target
	dex
	lda #$00		;keep MSB reset at the rest of it
	dey
	bpl cpname
	;; clear the variable value. Everything else is already setup
	jsr ZeroFr0Vector
	;; install the variable
	jsr SetVariable
	;; the parenthesis is not part of the variable name and requires parsing
	;; separately, so remove that now.
	;; at this point, ParseStartcix points to the end of the variable name
	;; and ScanOffset is the variable index
foundvarname:	
	ldy ParseStartcix
	bit VariableType
	bvc noarray
	dey			;ensure the syntax parser will see the ( of the array bracket
noarray:
	sty cix			;end of the parsed string
	lda ScanOffset		;found variable index
	ora #$80		;create the token for a variable access
	jsr InsertToken
	clc			;this worked!
	rts
full:
	;; the extra variable will be removed again once the error propagates to the top
	Error VariableTableOverflow
.endproc
;;; *** ParseREMDATA (EREM and EDATA in Atari Basic)
;;; *** Continue parsing the REM and DATA statements.
;;; *** All these two do is to place the rest of the line
;;; *** in clear text into the output buffer and continue
;;; *** from there. No further parsing is done.
	.global ParseREMDATA
.proc	ParseREMDATA
	jsr CopyDirectToToken	;copy the rest of the line directly to the output
	;; runs into the following
.endproc
;;; *** ParseIfStatement (EIF in Atari Basic)
;;; *** Parse the statements behind an IF statement if this is not a line number.
;;; *** This rather terminates parsing, and restarts with a new statement.
	.global ParseIfStatement
.proc	ParseIfStatement
	pla
	pla
	clc			;parsing succeeded
	rts			;return to top-level caller
.endproc
;;; *** InsertError (no equvalent in Atari Basic)
;;; *** When parsing failed, insert the error token into the line
;;; *** and copy the rest of the erraneous statement as argument to the
;;; *** error token.
	.global InsertError
.proc InsertError
	ldy MaxValidcix
	lda (inbuff),y
	cmp #$9b		;reached the final eol?
	bne noteof
	;; move EOL one to the right
	iny
	sta (inbuff),y
	lda #' '		;insert a blank in place
	dey
noteof:
	ora #$80
	sta (inbuff),y		;mark end of the error
	lda #$40
	ora DirectModeFlag
	sta DirectModeFlag	;indicate the syntax error
	ldy StatementStart
	sty cix
	ldx #3
	stx StatementLen 	;where the length goes: Right after the line length
	inx
	stx cox			;put the error token here
	lda #ErrorToken
	jsr InsertToken
	;; runs into the following
.endproc
;;; *** CopyDirectToToken
;;; *** Copy the contents of the input buffer directly to the token buffer
;;; *** This is used for ERROR, DATA and REM
	.proc CopyDirectToToken
insertloop:
	;; the argument of the ERROR token is the erraneous statement
	ldy cix
	lda (inbuff),y
	jsr InsertToken
	inc cix
	cmp #$9b
	bne insertloop		;up to and including the EOL
	rts
.endproc

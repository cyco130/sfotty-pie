;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicparser.i,v 1.9 2015/10/24 13:58:52 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Syntax parser of the ABML                      **
;;; **********************************************************************

TokenBuffer		=	$80	;output for the tokenizer, a 256 byte buffer (also LoMem)
cox			=	$94	;output buffer index equivalent to cix (COX in Atari basic)
ScanPtr			=	$95	;pointer to a statement/function table to be scanned (SRCADR in Atari basic)
MaxValidcix		=	$9f	;maximum value of the cix input buffer offset (MAXCIX in Atari basic)
StatementStart		=	$a8	;start of the current statement (STMSTRT,STINDEX in Atari basic) (also StatementOffset)
StatementLen		=	$a7	;offset of the length byte in the output buffer (STMLB or NXTSTD in Atari basic), also StatementEnd
SyntaxStackPtr		=	$a9	;stack pointer for the syntax parser stack
TableSkip		=	$aa	;additional size of each entry in the statement/command table (SRCSKP in Atari basic)
ParseStartcox		=	$ab	;backup of cox within parsers (TSCOX in Atari Basic)
ParseStartcix		=	$ac	;backup of cix within parsers (TVSCIX in Atari Basic)
ParsedOperator		=	$b0	;backup of the current operator token (SVONTC in Atari Basic)
ScanOffset		=	$af	;also used as temporary offset for scanning for tokens (SCANT,STENUM in Atari basic)
ParsedOperatorcix	=	$b2	;copy of cix on an operand match (SVONTL in Atari basic), position where ParsedOperator was found
LastOperatorcix		=	$b3	;saved copy of cix (SVONTX in Atari Basic)
SyntaxPtr		=	$be	;pointer to the current syntax description (CPC in Atari Basic, but there $9d)

	;; page 4 equates: This is the syntax stack. Each entry consists of four bytes: cix,cox,and the syntax pointer
SavedSyntaxcix		=	$480	;backup of the input pointer (SIX in Atari Basic)
SavedSyntaxcox		=	$4c0	;backup of the output pointer (SOX in Atari basic)
SavedSyntaxPtrLo	=	$500	;syntax description pointer, backup (SPC in Atari Basic)
SavedSyntaxPtrHi	=	$540	;syntax description pointer, backup (SPC in Atari Basic)

	.global InsertToken
	.global ParseLineNumber
	.global ParseNumber
	.global ParseString
	.global ParseREMDATA
	.global ParseNumericVariableName
	.global ParseStringVariableName
	.global ParseIfStatement
	.global IsAlpha
	.global InsertError
	.global SearchStatement
	.global SearchForToken
	.global ParseArguments
	.global PrintStatement


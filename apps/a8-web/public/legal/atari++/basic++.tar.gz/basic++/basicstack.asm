;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicstack.asm,v 1.15 2015/12/01 20:57:53 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   Stack support functions			**
;;; **********************************************************************

	.include "basicstack.i"
	.include "basicerror.i"
	.include "basicmemory.i"
	.include "basicexecution.i"
	.include "syntax.i"
	.include "mathpack.i"
	.include "reset.i"
	
	.segment "BasMain"

;;; *** WriteBCDToRunStack (almost MV6RS in AtariBasic)
;;; *** Move Fr0 onto the RUN stack frame at offset Y
	.global WriteBCDToRunStack
.proc	WriteBCDToRunStack
	ldx #-6+256
loop:
	lda fr0+6,x
	sta (RunStackPtr),y
	iny
	inx
	bne loop
	rts
.endproc
;;; *** ReadBCDFromRunStack (PL6RS in Atari Basic)
;;; *** Move the BCD variable at the stack frame + Y
;;; *** into fr1
	.global ReadBCDFromRunStack
.proc	ReadBCDFromRunStack
	ldx #-6+256
loop:
	lda (HiMem),y
	sta fr1+6,x
	iny
	inx
	bne loop
	rts
.endproc
;;; *** PushProgramLine (XGS1 in Atari Basic)
;;; *** Save the current program position and the line offset from
;;; *** SavedStatementOffset on the run stack
	.global PushProgramLine
.proc	PushProgramLine
	lda #STYPE_GOSUB
	;; runs into the following
.endproc
;;; *** PushOnRunStack (PSHRSTK in Atari basic)
;;; *** put the current line number and the statement offset
;;; *** from SavedStatementOffset on a run stack, creating
;;; *** a stack element of the type in the accumulator
	.global PushOnRunStack
.proc	PushOnRunStack
	pha			;keep for a while on the hardware stack
	ldy #SGOSUB_Size	;four bytes stack element
	jsr EnlargeRunStack	;make stack larger
	pla
	ldy #0
	sta (RunStackPtr),y	;keep offset
	lda (CurrentLinePtr),y	;line number low
	iny
	sta (RunStackPtr),y
	lda (CurrentLinePtr),y	;line number high
	iny
	sta (RunStackPtr),y
	ldx SavedStatementOffset ;statement offset
	iny
	dex
	txa
	sta (RunStackPtr),y	;and store this as well
	;; the following is an extension to speed up GOSUB, FOR-NEXT and READ
	iny
	lda GenerationCounter	;the consistency check for line-number changes
	sta (RunStackPtr),y
	iny
	lda CurrentLinePtr	;low of the line pointer
	sta (RunStackPtr),y
	iny
	lda CurrentLinePtr+1	;and high of the line pointer
	sta (RunStackPtr),y
	rts
.endproc
;;; *** SaveStatementOffset (SAVDEX in Atari basic)
;;; *** Copy the current statement offset into
;;; *** its backup position
	.global SaveStatementOffset
.proc	SaveStatementOffset
	ldy StatementOffset
	sty SavedStatementOffset
	rts
.endproc
;;; *** SaveStackPtr (SAVRTOP in Atari Basic)
;;; *** Save the current run stack position in RunStackPtr
;;; *** Does not modify A or Y
	.global SaveStackPtr
.proc	SaveStackPtr
	ldx HiMem
	stx RunStackPtr
	ldx HiMem+1
	stx RunStackPtr+1
	rts
.endproc
;;; *** RestoreStackPtr
;;; *** Restore the stack ptr from from the saveback position.
	.global RestoreStackPtr
.proc	RestoreStackPtr
	ldx RunStackPtr
	stx HiMem
	ldx RunStackPtr+1
	stx HiMem+1
	rts
.endproc
;;; *** ExecuteReturn (XRTN in Atari Basic)
;;; *** Execute a RETURN statement to return from a subroutine
	.global ExecuteReturn
.proc	ExecuteReturn
	;; runs directly into the following
.endproc
;;; *** PopProgramPosition (XRTN in Atari Basic)
;;; *** Restore the program position from the run stack
;;; *** Must return with the statement offset in Y
	.global PopProgramPosition
.proc	PopProgramPosition
popagain:	
	jsr PopFromStack
	bcs error
	;; if this is from a FOR loop, pop again
	;; strangely enough, a started FOR loop with a RETURN
	;; is OK even without POP
	bne popagain
	jsr GetStackToken	;get the token on the run stack
	cmp #GOSUBToken
	beq ok
	cmp #ONToken
	beq ok
	cmp #LISTToken
	beq ok
	cmp #READToken
	bne RestoreLineMissing
ok:	
	rts
error:
	Error GosubNotFound	;actually, misleading. Can also be on LIST and READ (and ON..GOSUB)
.endproc

;;; *** GetStackToken (:GETTOK in AtariBasic)
;;; *** Return the element pointed to by the token on the stack
;;; *** Must return with the statement offset in Y
	.global GetStackToken
.proc	GetStackToken
	;; first check whether we can speed up the restauration of the current line ptr
	lda GenerationCounter
	eor PoppedGenerationCounter ;did someone mess with the basic token table?
	bne fullsearch		    ;if so, do a line search
	;; here: Use the popped position, avoid a full-search (A=0 here)
	tay
	lda (PoppedLinePtr),y
	cmp TargetLineNumber
	bne fullsearch
	iny
	lda (PoppedLinePtr),y
	cmp TargetLineNumber+1
	bne fullsearch
	lda PoppedLinePtr
	sta CurrentLinePtr
	lda PoppedLinePtr+1
	sta CurrentLinePtr+1
	jsr SetupLineOffsets
	bne restore
fullsearch:
	jsr SetupLine		;find the target line. A backup of the current is in JumpOriginLinePtr
	bcs RestoreLineMissing	;error if the line does not exist
restore:	
	ldy PoppedStatementOffset
	dey			;in front of the command
	lda (CurrentLinePtr),y	;which command
	sta StatementEnd 	;end of the statement
	iny
	lda (CurrentLinePtr),y	;and the statement itself
	rts
.endproc
;;; *** RestoreLineMissing
;;; *** Repair the current line and report a "line missing" error.
.proc	RestoreLineMissing
	jsr RestoreCurrentLine
	Error TargetLineDeleted
.endproc
;;; *** RestoreCurrentLine (RESCUR in Atari Basic)
;;; *** Restores the current line after having popped
;;; *** a new line from the stack (erraneously, likely!)
	.global RestoreCurrentLine
.proc	RestoreCurrentLine
	lda JumpOriginLinePtr
	sta CurrentLinePtr
	lda JumpOriginLinePtr+1
	sta CurrentLinePtr+1
	rts
.endproc
;;; *** ExecutePop (XPOP in Atari Basic)
;;; *** Remove the topmost element from the run stack
	.global ExecutePop
.proc	ExecutePop
	;; runs into the following
.endproc
;;; *** PopFromStack (POPRSTCK in Atari Basic)
;;; *** Pop an element from the run stack. Returns with C=1
;;; *** in case the stack is empty. Returns with the type
;;; *** of the topmost stack entry in A. Returns with Z=1
;;; *** if the element was from GOSUB.
	.global PopFromStack
.proc	PopFromStack
	lda RunStack
	cmp HiMem
	lda RunStack+1
	sbc HiMem+1
	bcs empty		;stack is empty
	lda #256-SGOSUB_Size
	jsr ShrinkRunStack
	;; get saved line
	ldy #SGOSUB_Size-1
	;; First the extended part
	lda (HiMem),y
	sta PoppedLinePtr+1
	dey
	lda (HiMem),y
	sta PoppedLinePtr
	dey
	lda (HiMem),y
	sta PoppedGenerationCounter
	dey
	;; now the regular part
	lda (HiMem),y		;the released stack element
	sta PoppedStatementOffset ;the statement offset
	dey
	lda (HiMem),y
	sta TargetLineNumber+1
	dey
	lda (HiMem),y
	sta TargetLineNumber
	dey
	lda (HiMem),y		;and the stack type
	;; note that the carry is at this point still clear.
	beq exit		;if GOSUB type, exit
	;; here it is FOR..NEXT, i.e. a variable is missing
	pha
	lda #256-SFOR_Size		;end and step size
	jsr ShrinkRunStack	;remove that, too
	pla
exit:
empty:	
	rts
ShrinkRunStack:
	ldy HiMem+1
	adc HiMem
	bcs SetHiMem
	dey
	;; runs into the following
.endproc
;;; *** SetHiMem
;;; *** Set the high-memory to A=lo, Y=hi
;;; *** MUST return with C=0
	.global	SetHiMem
.proc	SetHiMem
	sta HiMem
	sta AppMemHi
	sty HiMem+1
	sty AppMemHi+1
	clc
	rts
.endproc

;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicstack.i,v 1.10 2015/11/18 19:24:34 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Stack support functions			**
;;; **********************************************************************

GenerationCounter	=	$92	;gets incremented each time the program body is modified
PoppedGenerationCounter	=	$93	;what came from the stack
PoppedLinePtr		=	$95	;also used to save the line when retrieving a stack element
PoppedStatementOffset	=	$b2	;statement offset as taken from the stack (SVDISP in Atari Basic)
SavedStatementOffset	=	$b3	;saved copy of StatementStartOffset (SAVDEX in Atari Basic)
JumpOriginLinePtr	=	$be	;a temporary copy of CurrentLinePtr, origin of a jump
RunStackPtr		=	$c4	;keeps the top of the run stack (TEMPA in Atari basic)

	.global ExecutePop
	.global ExecuteReturn
	.global GetStackToken
	.global WriteBCDToRunStack
	.global ReadBCDFromRunStack
	.global PushProgramLine
	.global PushOnRunStack
	.global PopProgramPosition
	.global PopFromStack
	.global SaveStatementOffset
	.global RestoreCurrentLine
	.global SaveStackPtr
	.global	RestoreStackPtr
	.global RestoreStackFrame
	.global SetHiMem

;;; Elements on the run stack
STYPE_GOSUB		=	$00 ;a GOSUB type
SGOSUB_Size		=	$07 ;size of a GOSUB stack frame (was: $04)
;;; Layout of the FOR stack frame
SFOR_Limit		=	$00 ;offset of the target value
SFOR_Step		=	$06 ;offset to the STEP value
SFOR_Size		=	$0c ;size of the FOR stackframe (without the gosub part)

;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicstatements.asm,v 1.68 2017/02/11 16:55:12 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   Implementation of Basic Statements             **
;;; **********************************************************************

	.include "basicmacros.i"
	.include "basicstatements.i"
	.include "basicexpression.i"
	.include "basicio.i"
	.include "basicerror.i"
	.include "basicmath.i"
	.include "basicmemory.i"
	.include "basicexecution.i"
	.include "basicstack.i"
	.include "basicmain.i"
	.include "basicparser.i"
	.include "constants.i"
	.include "syntax.i"
	.include "kernel.i"
	.include "cio.i"
	.include "errors.i"
	.include "sio.i"
	.include "fms.i"
	.include "mathpack.i"
	.include "editor.i"
	.include "screen.i"
	.include "reset.i"
	.include "nmi.i"
	.include "irq.i"
	.include "pokey.i"
	
	.segment "BasMain"

;;; *** ReadNextVariableFromBuffer (not present in Atari Basic)
;;; *** Assign the next variable from the input buffer
;;; *** plus cix. Potentially errors if the type does not fit
.proc	ReadNextVariable
	jsr GetLValue		;get the next token: This is the variable to assign to
	lda VariableType
	bmi string		;string or numerical?
	;; here numerical
	jsr AsciiToBCDVector	;convert this to a number
	bcs error		;if this does not work, error
	jsr TestInputSeparator
	bne error		;if neither , or EOL, error
	beq assignnow		;make the assignment
string:				;here a string variable
	dec cix
	ldy cix
	sty ztemp1		;pointer in front of the next character
	ldx #-1+256		;character counter
sloop:
	inx			;get the next character
	jsr TestNextInputSeparator
	bne sloop		;advance until separator found
	bcs eol			;if C=1 and Z=1, then we found an EOL
	bit InputMode		;are we executing INPUT or READ?
	bvc sloop		;INPUT strings reads over comma, READ does not and separates at commas
eol:	
	ldy ztemp1		;get start index again
	txa			;length of the string
	ldx #inbuff		;Z-page address where the string is
	jsr StringConstFromPointerAndSize;and create a string constant from it (Y contains offset into buffer)
assignnow:	
	jmp SetVariableToFr0  	;evaluate the token, and set the variable
error:
	lda #0
	sta EnterIOCB		;restore STDIN
	Error InputTypeMismatch	;wrong variable type
.endproc
;;; *** ExecuteInput (XINPUT in Atari Basic)
;;; *** Execute the INPUT command
	.global ExecuteInput
.proc	ExecuteInput
	;; some programs, notably kaiser, expect that INPUT also
	;; inputs from IOCB #7 if this is part of ENTER, but
	;; then trap in case IOCB #7, i.e. the enter source, runs
	;; out of data. Unfortunately, they also set the LoadFlag
	;; as a "list protection".
	lda #0
	sta LoadFlag		;not anymore
	jsr GetToken		;get the next token
	dec StatementOffset 	;undo the skip over the token
	bcc noiocb		;if not an operator, it is INPUT from IOCB
	;; here an operator follows. This is the IOCB#, ensured by the syntax parser
	jsr GetIOCB		;THOR: Interestingly, basic allows an input #0 here.
	;; Some hacks use #16 to suppress the prompt 
	sta EnterIOCB		;adjust stdin
noiocb:
inputloop:	
	lda EnterIOCB
	bne noprompt
	lda #'?'		;print the question mark
	jsr PrintChar
noprompt:
	jsr GetLine
	lda BreakFlag		;aborted due to break?
	beq exit		;the main program execution will STOP then

	ldy #0
	sty cix			;reset to start of the buffer
	sty InputMode		;indicate that this is INPUT
inputshortloop:
	jsr ReadNextVariable
	;; is assigned
	jsr TestStatementEnd	;end of statement reached
	bcs exit		;leave when done and all variables are assigned
	jsr TestInputSeparator	;test whether we find a comma or not
	bcs inputloop		;if EOL, go ask again
	;; here a comma
	inc cix			;increment over the comma.
	bcc inputshortloop	;otherwise, go get from the next line
exit:
	;; jsr LoadOutbuffVector	;restore inbuf: why is this needed?
	lda #0
	sta EnterIOCB		;restore STDIN
	rts
.endproc
;;; *** ExecuteRead (XREAD in Atari Basic)
;;; *** Execute the READ statement, read from DATA lines
	.global ExecuteRead
.proc	ExecuteRead
	lda DataLine		;go looking for the line where DATA should be
	ldy DataLine+1
	;; FIXME: This is a dream of inefficiency. The absolute data address (dependent on the generation flag)
	;; should probably be stored somewhere and retrieved instead if the generation flag is consistent.
	jsr FindTargetLineYA	;and go search for it
	bcc found
	lda #0
	sta DataOffset		;start at the beginning of the next line
found:	
	lda CurrentLinePtr	;found line to inbuff
	ldy CurrentLinePtr+1
	jsr Loadinbuff
	jsr RestoreCurrentLine
	lda #$40
	sta InputMode		;indicate that we are READ
readloop:
	ldy #0
	sty cix			;reset cix
	jsr TestInputSeparator 	;as this points to a line structure, get the line number low
	sta DataLine		;low-byte
	jsr TestNextInputSeparator
	sta DataLine+1		;high-byte
	jsr TestNextInputSeparator
	sta ztemp1		;length of the line containing DATA
	;; now continue looking for the data statements in the line
readdataloop:	
	jsr TestNextInputSeparator
	tax			;get the offset of the next statement
	jsr TestNextInputSeparator
	eor #DATAToken
	beq founddata
	;; here not, skip over. Offset to next statement is still in x
	cpx ztemp1		;reached end of line?
	dex			;to compensate for the INC in TestNext...
	stx cix			;next statement or next line
	bcc readdataloop	;advance to that
	;; test the line number
nextline:
	lda DataLine+1
	bmi outofdata		;if we are reading from the direct line, then out of data
	;; here go to the next line
	;sec			;carry is set here anyhow
	lda cix
	adc inbuff		;+1+cix. cix points upfront the line due to TestNext....
	sta inbuff
	lda #0
	sta DataOffset		;start of the line again
	adc inbuff+1
	sta inbuff+1
	bcc readloop		;and advance to the next line
	;; here a DATA statement was found.
founddata:
	tax			;element count is zero (cleared from EOR above)
	;; locate now the element at the offset
elementloop:
	cpx DataOffset		;right offset?
	bcs foundelement	;if not, keep looking
scandata:	
	jsr TestNextInputSeparator ;get the next element
	bne scandata		;if no separator, keep scanning the element itself
	bcs nextline		;if an EOL, advance the line
	inx			;here only an element, so advance that
	bne elementloop
	;; here we are finally at the right element in the right line
foundelement:	
	inc cix			;inc either over DATA statement or comma
	jsr ReadNextVariable	;do the READ and assignment
	;; get to the next data element
	inc DataOffset		;advance offset for DATA
	jsr TestStatementEnd	;last variable to be assigned reached?
	bcs exit		;if so, return
	jsr TestInputSeparator	;what is the end of the line?
	bcc foundelement	;only a comma: advance over, get next.
	bcs nextline		;otherwise, advance the line (and increment over EOL by SEC above)
exit:
	rts
outofdata:
	Error ReadOutOfData
.endproc
;;; *** TestNextInputSeparator (Atari Basic XRNT)
;;; *** Advance to the next character in the input buffer
;;; *** and test for separator.
;;; *** MUST NOT ALTER THE X REGISTER
.proc	TestNextInputSeparator
	inc cix
	;; runs into the following
.endproc
;;; *** TestInputSeparator (Atari Basic XRNT1)
;;; *** Test whether the current character pointed to by
;;; *** cix is a comma, then return with c=0 and Z=1,
;;; *** or an EOL, then return with c=1 and Z=1.
;;; *** MUST NOT ALTER THE X REGISTER
.proc	TestInputSeparator
	ldy cix
	lda (inbuff),y
	cmp #','
	clc
	beq exit
	cmp #$9b		;or EOL?
exit:
	rts
.endproc
;;; *** ExecutePrint (XPRINT in Atari Basic)
;;; *** Executes the print statement.
	.global ExecutePrint
.proc	ExecutePrint
	lda PrintColonWidth
	sta PrintOffset
	lda #0
	sta PrintCounter
	sta InputMode		;stores the last token here.
prloop:
	ldy StatementOffset 	;get next token
	lda (CurrentLinePtr),y
	cmp #EndOfLineToken	;print an EOL? (why is this 
	beq preol
	cmp #ColonToken		;or end of statement?
	beq preol		;all the same, implies EOL
	sta InputMode		;keep last token
	cmp #CommaToken		;a comma? (then print tabs)
	beq prcomma
	cmp #SemicolonToken	;this has no effect
	beq prsemicolon
	cmp #IOCBToken		;a hash-token?
	beq setiocb		;if so, set stdout
	;; here: None of the above. An expression
	jsr GetArgument		;get what needs printing
	dec StatementOffset
	bit VariableType	;string or numeric?
	bmi printstring
	;; here numeric
	jsr FixedBCDToAscii	;convert to string
	ldy #0
	sty cix
prnum:
	ldy cix
	lda (inbuff),y		;get the next character
	pha
	inc cix
	and #$7f		;mask off the MSB
	jsr CountAndPrintChar
	pla
	bpl prnum
	bmi prloop
printstring:
	jsr GetStringAddress	;get the absolute address of the string
prsloop:	
	ldx #StringLength
	jsr DecrementZeroPagePtr
	beq prloop		;once done, continue
	lda (VariablePointer-StringLength,x)
	jsr CountAndPrintChar
	inc VariablePointer	;go get the next character
	bne prsloop
	inc VariablePointer+1
	bne prsloop
prcomma:			;here a comma: fill up to the next multiple of the colon width
	ldy PrintCounter	;characters printed so far
	iny
	cpy PrintOffset		;reached a stop position?
	bcc foundstop
	;; not here, ok, try the next multiple
	clc
	lda PrintColonWidth
	adc PrintOffset
	sta PrintOffset
	bcc prcomma
foundstop:			;found the next possible stop position
	ldy PrintCounter
	cpy PrintOffset		;if reached, done
	bcs commadone
	lda #' '
	jsr CountAndPrintChar	;fill up with blanks
	bpl foundstop		;jumps always
commadone:
prsemicolon:			;this does nothing
	inc StatementOffset 	;skip over statement
	bne prloop		;jumps always
setiocb:			;here print over a channel
	jsr GetIOCB		;get an IOCB. Again, Basic allows #0 here
	sta ListIOCB		;store it here
	dec StatementOffset 	;need the separator again
	bne prloop
preol:				;here done.
	lda InputMode		;get the last token printed
	cmp #CommaToken		;if a comma
	beq exit
	cmp #SemicolonToken	;or a semicolon
	beq exit		;then do nothing
	lda #$9b
	jsr PrintChar		;otherwise, put an EOL over the stream
exit:
	lda #0
	sta ListIOCB		;reset stdout
	rts
.endproc
;;; *** ExecuteLPrint (XLPRINT in Atari Basic)
;;; *** Execute the LPrint statement
;;; *** FIXME: This is probably one of the statements that can go
	.global ExecuteLPrint
.proc	ExecuteLPrint
	lda #<PrinterName
	ldy #>PrinterName
	jsr Loadinbuff
	ldx #7
	stx ListIOCB  		;print over IOCB #7
	lda #8			;AUX1
	jsr OpenIOCB7Aux2Z
	jsr TestForIOError	;worked?
	jsr ExecutePrint	;do the printing now
	jmp CloseIOCB		;and close again
	;; Atari Basic restores inbuff here. Why?
.endproc
;;; *** ExecuteEnter (XENTER in Atari Basic)
;;; *** Executes the ENTER command.
;;; *** Actually, all it does is that it reseats
;;; *** stdin to the specified filespec.
;;; *** FIXME: Test whether it is useful to return to
;;; *** program execution when done.
	.global ExecuteEnter
.proc	ExecuteEnter
	lda #4
	jsr OpenAltChannel	;open the channel to enter from
	lda #7
	sta EnterIOCB
	inc GenerationCounter	;may change the program now
	jmp Syntax		;go to the syntax parser
.endproc
;;; *** ExecuteList (XLIST in Atari Basic)
;;; *** Execute the LIST statement
	.global ExecuteList
.proc	ExecuteList
	ldy #0
	sty TargetLineNumber	;start line number: 0
	sty TargetLineNumber+1	;end line number
	lda #$9b
	sta DirectFlag		;do not execute control characters
	jsr PrintChar		;do we need that??
	jsr SaveStatementOffset	;mark the start of LIST
	;; now check whether there are any arguments
tryagain:
	jsr TestStatementEnd
	bcs startfull		;start immediately
	lda StatementOffset
	pha			;keep the position
	jsr GetArgument		;this can be either a target file name or a line number range
	pla
	sta StatementOffset 	;return, OpenAltChannel evaluates again
	lda VariableType	;is this a number
	bpl startline
	;; here a string. Ok, list the string
	lda #8			;the open mode
	jsr OpenAltChannel	;over the Basic secondary IOCB#7
	lda #7			;Use this IOCB
	sta ListIOCB
	bpl tryagain		;go go again
startline:			;here a start line is present
	jsr GetLineNumber	;get the line number
	sty TargetLineNumber+1
	sta TargetLineNumber	;copy to the target line number
	;; is this the only argument?
	ldx StatementOffset
	cpx StatementEnd
	beq endline
	inx
	;; a single comma?
startfull:
	ldy #$7f
	lda #$ff
	cpx StatementEnd
	bcs endline		;if so, list to the end of the file
	jsr GetLineNumber	;get the end line number
endline:
	sty ListEndLineNumber+1
	sta ListEndLineNumber
	;; listing starts here.
startlist:
	jsr PushProgramLine	;now on the stack with you
	jsr FindTargetLine	;find the first line
listloop:
	jsr TestIfDirect	;if this is the direct line, stop
	bmi done
	ldy #0
	lda ListEndLineNumber
	cmp (CurrentLinePtr),y
	lda ListEndLineNumber+1
	iny
	sbc (CurrentLinePtr),y	;below target line?
	bcc done
	jsr ListLine		;perform the actual decoding
	jsr GetLineLength
	jsr GetNextLine		;and advance the line
	lda BreakFlag		;user hit BREAK?
	bne listloop		;if not break, continue
done:
	;; here: aborted by break or because the end has been found
	jsr CloseIOCB		;close the IOCB again (NOP if the IOCB is zero)
	lda #0
	sta ListIOCB		;reset stdout
	sta DirectFlag		;again execute control characters.
	jmp PopProgramPosition	;and restore the current position.
.endproc
;;; *** ListLine (LLINE in Atari Basic)
;;; *** list an entire line pointed to by CurrentLinePtr
;;; *** including the line number
	.global ListLine
.proc	ListLine
	jsr PrintLineNumber
	;; runs into the following
.endproc
;;; *** ListDirectLine (LPLINE in Atari Basic)
;;; *** Print the line excluding the line number
;;; *** Returns with C set!
	.global ListDirectLine
.proc	ListDirectLine
	jsr GetLineLength
	sta LineLength
	iny
listloop:
	lda (CurrentLinePtr),y
	sta StatementEnd	;get offset of next statement
	iny
	sty StatementOffset 	;start of current statement
	jsr ListStatement	;print the statement at this offset
	ldy StatementEnd 	;get next offset
	cpy LineLength
	bcc listloop		;continue until the line is done
	rts
.endproc
;;; *** ListStatement (LSTMT in Atari Basic)
;;; *** List the statement at CurrentLinePtr, at offset StatementOffset
.proc	ListStatement
	jsr GetListToken
	cmp #ImplicitLetToken	;variable directly?
	beq printargs
	pha
	jsr PrintStatement	;print the statement
	pla			;get again
	cmp #ErrorToken		;the token of ERROR -
	beq outputdata		;output the following data directly
	cmp #INPUTToken		;all regular commands
	bcs printargs
	;; here REM or DATA: This prints the data directly until the end of the data
outputdata:			;or ERROR
	jsr GetNextListToken
	jsr PrintChar		;print the data. When done, GetNextListToken returns
	bpl outputdata		;aborts by GetNextListToken
	;; here a statement that takes tokenized arguments (the regular case)
printargs:
	ldx #0			;zero extra bytes in the table
	jsr GetNextListToken
	bpl isoperand
	;; here: is a variable
	and #$7f
	sta ScanOffset		;the variable number
	lda VarNamePtr+1	;variable names
	ldy VarNamePtr		;X is already zero
	jsr SearchForToken	;look for the variable name
	jsr PrintString		;and print the variable name
	cmp #'('+$80		;an array?
	bne printargs		;if not, continue printing the expression
	;; here: an array variable that has to be printed
	;; next token is a ( anyhow and does not need printing
	inc StatementOffset
	bne printargs		;jumps always
isoperand:
	cmp #StringToken 	;a constant string in quotes?
	beq printstringconst
	bcs printoperand
	;; here: a constant number
	jsr GetNextBCD		;read a BCD number from the statement
	sty StatementOffset 	;restore the token pointer
	jsr FixedBCDToAscii	;convert number to ASCII
	jsr LoadinbuffToPrintPtr
nonblank:			;used below. print operand directly
	jsr PrintString		;and print the number
	bmi printargs		;continue with the tokens (jumps always)
	;; print a string constant
printstringconst:
	jsr GetNextListToken	;read the next token
	sta PrintOffset		;is string length
	lda #$22		;double quote
	jsr PrintChar
	lda PrintOffset
	beq prdone
prstring:	
	jsr GetNextListToken
	jsr PrintChar		;print the contents of the string
	dec PrintOffset		;until done
	bne prstring
prdone:
	lda #$22		;another double quote
	jsr PrintChar
	bpl printargs		;and continue
	;; print a tokenized operand
printoperand:
	pha
	sbc #CommaToken		;C=1. Compute the offset in the operand table
	sta ScanOffset
	lda #>OperatorTable
	ldy #<OperatorTable	;X is already zero
	jsr SearchForToken	;find token name
	pla			;get again
	cmp #STRToken		;regular functions?
	bcs nonblank		;without blanks around them, please
	ldy #0
	lda (ScanPtr),y		;get the name of the beast
	and #$7f
	jsr IsAlpha		;can this be printed?
	bcs nonblank		;print without spaces around it (things like +,-,*,/...)
	jsr PrintBlankStringAndBlank ;otherwise, put blanks around it
	bpl printargs		;continue
	;; code never goes here, returns by falling off GetNextListToken
GetNextListToken:	
	inc StatementOffset
	;; runs into the following
GetListToken:	
	ldy StatementOffset
	cpy StatementEnd 	; below end?
	bcc tokenok
	pla
	pla			; return to caller
tokenok:	
	lda (CurrentLinePtr),y
	rts
.endproc

;;; ********************* Flow and program control ************************************
;;; *** ExecuteOn (XON in Atari Basic)
;;; *** Execute the ON .. GOTO/GOSUB statement
;;; *** THOR: Atari Basic had a bug here by pushing the source
;;; *** on the stack with ON .. GOSUB without even validating
;;; *** whether there is a target.
	.global ExecuteOn
.proc	ExecuteOn
	jsr SaveStatementOffset	;keep the statement offset
	jsr GetByte		;error if the offset is too large
	lda fr0
	beq fallthrough		;if zero, fall through
	sta OnValue		;keep the value
	ldy StatementOffset 	;check whether this is gosub or goto
	dey
	lda (CurrentLinePtr),y
	cmp #GotoOperatorToken
	php			;keep the indicator whether this is gosub or goto
onloop:
	jsr GetLineNumber	;get the next line to jump to
	dec OnValue		;if this is the jump target
	bne next
				;here: found the statement
	plp
	beq GotoLineYA		;if it is the GOTO token, execute the goto. Line number is already in AY (this cleans up the stack anyhow...)
	bne GosubLine		;otherwise, execute Gosub
next:	
	jsr TestStatementEnd	;more data coming?
	bcc onloop		;if so, continue
	plp			;clean up the stack
fallthrough:
	rts
.endproc
;;; *** ExecuteIf (XIF in Atari Basic)
;;; *** Execute the IF statement
	.global ExecuteIf
.proc	ExecuteIf
	jsr GetArgument		;get its argument
	;; Test for zero/nonzero. This should probably use the correct zero testing, though
	;; this also allows an "almost zero" that may be desirable. So leave it for now as is.
	jsr TestFr0Sign		;is zero?
	beq skipend		;if so, expression is false and skip to the end of it
	;; here is true. What follows can be either a new statement, or a line number.
	jsr TestStatementEnd	;reached end of statement?
	bcc ExecuteGoto		;if not, execute the GOTO statement, a line number is the argument
	;; here no statement follows, thus all the following statements are executed
	rts			;here done, empty argument
skipend:			;condition false, jump to the end of the statement
	lda LineLength		;move to the end of the line
	sta StatementEnd
	rts
.endproc
;;; *** ExecuteGosub (XGOSUB in Atari Basic)
;;; *** Execute the GOSUB statement
	.global ExecuteGosub
.proc	ExecuteGosub
	jsr SaveStatementOffset
	jsr GetLineNumber
	;; runs into the following
.endproc
;;; *** GosubLine (not present in Atari Basic)
;;; *** Gosub to the given line, error if not present
.proc	GosubLine
	jsr PushProgramLine	;and place the return address on the stack
	lda fr0
	ldy fr0+1
	jsr FindTargetLineYA
	bcc GoExecute
	jsr PopProgramPosition	;restore the program PC
	;; runs into the following
.endproc
;;; *** ErrorLine
;;; *** Create an error that the given line was not found
.proc	ErrorLine
	jsr RestoreCurrentLine	;restore were we came from
	Error LineNotFound
.endproc
;;; *** ExecuteGoto (XGOTO in Atari Basic)
;;; *** Execute the goto statement, branch to a line
;;; *** This is also used by the If statement.
	.global ExecuteGoto
.proc	ExecuteGoto
	jsr GetLineNumber	;get the target line
	;; runs into the following
.endproc
;;; *** GotoLineAY (almost, but not exactly like XGO1 in Atari Basic)
;;; *** continue execution at line (A,Y)
	.global GotoLineYA
.proc	GotoLineYA
	jsr FindTargetLineYA	;find the line we jump to
	bcs ErrorLine
	;; here: line found. Do not execute the rest of the statement,
	;; rather redo from the target line
	;; runs into the following on success
.endproc
;;; *** GoExecute
;;; *** Start program execution at a new line
.proc GoExecute
	;; As this is could be called from TRAP, and the
	;; stack could be arbitrarily deep, it would be better if
	;; we would keep a stack pointer somewhere and restore it
	;; here instead of assuming we're just two levels deep.
	;; Actually, we are always top level here...
	ldx #$ff
	txs
	jmp ExecuteProgram
.endproc
;;; *** ExecuteFor (XFOR in Atari Basic)
;;; *** This function executes the FOR statement
	.global ExecuteFor
.proc	ExecuteFor
	jsr SaveStatementOffset	;where we are, at the start of FOR
	jsr EvaluateExpression	;this is part of the variable assigment
	lda VariableIndex	;get the variable of the counter
	ora #$80		;mark it as a non-GOSUB stack frame
	;; THOR: FIXME: This is all a mess. The BASIC program should be
	;; organized such that messing with stack frames is not
	;; necessary
	;; now fixup the stack frame (originally part of FIXRSTK)
	sta ForVariableIdx	;keep the variable index
	jsr SaveStackPtr	;keep current stack pointer in RunStackPtr
fixloop:
	jsr PopFromStack	;get the topmost element
	bcs stackok		;if the stack is empty, this is ok
	beq stackok		;if the topmost element is from GOSUB, also ok
	cmp ForVariableIdx	;is it our stack frame?
	bne fixloop		;if not, keep looking
	;; here we found a stack entry we already used before in a former FOR, probably
	;; because the program flow GOTO to a FOR that was started earlier. Keep reusing this
	;; stack frame. Everything above on the stack is now thrown away.
	beq nodrop
stackok:			;ok, do not remove the GOTO/GOSUB element
	jsr RestoreStackPtr
nodrop:
	;; now build a new stack element
	ldy #SFOR_Size		;requires 12 bytes as stack frame
	jsr EnlargeRunStack	;make room on the stack
	jsr GetArgument		;get the end value behind TO
	ldy #SFOR_Limit
	jsr WriteBCDToRunStack	;push the limit on the run stack
	;; get the STEP argument.
	jsr OneToFr0		;default is 1.0
	jsr TestStatementEnd	;at the end of FOR?
	bcs foundstep		;if so, keep STEP at default
	jsr GetArgument		;otherwise, retrieve the STEP size
foundstep:
	ldy #SFOR_Step		;and place it here on the stack
	jsr WriteBCDToRunStack	;as well
	lda ForVariableIdx	;get the variable back
	jmp PushOnRunStack	;and push the end of FOR onto the RUN stack
.endproc
;;; *** ExecuteNext (XNEXT in Atari Basic)
;;; *** Execute the NEXT statement, ending a FOR loop
	.global ExecuteNext
.proc	ExecuteNext
	ldy StatementOffset 	;get the loop variable
	lda (CurrentLinePtr),y
	sta ForVariableIdx	;keep me for later
	;; again, find the stack frame for this loop
	;; THOR: Fixme: this is a big mess. There is really
	;; no need to fixup the stack here. Basic programs
	;; should better have the stack organized correctly.
findframe:
	jsr SaveStackPtr  	;save the start of the stack frame.
	jsr PopFromStack	;get the topmost element
	bcs noforfound		;if the stack is empty
	beq noforfound		;or the stack frame belongs to GOSUB, error!
	cmp ForVariableIdx	;found the variable?
	bne findframe		;if not, continue (Actually, it should error here!)
	
	ldy #SFOR_Step
	jsr ReadBCDFromRunStack	;get the step size to fr1
	lda fr1			;keep the sign (to test whether we are beyond the end)
	sta StepSign		;for later. Only bit 7 is interesting here.
	lda ForVariableIdx	;get the variable into fr0
	jsr GetVariable
	jsr AddNumeric		;add step to the loop variable
	jsr SetVariable		;and restore back
	;; now check whether we are at (or above) the limit
	ldy #SFOR_Limit
	jsr ReadBCDFromRunStack	;again into fr1
	jsr CompareOperatorNumeric ;and test
	beq iterate		;if equal, continue with the iteration
	eor StepSign		;otherwise, check whether we are already above the limit
	bpl exit		;if so, next is done
iterate:			;go for the next loop
	jsr RestoreStackPtr	;restore the run time stack pointer
	jsr GetStackToken	;test top of the stack, and also load stack position into the line pointer
	cmp #FORToken		;is it for?
	bne noforfound
exit:
	rts
noforfound:
	Error ForNotFound
.endproc
;;; *** ExecuteTrap (XTRAP in Atari Basic)
;;; *** Execute the trap instruction
	.global ExecuteTrap
.proc	ExecuteTrap
	jsr GetInteger		;get the argument
	sta TrapLine
	sty TrapLine+1
	rts
.endproc
;;; *** ExecuteBye (XBYE in Atari Basic)
;;; *** Execute to the memopad or selftest or DUP
	.global ExecuteBye
.proc	ExecuteBye
	jsr CloseAll
	jmp ByeVector
.endproc
;;; *** ExecuteDos (XDOS in Atari Basic)
;;; *** Execute to the DUP
	.global ExecuteDos
.proc	ExecuteDos
	jsr CloseAll
	jmp (DosVector)
.endproc
	
;;; *** ExecuteStop (XSTOP in Atari basic)
;;; *** Execute the STOP command
	.global ExecuteStop
.proc	ExecuteStop
	jsr Stop
	jsr PrintCR
	lda #>StoppedMsg
	ldy #<StoppedMsg
	jsr PrintStringAY
	jmp AbortAtLineMessage	;and abort the program execution
.endproc
;;; *** ExecuteNew
;;; *** This implements the NEW command
	.global ExecuteNew
.proc	ExecuteNew
	jsr InitializeMemory
	;; runs into the following
.endproc
;;; *** ExecuteEnd (XEND in Atari Basic)
;;; *** Execute the END statement
	.global ExecuteEnd
.proc	ExecuteEnd
	lda #$80
	sta StopLine+1		;do not continue
	;; NOTE: WarmerStart also resets Stdin and Stdout, so
	;; no need to do that here.
	;; runs into the following
.endproc
;;; *** StopRunning (:RUNEND in Atari Basic)
;;; *** Stop program execution
.proc	StopRunning
	jmp WarmerStart
.endproc
;;; *** ExecuteError
;;; *** Executes the ERROR token
	.global ExecuteError
.proc	ExecuteError
	Error InvalidToken
.endproc
;;; *** ExecuteCont (XCONT in Atari Basic)
;;; *** Execut the CONT command
	.global ExecuteCont
.proc	ExecuteCont
	jsr TestIfDirect	;in direct mode?
	bpl direct
	ldy StopLine+1
	bmi StopRunning		;THOR: Do not continue if the stop line is not set.
	lda StopLine
	jsr FindTargetLineYA	;find the line were we stopped
	bcs notfound		;if not found, we are already at the next line
	jsr TestIfDirect
	bmi StopRunning		;if not found, then no continue
	jsr GetLineLength	;get where we stopped
	jsr GetNextLine		;and advance to the next line
notfound:
	jsr TestIfDirect
	bmi StopRunning
	;; since line offsets may have changed due to editing the
	;; source, invalidate absolute addresses
	inc GenerationCounter
	jmp SetupLineOffsets	;and done with it.
direct:	
	jmp ResetEnterListIOCB	;just reset stdin and stdout. This is for ENTERing a CONT, or a CONT in a program (which does nothing)
.endproc

;;; *****************

;;; *** ExecuteCom (XCOM in Atari Basic)
;;; *** Execute the COM statement
	.global ExecuteCom
.proc	ExecuteCom
	;; runs into the following
.endproc
;;; *** ExecuteDim (XDIM in Atari Basic)
;;; *** Execute the DIM statement
	.global ExecuteDim
.proc	ExecuteDim
	;; since multiple arrays can be dimensioned at once,
	;; check whether there are any left
dimloop:
	ldy StatementOffset
	cpy StatementEnd
	bcs done		;if none left, leave
	jsr EvaluateExpression	;get the variable that is to be dimensioned
	lda VariableType	;is this already dim'd?
	ror a
	bcs dimerror		;if so, error
	sec
	rol a			;set the flag
	sta VariableType
	bmi dimstring		;if this is a string, dim there
	;; here a numerical array
	;; as a side effect of the evaluation, the first dimension is in ztemp1
	;; and the second in index2
	ldy Index1
	ldx Index1+1		;get first dimension
	jsr addone
	sty Index1
	stx Index1+1		;put back for multiplication
	sty FirstArrayDimension
	stx FirstArrayDimension+1 ;and keep here
	;; now for the second dimension
	ldy Index2
	ldx Index2+1
	jsr addone
	sty SecondArrayDimension
	stx SecondArrayDimension+1
	jsr ZTempTimesDim2	;get the array size in elements
	jsr ZTempTimes6		;get number of bytes to reserve
	bcc allocate		;hopefully....
dimstring:			;here allocate a string
	lda #0
	sta StringLength
	sta StringLength+1	;set the size of the string to zero
	lda Index1
	sta StringDimension
	lda Index1+1
	sta StringDimension+1	;set size of the string
	ora Index1		;should better not be zero
	beq dimerror
allocate:
	ldy ztemp1		;get size (Index1 = ztemp1)
	lda ztemp1+1
	ldx #RunStack		;above the array buffer
	jsr AllocMem
	sec
	lda AllocMemPtr
	sbc ArrayTablePtr
	sta VariablePointer
	lda AllocMemPtr+1
	sbc ArrayTablePtr+1
	sta VariablePointer+1
	jsr SetVariable		;and install the new value including the DIM'd flag
	bmi dimloop		;jumps always
done:	
	rts
dimerror:
	Error DIMMismatch
addone:
	iny
	bne noinc
	inx
	beq dimerror
noinc:
	rts
.endproc
;;; *** ExecuteRun (XRUN in Atari Basic)
;;; *** Executes the RUN statement. Either starts the program, or
;;; *** loads one from file and runs it.
	.global ExecuteRun
.proc	ExecuteRun
	jsr TestStatementEnd	;any argument here?
	bcs noargument
	jsr LoadFromFile		;if there is an argument, first load the file from disk
noargument:
	;; runs into the following
.endproc
;;; *** RunProgram
;;; *** Run the loaded program - if there is any
.proc	RunProgram
	jsr CloseAll		;NEW: Close everything before we continue
	lda #0
	sta TargetLineNumber
	sta TargetLineNumber+1	;start from the first line
	jsr SetupLine		;load this line
	jsr TestIfDirect	;in direct mode
	bpl init
	jmp WarmerStart		;no program there, do not execute the stored direct line
init:	
	jsr RunInit
	;; runs into CLR now, then continue execution from the first line of the loaded program
.endproc
;;; *** ExecuteClr (XCLR in Atari Basic)
;;; *** Execute the CLR statement, un-do all DIMs, clear all variables
	.global ExecuteClr
.proc	ExecuteClr
	;; first zero all variables (this is ZVAR in Atari basic)
	lda VarValuePtr
	sta ztemp1
	lda VarValuePtr+1
	sta ztemp1+1
loop:
	ldy #0
	lda ztemp1
	cmp StatementPtr
	lda ztemp1+1
	sbc StatementPtr+1
	bcs clrdone		;if above the last variable, we are done
	;; first, remove the dim flag
	lda (ztemp1),y
	and #(~(VTYPE_Dimensioned|VTYPE_Absolute) & 255)
	sta (ztemp1),y
	tya			;clear the next six bytes, i.e. the variable pointer, dimension or value
	iny
	iny
clrlp:
	sta (ztemp1),y
	iny
	cpy #8
	bcc clrlp
	tya
	clc
	adc ztemp1		;and continue with the next variable
	sta ztemp1
	bcc loop
	inc ztemp1+1
	bcs loop
	;; here variables are cleared
clrdone:
	sty GenerationCounter	;stack is initialized, return stack is lost anyhow
	lda ArrayTablePtr
	sta RunStack		;clear the array value table
	ldy ArrayTablePtr+1
	sty RunStack+1
	jmp SetHiMem		;and reset HiMem
.endproc
;;; ***************** Miscellaneous commands follow ***************************************
;;; *** ExecutePoke (XPOKE in Atari Basic)
;;; *** Implements the POKE statement
	.global ExecutePoke
.proc	ExecutePoke
	jsr GetInteger
	sta PrintPtr
	sty PrintPtr+1
	jsr GetByte
	lda fr0
	;; ldy #0		;is already zero
	sta (PrintPtr),y	;execute the mess
	rts
.endproc
;;; *** ExecuteDeg (XDEG in Atari Basic)
;;; *** Execute the DEG statement, switch to degrees.
	.global ExecuteDeg
.proc	ExecuteDeg
	lda #6
	Skip2
	;; runs into the following
.endproc
;;; *** ExecuteRad (XRAD in Atari Basic)
;;; *** Executes the RAD statement, switches to radiants
	.global ExecuteRad
.proc	ExecuteRad
	lda #0
	sta RadFlag
	rts
.endproc
;;; *** ExecuteRestore (XRESTORE in Atari Basic)
;;; *** Execute the RESTORE statement and resets the
;;; *** the line where to read DATA from.
	.global ExecuteRestore
.proc	ExecuteRestore
	lda #0
	tay			;reset Y as well
	sta DataOffset		;always start of the line
	jsr TestStatementEnd	;reached the end of the statement
	bcs setline		;if so, set the line to zero
	jsr GetInteger		;THOR why not positive int?
setline:
	sta DataLine
	sty DataLine+1		;and set the line where to read from
	rts
.endproc
;;; *** ExecuteColor (Atari Basic XCOLOR)
;;; *** Implementation of the COLOR statement
	.global ExecuteColor
.proc	ExecuteColor
	jsr GetByte		;THOR: This was GetInteger Fixme: why not GETBYTE?
	sta Color
	rts
.endproc
;;; *** ExecuteSetcolor (Atari Basic XSETCOLOR)
;;; *** Execute the SETCOLOR statement.
;;; *** THOR: This should probably also set player colors.
	.global ExecuteSetcolor
.proc	ExecuteSetcolor
	jsr GetByte		;THOR: This was GetInteger (should really be a byte!)
	cmp #5			;THOR: Allow player colors?
	bcs Go2ValueError
	sta ChannelOffset	;keep keep
	jsr GetNibbleArgs	;get hue and luminance
	sta Color0Shadow,x	;install the value
	rts
.endproc
Go2ValueError:
	Error ValueError
;;; *** ExecuteSound (XSOUND in Atari Basic)
;;; *** Play a sound over a given channel
	.global ExecuteSound
.proc	ExecuteSound
	jsr GetByte		;THOR: This was GetInteger (should really be a byte!)
	cmp #4
	bcs Go2ValueError	;only four channels
	asl a			;every channel takes two bytes
	sta ChannelOffset	;keep keep
	lda SkStatShadow
	and #$07		;clear all bits relevant for audio output
	sta SkStatShadow
	sta SkStat		;reset pokey
	lda #0
	sta AudioCtrl		;really
	;jsr GetByte		;get the frequency
	;; too many programs simply put "something" here, and depend on basic ignoring the high-byte... sigh
	jsr GetInteger
	ldx ChannelOffset
	sta AudFreq0,x		;set the frequency
	jsr GetNibbleArgs	;the next two args are distortion and volume
	sta AudCtrl0,x		;and set distortion and volume
	rts
.endproc
;;; *** GetNibbleArgs
;;; *** Retrieve two arguments, the first argument goes to the high-nibble,
;;; *** the second into the low-nibble, return the result in A
.proc	GetNibbleArgs
	jsr GetInteger		;get the distortion or color
	asl a
	asl a
	asl a
	asl a
	pha
	;jsr GetByte		;get the volume or the luminance
	;; ditto, see above. Too much nonsense done here
	jsr GetInteger
	pla
	adc fr0			;carry is clear (from getInteger)
	ldx ChannelOffset
	rts
.endproc
;;; ***************** I/O related commands follow ***************************************
;;; *** ExecuteGraphics (XGR in Atari Basic)
;;; *** Execute the GRAPHICS statement, open a screen
	.global ExecuteGraphics
.proc	ExecuteGraphics
	jsr GetByte		;THOR: Fix. Was GetInteger. Get this first
	lda #6
	sta IOCB		;over IOCB #6
	jsr CloseIOCB		;first close it
	lda #<ScreenName
	ldy #>ScreenName
	jsr Loadinbuff		;over the screen.
	ldx #6
	lda fr0
	and #$f0		;mask out the upper bits, they define the text window mode
	eor #$1c		;make read-write, invert the text-window mode
	tay			;make this aux2
	lda fr0			;re-read aux1
	jsr OpenIOCB		;open it now
	jmp TestForIOError	;and check for errors
.endproc
;;; *** ExecuteXIO (XXIO in Atari Basic)
;;; *** Run the XIO command
	.global ExecuteXIO
.proc	ExecuteXIO
	jsr GetByte		;get the command number
	Skip2
	;; runs into the following
.endproc
;;; *** ExecuteOPEN (XOPEN in Atari Basic)
;;; *** Run the Open Command
	.global ExecuteOpen
.proc	ExecuteOpen
	lda #CmdOpen
	sta IOCommand		;what is to be executed
	;; now get the channel
	jsr GetValidIOCB	;get IOCB and validate
	jsr GetByte		;and AUX1
	pha
	jsr GetByte		;and AUX2
	pha
	jsr GetFileSpec		;get the argument
	jsr LoadIOCBOffset
	pla
	sta IOCBAux2,x		;store aux2
	pla
	sta IOCBAux1,x
	jsr CallCIOOnInputBuffer ;and run the command
	;; atari Basic restored here the INBUFF, why?
	jmp TestForIOError	;any error? If so, report
.endproc
;;; *** OpenAltChannel (ELADVC in Atari Basic)
;;; *** Open the alternative channel #7 with the
;;; *** filespec taken from the current argument
;;; *** mode in A.
;;; *** Used for LIST,ENTER,SAVE,LOAD
	.global OpenAltChannel
.proc	OpenAltChannel
	pha
	jsr GetFileSpec
	pla
	jsr OpenIOCB7Aux2Z
	jmp TestForIOError
.endproc
;;; *** ExecuteClose (XCLOSE in Atari basic)
;;; *** closes the indicated channel
	.global ExecuteClose
.proc	ExecuteClose
	lda #CmdClose
	;; runs into the following
.endproc
;;; *** GenericCmdIo (GDVCIO in Atari Basic)
;;; *** Execute the IO Command in A without further
;;; *** arguments.
.proc	GenericCmdIo
	sta IOCommand
	jsr GetValidIOCB
	jsr CallCIOIOCmd
	jmp TestForIOError
.endproc
;;; *** ExecuteStatus (XSTATUS in Atari Basic)
;;; *** Execute the STATUS statement
	.global ExecuteStatus
.proc	ExecuteStatus
	jsr GetValidIOCB
	jsr GetLValue
	lda #CmdStatus
	jsr CallCIOCmd
	;; do not test for error, use the status
	;; as result code
	jsr GetIOCBStatus	;get status code
	jmp SetVariableToIntLo	;and set the variable.
.endproc
;;; *** ExecuteNote (XNOTE in Atari Basic)
;;; *** Execute the NOTE command
	.global ExecuteNote
.proc	ExecuteNote
	lda #CmdNote
	jsr GenericCmdIo
	jsr GetLValue
	jsr LoadIOCBOffset
	lda IOCBAux3,x		;low
	ldy IOCBAux4,x		;high
	jsr SetVariableToInt	;install as first argument
	jsr GetLValue
	jsr LoadIOCBOffset	;get again IOCB
	lda IOCBAux5,x
	jmp SetVariableToIntLo	;and the second argument
.endproc
;;; *** ExecutePoint (XPOINT in Atari Basic)
;;; *** Execute the POINT command
	.global ExecutePoint
.proc	ExecutePoint
	jsr GetValidIOCB	;get the IOCB to run on
	jsr GetInteger		;get first argument.
	jsr LoadIOCBOffset	;IOCB offset
	lda fr0
	sta IOCBAux3,x
	lda fr0+1
	sta IOCBAux4,x		;install first argument
	jsr GetByte		;get second argument (FIXME: should probably be: GetByte)
	jsr LoadIOCBOffset
	lda fr0
	sta IOCBAux5,x
	lda #CmdPoint
	jsr CallCIOCmd
	jmp TestForIOError
.endproc
;;; *** ExecutePut (XPUT in Atari Basic)
;;; *** Implementation of the PUT statement
	.global ExecutePut
.proc	ExecutePut
	jsr GetValidIOCB
	jsr GetByte	;THOR fix: this was GetInteger GetByte?
	ldx IOCB
	jmp PrintCharIOCB	;use the Put one byte vector
.endproc
;;; *** ExecuteGet (XGET in Atari Basic)
;;; *** Implementation of the GET command
	.global ExecuteGet
.proc	ExecuteGet
	jsr GetValidIOCB
	;; runs into the following
.endproc
;;; *** ReadCharacterFromIOCB (GET1 in Atari Basic)
;;; *** Reads one character from IOCB, sets the variable.
.proc	ReadCharacterFromIOCB
	lda #CmdGetBlock
	sta IOCommand
	jsr LoadOutbuffVector	;was missing in Basic: read to the output buffer
	ldy #1
	jsr CallCIOOnShortBuffer ;read the byte
	jsr TestForIOError
	jsr GetLValue
	ldy #0
	lda (inbuff),y		;get the read byte
	jmp SetVariableToInt	;install the result
.endproc
;;; *** ExecutePosition (XPOS in Atari Basic)
;;; *** Executes the POSITION statement
	.global ExecutePosition
.proc	ExecutePosition
	;; runs into the following...
	;; it seemed smart to set the OldColorRow here
	;; to allow a sequence of Position:Drawto
	;; commands, but that would break existing POSITION...:XIO 18,#6...
	;; sequences for area fill, so don't....
.endproc
;;; *** GetPosition
;;; *** Retrieve a cursor coordinate.
.proc	GetPosition
	jsr GetInteger		;FIXME Atari Basic had only GetInteger here. Useful?
	sta CursorColumn
	sty CursorColumn+1	;set X position
	jsr GetByte
	sta CursorRow		;set cursor Y position
	rts
.endproc
;;; *** ExecutePlot (XPLOT in Atari Basic)
;;; *** Executes the PLOT statement
	.global ExecutePlot
.proc	ExecutePlot
	jsr GetPosition		;first place the cursor
	lda Color
	ldx #6			;over channel #6
	jmp PrintCharIOCB	;perform priting
.endproc
;;; *** ExecuteDrawto (XDRAWTO in Atari Basic)
;;; *** Executes the DRAWTO statement
	.global ExecuteDrawto
.proc	ExecuteDrawto
	jsr GetPosition		;first place the cursor at the end of the line
	lda Color
	sta ScreenByte		;set the color for the line
	lda #CmdDrawTo		;the line drawer
	ldx #6			;over IOCB #6
	jsr LoadIOCBCmdAndOffset
	;; atari basic also sets here AUX1 and AUX2. This is however not even
	;; used by the Os, so avoid this
	jsr CallCIOIOCmd	;run the line drawer
	jmp TestForIOError	;done
.endproc
;;; *** ExecuteLocate (XLOCATE in Atari Basic)
;;; *** Executes the LOCATE statement
	.global ExecuteLocate
.proc	ExecuteLocate
	jsr ExecutePosition	;first place the cursor
	ldx #6			;over the screen channel
	jsr LoadIOCBOffsetFromX
	bne ReadCharacterFromIOCB ;branches always. Read the character
.endproc
;;; *** ExecuteCLoad (XCLOAD in Atari Basic)
;;; *** Execute the CLOAD command
;;; *** Load a file from tape, do not run it.
;;; *** FIXME: This is probably a command that can go.
	.global ExecuteCLoad
.proc	ExecuteCLoad
	lda #4
	jsr OpenTape
	jsr LoadFromIOCB
	jmp WarmerStart		;and do not start the program.
.endproc
;;; *** RunAutorun
;;; *** Try to locate the autorun file, run it if it is there
	.global RunAutorun
.proc	RunAutorun
	lda #<AutorunName
	ldy #>AutorunName
	jsr Loadinbuff
	lda #4
	jsr OpenIOCB7Aux2Z
	bmi exit		;if this did not work, do not bother
	jsr LoadFromIOCB
	jsr RunProgram		;this already branches off in case there is no program
	jmp ExecuteProgram
exit:
	rts
.endproc
;;; *** ExecuteLoad (XLOAD in Atari Basic)
;;; *** Executes the LOAD statement to load a tokenized file from disk
	.global ExecuteLoad
.proc	ExecuteLoad
	jsr LoadFromFile	;but then finally...
	jmp WarmerStart		;run into the warm start
.endproc
;;; *** LoadFromFile (FRUN in Atari Basic)
;;; *** Load a file form disk, then run it.
.proc	LoadFromFile
	lda #4			;open for read
	jsr OpenAltChannel	;channel #7
	;; runs into the following
.endproc
;;; *** LoadFromIOCB
;;; *** This is the load/run entry point which loads from channel #7
;;; *** Unlike Atari Basic, there is no Run/Load flag. If you want
;;; *** to load a program, run into WarmerStart afterwards. Otherwise,
;;; *** run into RunProgram.
.proc	LoadFromIOCB
	lda #CmdGetBlock
	sta IOCommand
	jsr LoadOutbuffVector	;load into outbuff
	jsr LoadIOCBOffset
	ldy #RunStack-LoMem	;the zero-page offsets that are part of the basic header
	jsr CallCIOOnShortBuffer ;load the z-page offsets
	jsr TestForIOError
	lda outbuff
	ora outbuff+1		;the offset from lomem to lomem must be zero (-:
	bne loaderror
	;; now adjust the offsets
	ldx #ArrayTablePtr-LoMem ;the offsets to adjust
	stx LoadFlag		;from now on: Tables become invalid
adjloop:
	clc
	lda outbuff,x
	adc LoMem
	tay			;keep lo
	lda outbuff+1,x
	adc LoMem+1		;correct the offset
	;; now test whether the program still fits
	pha
	cpy MemTop
	sbc MemTop+1
	bcs ovflow		;overflow if above himem
	pla
	sta LoMem+1,x
	sty LoMem,x		;update
	dex
	dex
	bne adjloop		;no need to update lowmem
	jsr IOUserBlock		;load or save the program body plus DIMs (:LSBLK in Atari Basic)
	jsr ExecuteClr		;reset the DIM state
	lda #0
	sta LoadFlag		;reset the load flag: program is now ready
	rts			;otherwise, return to run.
ovflow:
	jsr CloseIOCB
	Error ProgramTooLarge	;no memory (why is there a separate error for that?)
loaderror:			;not a save file
	jsr CloseIOCB
	Error InvalidSaveFormat
.endproc
;;; *** ExecuteCSave (XCSAVE in Atari Basic)
;;; *** Execute the CSAVE instruction to save a file to tape
;;; *** FIXME: This is probably something that should go.
	.global ExecuteCSave
.proc	ExecuteCSave
	lda #8
	jsr OpenTape
	bpl SaveToIOCB		;jumps always
.endproc
;;; *** ExecuteSave (XSAVE in Atari Basic)
;;; *** Execute the SAVE statement to save a file to disk
	.global ExecuteSave
.proc	ExecuteSave
	lda #8
	jsr OpenAltChannel	;Open the target file for saving.
	;; CSAVE would run into here
	;; runs into the following
.endproc
;;; *** SaveToIOCB (XSAVE1 in Atari Basic)
;;; *** Save a file to the IOCB #7
.proc	SaveToIOCB
	lda #CmdPutBlock
	sta IOCommand
	jsr LoadOutbuffVector	;use this as temporary storage
	;; now compute the offsets for the data to save
	ldx #ArrayTablePtr-LoMem
cmploop:
	sec
	lda LoMem,x
	sbc LoMem
	sta outbuff,x
	lda LoMem+1,x
	sbc LoMem+1
	sta outbuff+1,x
	dex
	dex
	bpl cmploop
	jsr LoadIOCBOffset
	ldy #RunStack-LoMem	;the zero-page offsets that are part of the basic header
	jsr CallCIOOnShortBuffer ;load the z-page offsets
	jsr TestForIOError
	;; runs into the following: Save the rest
.endproc
;;; *** IOUserBlock (:LSBLK in atari basic)
;;; *** Load or save the user program area: Tokenized program plus variables
.proc	IOUserBlock
	lda BreakFlag		;in case it was aborted in the middle
	beq closedone		;close down now and do not attempt to write/read the second buffer.
	;; the error handler would have closed the channel under us....
	jsr LoadIOCBOffset	;IOCB offset to X
	lda VarNamePtr		;data to load starts here (below is temporary buffer)
	ldy VarNamePtr+1	;hi
	jsr Loadinbuff
	ldy outbuff+ArrayTablePtr-LoMem+1 ;number of bytes to load: This is the offset of the last address
	dey			;256 bytes are reserved for the tokenizer buffer. Not needed
	tya
	ldy outbuff+ArrayTablePtr-LoMem
	jsr CallCIOOnSizedBuffer ;load the buffer
	jsr TestForIOError
closedone:	
	jmp CloseIOCB		;done, close the buffer
.endproc
;;; *** ExecuteDir (Not present in Atari Basic)
;;; *** Execute the DIR statement
	.global ExecuteDir
.proc	ExecuteDir
	lda #<DirName
	ldy #>DirName		;get the default file name
	jsr Loadinbuff
	jsr TestStatementEnd
	bcs noargument
	jsr GetFileSpec		;get the argument
noargument:
	lda #6			;AUX1
	jsr OpenIOCB7Aux2Z
	jsr TestForIOError	;worked?
	jsr LoadOutbuffVector	;load inbuf with the input buffer
dirloop:
	lda #CmdGetRecord
	ldx #7
	jsr LoadIOCBCmdAndOffset
	jsr CallCIOOnInputBuffer ;read a line into the input buffer
	cpy #EndOfFile		 ;on EOF, just terminate
	beq done
	jsr TestForIOError
	lda BreakFlag
	beq done
	ldy #0
	sty cix
prloop:
	ldy cix
	lda (inbuff),y
	pha
	jsr PrintChar
	inc cix
	pla
	cmp #$9b		;loop until EOF
	bne prloop
	beq dirloop		;then continue
done:
	jmp CloseIOCB		;done with it.
.endproc
	

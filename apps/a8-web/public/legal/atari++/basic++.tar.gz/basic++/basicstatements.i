;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: basicstatements.i,v 1.16 2017/02/05 15:58:27 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   Implementation of Basic Statements             **
;;; **********************************************************************

InputMode		=       $a6     ;keeps the token for READ or INPUT (also for PRINT), also used by DirectModeFlag
ListEndLineNumber	=	$ab	;end of the list range
OnValue			=	$b2	;copy of the value for ON x GOTO (ONLOOP, but there in $b3 in Atari Basic)
StepSign		=	$c6	;direction of STEP
ForVariableIdx		=	$c7	;variable number for the loop index in FOR...NEXT
Color			=	$c8	;color for plotting and line drawing
PrintColonWidth		=	$c9	;number of blanks if a "," is used in PRINT, 10 by default (PTABW in Atari Basic)
ChannelOffset		=	$b3	;offset to the sound channel (also SavedCix)

	.global ExecuteNew
	.global ExecuteRem
	.global ExecuteData
	.global ExecuteInput
	.global ExecuteRead
	.global ExecutePrint
	.global ExecuteLPrint
	.global ExecuteEnter
	.global ExecuteList
	.global ExecuteOn
	.global ExecuteIf
	.global ExecuteGosub
	.global ExecuteGoto
	.global GotoLineYA
	.global RunAutorun
	.global ExecuteFor
	.global ExecuteNext
	.global ExecuteTrap
	.global ExecuteBye
	.global ExecuteDos
	.global ExecuteStop
	.global ExecuteEnd
	.global ExecuteError
	.global ExecuteCont
	.global ExecuteCom
	.global ExecuteDim
	.global ExecuteRun
	.global ExecuteClr
	.global ExecutePoke
	.global ExecuteDeg
	.global ExecuteRad
	.global ExecuteRestore
	.global ExecuteColor
	.global ExecuteSetcolor
	.global ExecuteSound
	.global ExecuteGraphics
	.global ExecuteXIO
	.global ExecuteOpen
	.global ExecuteClose
	.global ExecuteStatus
	.global ExecuteNote
	.global ExecutePoint
	.global ExecutePut
	.global ExecuteGet
	.global ExecutePosition
	.global ExecutePlot
	.global ExecuteDrawto
	.global ExecuteLocate
	.global ExecuteCLoad
	.global ExecuteLoad
	.global ExecuteCSave
	.global ExecuteSave
	.global ExecuteDir
	.global ListLine
	.global ListDirectLine

;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: constants.asm,v 1.21 2017/04/09 08:51:31 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Constant strings and symbols                   **
;;; **********************************************************************

	.include "basicmacros.i"
	
	.segment "BasMain"

	.global Const65535
Const65535:	.byte $42,$06,$55,$36,$00,$00 ;65536.0
	.global RadToDeg
RadToDeg:	.byte $40,$57,$29,$57,$79,$51 ;180/Pi
	;; the following are the coefficients for the approximation of SIN, still to be improved
	.global SinPolynomial
SinPolynomial:
		.byte $bd,$03,$55,$14,$99,$39 ; -.0000035419939
		.byte $3e,$01,$60,$44,$27,$52 ; 0.000160442752
		.byte $be,$46,$81,$75,$43,$55 ; -.004681754355
		.byte $3f,$07,$96,$92,$62,$39 ; 0.0796926239
		.byte $bf,$64,$59,$64,$08,$67 ; -.6459640867
	.global PiHalf
PiHalf:	
		.byte $40,$01,$57,$07,$96,$32 ; Pi/2 (Part of the polynomial)
	.global Ninty
Ninty:		.byte $40,$90,$00,$00,$00,$00

	;; Various strings
	.global ReadyMsg
ReadyMsg:	.byte "READY",$9b
	.global StoppedMsg
StoppedMsg:	bstring "STOPPED "
	.global AtLineMsg
AtLineMsg:	bstring "AT LINE "
	.global ScreenName
ScreenName:	.byte "S:",$9b
	.global PrinterName
PrinterName:	.byte "P:",$9b
	.global TapeName
TapeName:	.byte "C:",$9b
	.global DirName
DirName:	.byte "D:*.*",$9b
	.global AutorunName
AutorunName:	.byte "D:AUTORUN.BAS",$9b
	.global TitleMsg
TitleMsg:	.byte "Basic++ 1.08 by SMI 1979, THOR 2017",$9b
	

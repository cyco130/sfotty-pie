;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: constants.i,v 1.6 2015/09/21 19:44:33 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Constant strings and symbols                   **
;;; **********************************************************************

	.global Const65535
	.global RadToDeg
	.global TwoOverPi
	.global OneOver90
	.global SinPolynomial
	.global ReadyMsg
	.global StoppedMsg
	.global AtLineMsg
	.global ScreenName
	.global PrinterName
	.global TapeName
	.global DirName
	.global AutorunName
	.global TitleMsg
	.global PiHalf
	.global Ninty
	.global One


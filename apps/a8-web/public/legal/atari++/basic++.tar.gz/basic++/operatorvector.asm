;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: operatorvector.asm,v 1.6 2015/11/28 19:36:03 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   The vector defining all operators		**
;;; **********************************************************************

	.include "basicmacros.i"
	.include "basicoperators.i"
	.include "basicexpression.i"
	.include "syntax.i"
	
	.segment "BasMain"

.macro	addVectorLo token, location
	.byte <(location-1)
	.if token<>OperatorCounter
	.error "Operator token definition mismatch"
	.endif
OperatorCounter		.set OperatorCounter+1 
.endmacro
.macro	addVectorHi token, location
	.byte >(location-1)
	.if token<>OperatorCounter
	.error "Operator token definition mismatch"
	.endif
OperatorCounter		.set OperatorCounter+1 
.endmacro

;;; The operator table. This stores the execution vector for each operator.
;;; It starts with the first "real" operator, the numeric "less or equal"
OperatorCounter		.set	$1d
	.global OperatorVectorLo
OperatorVectorLo:		;(OPETAB in Atari Basic)
	addVectorLo LessOrEqualToken,EvaluateLessOrEqual
	addVectorLo NotEqualToken,EvaluateNotEqual
	addVectorLo GreaterOrEqualToken,EvaluateGreaterOrEqual
	addVectorLo LessThanToken,EvaluateLessThan
	addVectorLo GreaterThanToken,EvaluateGreaterThan
	addVectorLo EqualsToken,EvaluateEquals
	addVectorLo PowerToken,EvaluatePower
	addVectorLo MultiplyToken,EvaluateMultiply
	addVectorLo PlusToken,EvaluatePlus
	addVectorLo MinusToken,EvaluateMinus
	addVectorLo DivideToken,EvaluateDivide
	addVectorLo NotToken,EvaluateNot
	addVectorLo OrToken,EvaluateOr
	addVectorLo AndToken,EvaluateAnd
	addVectorLo BracketOpenToken,EvaluateBracketOpen
	addVectorLo BracketCloseToken,EvaluateBracketClose
	addVectorLo NumericAssignmentToken,EvaluateNumericAssignment
	addVectorLo StringAssignmentToken,EvaluateStringAssignment
	addVectorLo StringLessOrEqualToken,EvaluateLessOrEqual 		;yes, these are all string
	addVectorLo StringNotEqualToken,EvaluateNotEqual    		;comparisons, yet they use
	addVectorLo StringGreaterOrEqualToken,EvaluateGreaterOrEqual 	;all the same entry points
	addVectorLo StringLessThanToken,EvaluateLessThan		;as their numeric
	addVectorLo StringGreaterThanToken,EvaluateGreaterThan		;counter-
	addVectorLo StringEqualsToken,EvaluateEquals		;parts
	addVectorLo UnaryPlusToken,EvaluateUnaryPlus
	addVectorLo UnaryMinusToken,EvaluateUnaryMinus		
	addVectorLo StringBracketOpenToken,EvaluateStringBracketOpen 	;substring operation
	addVectorLo NumericArrayBracketOpenToken,EvaluateNumericArrayBracketOpen
	addVectorLo DimNumericBracketOpenToken,EvaluateDimNumericBracketOpen
	addVectorLo FunctionBracketOpenToken,EvaluateFunctionBracket
	addVectorLo DimStringBracketOpen,EvaluateDimStringBracket
	addVectorLo ArrayDimensionCommaToken,EvaluateArrayDimensionComma
	addVectorLo STRToken,EvaluateSTR
	addVectorLo CHRToken,EvaluateCHR
	addVectorLo USRToken,EvaluateUSR
	addVectorLo ASCToken,EvaluateASC
	addVectorLo VALToken,EvaluateVAL
	addVectorLo LENToken,EvaluateLEN
	addVectorLo ADRToken,EvaluateADR
	addVectorLo ATNToken,EvaluateATN
	addVectorLo COSToken,EvaluateCOS
	addVectorLo PEEKToken,EvaluatePeek
	addVectorLo SINToken,EvaluateSIN
	addVectorLo RNDToken,EvaluateRND
	addVectorLo FREToken,EvaluateFRE
	addVectorLo EXPToken,EvaluateEXP
	addVectorLo LOGToken,EvaluateLOG
	addVectorLo CLOGToken,EvaluateCLOG
	addVectorLo SQRToken,EvaluateSQR
	addVectorLo SGNToken,EvaluateSGN
	addVectorLo ABSToken,EvaluateABS
	addVectorLo INTToken,EvaluateINT
	addVectorLo PADDLEToken,EvaluatePADDLE
	addVectorLo STICKToken,EvaluateSTICK
	addVectorLo PTRIGToken,EvaluatePTRIG
	addVectorLo STRIGToken,EvaluateSTRIG
	
OperatorCounter		.set	$1d
	.global OperatorVectorHi
OperatorVectorHi:		;(OPETAB in Atari Basic)
	addVectorHi LessOrEqualToken,EvaluateLessOrEqual
	addVectorHi NotEqualToken,EvaluateNotEqual
	addVectorHi GreaterOrEqualToken,EvaluateGreaterOrEqual
	addVectorHi LessThanToken,EvaluateLessThan
	addVectorHi GreaterThanToken,EvaluateGreaterThan
	addVectorHi EqualsToken,EvaluateEquals
	addVectorHi PowerToken,EvaluatePower
	addVectorHi MultiplyToken,EvaluateMultiply
	addVectorHi PlusToken,EvaluatePlus
	addVectorHi MinusToken,EvaluateMinus
	addVectorHi DivideToken,EvaluateDivide
	addVectorHi NotToken,EvaluateNot
	addVectorHi OrToken,EvaluateOr
	addVectorHi AndToken,EvaluateAnd
	addVectorHi BracketOpenToken,EvaluateBracketOpen
	addVectorHi BracketCloseToken,EvaluateBracketClose
	addVectorHi NumericAssignmentToken,EvaluateNumericAssignment
	addVectorHi StringAssignmentToken,EvaluateStringAssignment
	addVectorHi StringLessOrEqualToken,EvaluateLessOrEqual 		;yes, these are all string
	addVectorHi StringNotEqualToken,EvaluateNotEqual    		;comparisons, yet they use
	addVectorHi StringGreaterOrEqualToken,EvaluateGreaterOrEqual 	;all the same entry points
	addVectorHi StringLessThanToken,EvaluateLessThan		;as their numeric
	addVectorHi StringGreaterThanToken,EvaluateGreaterThan		;counter-
	addVectorHi StringEqualsToken,EvaluateEquals		;parts
	addVectorHi UnaryPlusToken,EvaluateUnaryPlus
	addVectorHi UnaryMinusToken,EvaluateUnaryMinus		
	addVectorHi StringBracketOpenToken,EvaluateStringBracketOpen 	;substring operation
	addVectorHi NumericArrayBracketOpenToken,EvaluateNumericArrayBracketOpen
	addVectorHi DimNumericBracketOpenToken,EvaluateDimNumericBracketOpen
	addVectorHi FunctionBracketOpenToken,EvaluateFunctionBracket
	addVectorHi DimStringBracketOpen,EvaluateDimStringBracket
	addVectorHi ArrayDimensionCommaToken,EvaluateArrayDimensionComma
	addVectorHi STRToken,EvaluateSTR
	addVectorHi CHRToken,EvaluateCHR
	addVectorHi USRToken,EvaluateUSR
	addVectorHi ASCToken,EvaluateASC
	addVectorHi VALToken,EvaluateVAL
	addVectorHi LENToken,EvaluateLEN
	addVectorHi ADRToken,EvaluateADR
	addVectorHi ATNToken,EvaluateATN
	addVectorHi COSToken,EvaluateCOS
	addVectorHi PEEKToken,EvaluatePeek
	addVectorHi SINToken,EvaluateSIN
	addVectorHi RNDToken,EvaluateRND
	addVectorHi FREToken,EvaluateFRE
	addVectorHi EXPToken,EvaluateEXP
	addVectorHi LOGToken,EvaluateLOG
	addVectorHi CLOGToken,EvaluateCLOG
	addVectorHi SQRToken,EvaluateSQR
	addVectorHi SGNToken,EvaluateSGN
	addVectorHi ABSToken,EvaluateABS
	addVectorHi INTToken,EvaluateINT
	addVectorHi PADDLEToken,EvaluatePADDLE
	addVectorHi STICKToken,EvaluateSTICK
	addVectorHi PTRIGToken,EvaluatePTRIG
	addVectorHi STRIGToken,EvaluateSTRIG

;;; *** The operator priority table, defines for each operator a left and right priority

.macro	definePriority left, right
	.byte (left<<4)|right
.endmacro

	;; RevA had a bug evaluating not not X. In rev B this was "fixed" by changing the parser
	;; and disallowing the parse of not not. This is the wrong fix! The expression makes
	;; sense (not not converts to boolean). Here we fix this by assigning not and the unary + and -
	;; a lower right priority, i.e. association binds stronger to the right so that the right "not"
	;; is evaluated before the left "not".
	.global OperatorPriorityTable ;OPRTAB in Atari Basic
OperatorPriorityTable:	
	definePriority	0,0		;double quote
	definePriority	0,0		;end of expression
	definePriority	0,0		;comma
	definePriority	0,0		;$
	definePriority	0,0		;colon
	definePriority	0,0		;semicolon
	definePriority	0,0		;end of line
	definePriority	0,0		;on x goto
	definePriority	0,0		;on x gosub
	definePriority	0,0		;for x TO
	definePriority	0,0		;STEP
	definePriority	0,0		;THEN
	definePriority	0,0		;IOCB
	;; numeric comparisons have the lowest priority
	definePriority	7,7		;<=
	definePriority 	7,7		;<>
	definePriority	7,7		;>=
	definePriority	7,7		;>	(huh, why is the priority different?)
	definePriority	7,7		;<
	definePriority	7,7		;=
	definePriority	10,10		;^
	definePriority	9,9		;*
	definePriority	8,8		;+
	definePriority	8,8		;-
	definePriority	9,9		;/
	definePriority	13,12		;NOT	;rev.a had a lower priority here, rev b and c bind as strongly as +-.
	definePriority	5,5		;OR
	definePriority	6,6		;AND
	definePriority	15,2		;(
	definePriority	4,14		;)
	definePriority	15,1		;numeric assignment
	definePriority	15,1		;string assignment
	definePriority	14,14		;<= on strings
	definePriority	14,14		;<> on strings
	definePriority	14,14		;>= on strings
	definePriority	14,14		;< on strings
	definePriority	14,14		;> on strings
	definePriority	14,14		;= on strings
	definePriority	13,12		;+ (unary)
	definePriority	13,12		;- (unary)
	definePriority	15,2		;( for substrings
	definePriority	15,2		;( for arrays
	definePriority	15,2		;( for dimensioning arrays
	definePriority	15,2		;( on function calls
	definePriority	15,2		;( on string dimension
	definePriority	4,3		;, in array dimensions and to separate function call arguments
	;; functions follow. They all bind weakly to the left (i.e. first evaluate the contents, then themselves
	definePriority	15,2		;STR$
	definePriority	15,2		;CHR$
	definePriority	15,2		;USR
	definePriority	15,2		;ASC
	definePriority	15,2		;VAL
	definePriority	15,2		;LEN
	definePriority	15,2		;ADR
	definePriority	15,2		;ATN
	definePriority	15,2		;COS
	definePriority	15,2		;PEEK
	definePriority	15,2		;SIN
	definePriority	15,2		;RND
	definePriority	15,2		;FRE
	definePriority	15,2		;EXP
	definePriority	15,2		;LOG
	definePriority	15,2		;CLOG
	definePriority	15,2		;SQR
	definePriority	15,2		;SGN
	definePriority	15,2		;ABS
	definePriority	15,2		;INT
	definePriority	15,2		;PADDLE
	definePriority	15,2		;STICK
	definePriority	15,2		;PTRIG
	definePriority	15,2		;STRIG
	

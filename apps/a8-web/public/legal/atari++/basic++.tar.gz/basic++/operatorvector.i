;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: operatorvector.i,v 1.3 2015/10/24 22:19:55 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   The vector defining all operators		**
;;; **********************************************************************

	.global OperatorVectorLo
	.global OperatorVectorHi
	.global OperatorPriorityTable

	

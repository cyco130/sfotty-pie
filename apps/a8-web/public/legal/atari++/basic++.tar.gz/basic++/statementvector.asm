;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: statementvector.asm,v 1.6 2015/10/24 22:19:55 thor Exp $	**
;;; **                                                                  **
;;; ** In this module:   The vector defining all statements             **
;;; **********************************************************************

	.include "basicmacros.i"
	.include "basicstatements.i"
	.include "basicexpression.i"
	.include "basicstack.i"
	.include "basicmain.i"
	.include "syntax.i"
	
	.segment "BasMain"

.macro	addVectorLo token, location
	.byte <(location-1)
	.if token<>StatementCounter
	.error "Statement token definition mismatch"
	.endif
StatementCounter	.set StatementCounter+1 
.endmacro

.macro	addVectorHi token, location
	.byte >(location-1)
	.if token<>StatementCounter
	.error "Statement token definition mismatch"
	.endif
StatementCounter	.set StatementCounter+1 
.endmacro
	
	;; This vector contains for each statement the
	;; address of the subroutine that is used to execute the
	;; statement
StatementCounter	.set	$0
	.global StatementVectorLo
StatementVectorLo:
	addVectorLo REMToken,ExecuteRem
	addVectorLo DATAToken,ExecuteData
	addVectorLo INPUTToken,ExecuteInput
	addVectorLo COLORToken,ExecuteColor
	addVectorLo LISTToken,ExecuteList
	addVectorLo ENTERToken,ExecuteEnter
	addVectorLo LETToken,ExecuteLet
	addVectorLo IFToken,ExecuteIf
	addVectorLo FORToken,ExecuteFor
	addVectorLo NEXTToken,ExecuteNext
	addVectorLo GOTOToken,ExecuteGoto
	addVectorLo GO_TOToken,ExecuteGoto	;this exists twice, once for GOTO and once for GO TO
	addVectorLo GOSUBToken,ExecuteGosub
	addVectorLo TRAPToken,ExecuteTrap
	addVectorLo BYEToken,ExecuteBye
	addVectorLo CONTToken,ExecuteCont
	addVectorLo COMToken,ExecuteCom
	addVectorLo CLOSEToken,ExecuteClose
	addVectorLo CLRToken,ExecuteClr
	addVectorLo DEGToken,ExecuteDeg
	addVectorLo DIMToken,ExecuteDim
	addVectorLo ENDToken,ExecuteEnd
	addVectorLo NEWToken,ExecuteNew
	addVectorLo OPENToken,ExecuteOpen
	addVectorLo LOADToken,ExecuteLoad
	addVectorLo SAVEToken,ExecuteSave
	addVectorLo STATUSToken,ExecuteStatus
	addVectorLo NOTEToken,ExecuteNote
	addVectorLo POINTToken,ExecutePoint
	addVectorLo XIOToken,ExecuteXIO
	addVectorLo ONToken,ExecuteOn
	addVectorLo POKEToken,ExecutePoke
	addVectorLo PRINTToken,ExecutePrint
	addVectorLo RADToken,ExecuteRad
	addVectorLo READToken,ExecuteRead
	addVectorLo RESTOREToken,ExecuteRestore
	addVectorLo RETURNToken,ExecuteReturn
	addVectorLo RUNToken,ExecuteRun
	addVectorLo STOPToken,ExecuteStop
	addVectorLo POPToken,ExecutePop
	addVectorLo QuestionmarkToken,ExecutePrint	;this also exists twice, once for PRINT and once for ?
	addVectorLo GETToken,ExecuteGet
	addVectorLo PUTToken,ExecutePut
	addVectorLo GRAPHICSToken,ExecuteGraphics
	addVectorLo PLOTToken,ExecutePlot
	addVectorLo POSITIONToken,ExecutePosition
	addVectorLo DOSToken,ExecuteDos
	addVectorLo DRAWTOToken,ExecuteDrawto
	addVectorLo SETCOLORToken,ExecuteSetcolor
	addVectorLo LOCATEToken,ExecuteLocate
	addVectorLo SOUNDToken,ExecuteSound
	addVectorLo LPRINTToken,ExecuteLPrint
	addVectorLo CSAVEToken,ExecuteCSave
	addVectorLo CLOADToken,ExecuteCLoad
	addVectorLo ImplicitLetToken,ExecuteLet
	addVectorLo ErrorToken,ExecuteError
	addVectorLo ErrorToken+1,ExecuteDir

StatementCounter	.set	$0
	.global StatementVectorHi
StatementVectorHi:
	addVectorHi REMToken,ExecuteRem
	addVectorHi DATAToken,ExecuteData
	addVectorHi INPUTToken,ExecuteInput
	addVectorHi COLORToken,ExecuteColor
	addVectorHi LISTToken,ExecuteList
	addVectorHi ENTERToken,ExecuteEnter
	addVectorHi LETToken,ExecuteLet
	addVectorHi IFToken,ExecuteIf
	addVectorHi FORToken,ExecuteFor
	addVectorHi NEXTToken,ExecuteNext
	addVectorHi GOTOToken,ExecuteGoto
	addVectorHi GO_TOToken,ExecuteGoto	;this exists twice, once for GOTO and once for GO TO
	addVectorHi GOSUBToken,ExecuteGosub
	addVectorHi TRAPToken,ExecuteTrap
	addVectorHi BYEToken,ExecuteBye
	addVectorHi CONTToken,ExecuteCont
	addVectorHi COMToken,ExecuteCom
	addVectorHi CLOSEToken,ExecuteClose
	addVectorHi CLRToken,ExecuteClr
	addVectorHi DEGToken,ExecuteDeg
	addVectorHi DIMToken,ExecuteDim
	addVectorHi ENDToken,ExecuteEnd
	addVectorHi NEWToken,ExecuteNew
	addVectorHi OPENToken,ExecuteOpen
	addVectorHi LOADToken,ExecuteLoad
	addVectorHi SAVEToken,ExecuteSave
	addVectorHi STATUSToken,ExecuteStatus
	addVectorHi NOTEToken,ExecuteNote
	addVectorHi POINTToken,ExecutePoint
	addVectorHi XIOToken,ExecuteXIO
	addVectorHi ONToken,ExecuteOn
	addVectorHi POKEToken,ExecutePoke
	addVectorHi PRINTToken,ExecutePrint
	addVectorHi RADToken,ExecuteRad
	addVectorHi READToken,ExecuteRead
	addVectorHi RESTOREToken,ExecuteRestore
	addVectorHi RETURNToken,ExecuteReturn
	addVectorHi RUNToken,ExecuteRun
	addVectorHi STOPToken,ExecuteStop
	addVectorHi POPToken,ExecutePop
	addVectorHi QuestionmarkToken,ExecutePrint	;this also exists twice, once for PRINT and once for ?
	addVectorHi GETToken,ExecuteGet
	addVectorHi PUTToken,ExecutePut
	addVectorHi GRAPHICSToken,ExecuteGraphics
	addVectorHi PLOTToken,ExecutePlot
	addVectorHi POSITIONToken,ExecutePosition
	addVectorHi DOSToken,ExecuteDos
	addVectorHi DRAWTOToken,ExecuteDrawto
	addVectorHi SETCOLORToken,ExecuteSetcolor
	addVectorHi LOCATEToken,ExecuteLocate
	addVectorHi SOUNDToken,ExecuteSound
	addVectorHi LPRINTToken,ExecuteLPrint
	addVectorHi CSAVEToken,ExecuteCSave
	addVectorHi CLOADToken,ExecuteCLoad
	addVectorHi ImplicitLetToken,ExecuteLet
	addVectorHi ErrorToken,ExecuteError
	addVectorHi ErrorToken+1,ExecuteDir

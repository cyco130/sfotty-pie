;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: syntax.asm,v 1.15 2015/11/08 15:24:57 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Definition of the syntax in ABML		**
;;; **********************************************************************

	.include "basicmacros.i"
	.include "syntax.i"
	.include "basicparser.i"

	.segment "BasMain"
	
;;; ************************************** Statement Table starts here *********************************************
;;; *** The statement table contains for each statement a pointer to the AMBL syntax of the statement
;;; *** and the name of the statement
StatementCounter	.set	$0

.macro	statement token, syntax, name
	.word	syntax-1
	.if (.match (.left (1, {name}), $0))
	.byte name,$80		
	.else
	bstring	name
	.endif
	.if token<>StatementCounter
	.error "Statement token definition mismatch"
	.endif
StatementCounter	.set StatementCounter+1 
.endmacro

	.global StatementTable
StatementTable:	
	statement REMToken,remsyntax,"REM"
	statement DATAToken,datasyntax,"DATA"
	statement INPUTToken,inputsyntax,"INPUT"
	statement COLORToken,colorsyntax,"COLOR"
	statement LISTToken,listsyntax,"LIST"
	statement ENTERToken,entersyntax,"ENTER"
	statement LETToken,letsyntax,"LET"
	statement IFToken,ifsyntax,"IF"
	statement FORToken,forsyntax,"FOR"
	statement NEXTToken,nextsyntax,"NEXT"
	statement GOTOToken,gotosyntax,"GOTO"
	statement GO_TOToken,gotosyntax,"GO TO"
	statement GOSUBToken,gosubsyntax,"GOSUB"
	statement TRAPToken,trapsyntax,"TRAP"
	statement BYEToken,byesyntax,"BYE"
	statement CONTToken,contsyntax,"CONT"
	statement COMToken,comsyntax,"COM"
	statement CLOSEToken,closesyntax,"CLOSE"
	statement CLRToken,clrsyntax,"CLR"
	statement DEGToken,degsyntax,"DEG"
	statement DIMToken,dimsyntax,"DIM"
	statement ENDToken,endsyntax,"END"
	statement NEWToken,newsyntax,"NEW"
	statement OPENToken,opensyntax,"OPEN"
	statement LOADToken,loadsyntax,"LOAD"
	statement SAVEToken,savesyntax,"SAVE"
	statement STATUSToken,statussyntax,"STATUS"
	statement NOTEToken,notesyntax,"NOTE"
	statement POINTToken,pointsyntax,"POINT"
	statement XIOToken,xiosyntax,"XIO"
	statement ONToken,onsyntax,"ON"
	statement POKEToken,pokesyntax,"POKE"
	statement PRINTToken,printsyntax,"PRINT"
	statement RADToken,radsyntax,"RAD"
	statement READToken,readsyntax,"READ"
	statement RESTOREToken,restoresyntax,"RESTORE"
	statement RETURNToken,returnsyntax,"RETURN"
	statement RUNToken,runsyntax,"RUN"
	statement STOPToken,stopsyntax,"STOP"
	statement POPToken,popsyntax,"POP"
	statement QuestionmarkToken,printsyntax,"?"
	statement GETToken,getsyntax,"GET"
	statement PUTToken,putsyntax,"PUT"
	statement GRAPHICSToken,graphicssyntax,"GRAPHICS"
	statement PLOTToken,plotsyntax,"PLOT"
	statement POSITIONToken,positionsyntax,"POSITION"
	statement DOSToken,dossyntax,"DOS"
	statement DRAWTOToken,drawtosyntax,"DRAWTO"
	statement SETCOLORToken,setcolorsyntax,"SETCOLOR"
	statement LOCATEToken,locatesyntax,"LOCATE"
	statement SOUNDToken,soundsyntax,"SOUND"
	statement LPRINTToken,lprintsyntax,"LPRINT"
	statement CSAVEToken,csavesyntax,"CSAVE"
	statement CLOADToken,cloadsyntax,"CLOAD"
	statement CLOADToken+1,dirsyntax,"DIR" 			;this is fiddled in here, but has a different token number
	statement ImplicitLetToken+1,silentletsyntax,$00 	;marks the end of the table
	statement ErrorToken+1,1,"ERROR-  "

;;; ********************************* Operator definitions start here ***********************************************

OperatorCounter	.set	$12
	
.macro	addoperator name, value
	.if (.match (.left (1, {value}), $0))
	.byte value		
	.else
	bstring value
	.endif
	.if name<>OperatorCounter
	.error "OperatorToken definition mismatch"
	.endif
OperatorCounter	.set OperatorCounter+1 
.endmacro

	;; Atari basic had here two additional dummy
	;; entries:
	;; The double-quote token, which was actually
	;; never printed nor parsed, with the code $10
	;; and the match pattern $82,
	;; and the EndOfExpression token, which was also
	;; never matched and parsed, and is only used
	;; internally in the expression evaluation as
	;; "end of stack" indicator.
	;; The two can only confuse the parser as a clever
	;; user could insert CTRL-, (ZERO) or CTRL-B ($02)
	;; into the source code and have that parsed.
	.global OperatorTable
OperatorTable:
	addoperator CommaToken,","
	addoperator DollarToken,"$"
	addoperator ColonToken,":"
	addoperator SemicolonToken,";"
	addoperator EndOfLineToken,$9b
	addoperator GotoOperatorToken,"GOTO"
	addoperator GosubOperatorToken,"GOSUB"
	addoperator ToToken,"TO"
	addoperator StepToken,"STEP"
	addoperator ThenToken,"THEN"
	addoperator IOCBToken,"#"
	addoperator LessOrEqualToken,"<="
	addoperator NotEqualToken,"<>"
	addoperator GreaterOrEqualToken,">="
	addoperator LessThanToken,"<"
	addoperator GreaterThanToken,">"
	addoperator EqualsToken,"="
	addoperator PowerToken,"^"
	addoperator MultiplyToken,"*"
	addoperator PlusToken,"+"
	addoperator MinusToken,"-"
	addoperator DivideToken,"/"
	addoperator NotToken,"NOT"
	addoperator OrToken,"OR"
	addoperator AndToken,"AND"
	addoperator BracketOpenToken,"("
	addoperator BracketCloseToken,")"
	addoperator NumericAssignmentToken,"="
	addoperator StringAssignmentToken,"="
	addoperator StringLessOrEqualToken,"<="
	addoperator StringNotEqualToken,"<>"
	addoperator StringGreaterOrEqualToken,">="
	addoperator StringLessThanToken,"<"
	addoperator StringGreaterThanToken,">"
	addoperator StringEqualsToken,"="
	addoperator UnaryPlusToken,"+"
	addoperator UnaryMinusToken,"-"
	addoperator StringBracketOpenToken,"("
	addoperator NumericArrayBracketOpenToken,"("
	addoperator DimNumericBracketOpenToken,"("
	addoperator FunctionBracketOpenToken,"("
	addoperator DimStringBracketOpen,"("
	addoperator ArrayDimensionCommaToken,","
	addoperator STRToken,"STR$"
	addoperator CHRToken,"CHR$"
	addoperator USRToken,"USR"
	addoperator ASCToken,"ASC"
	addoperator VALToken,"VAL"
	addoperator LENToken,"LEN"
	addoperator ADRToken,"ADR"
	addoperator ATNToken,"ATN"
	addoperator COSToken,"COS"
	addoperator PEEKToken,"PEEK"
	addoperator SINToken,"SIN"
	addoperator RNDToken,"RND"
	addoperator FREToken,"FRE"
	addoperator EXPToken,"EXP"
	addoperator LOGToken,"LOG"
	addoperator CLOGToken,"CLOG"
	addoperator SQRToken,"SQR"
	addoperator SGNToken,"SGN"
	addoperator ABSToken,"ABS"
	addoperator INTToken,"INT"
	addoperator PADDLEToken,"PADDLE"
	addoperator STICKToken,"STICK"
	addoperator PTRIGToken,"PTRIG"
	addoperator STRIGToken,"STRIG"
	.byte 0

;;; ********************************* ABML syntax definitions start here ********************************************
;;; *** This table defines for every command an ABML syntax defining its parameters

	;; call a subroutine code to parse the syntax of this command
.macro	callnative address
	.byte SC_CallNative
	.dbyt address-1		;really inverted byte order, is more convenient this way.
.endmacro
	
.macro	subshort address
	.byte $80+(((address-*)&$7f)^$40)
.endmacro

.macro	sublong	address
	.byte SC_CallVector
	.word address-1
.endmacro
	
;; call relative to another parser
.macro	sub address
	.if (address-*) >= -64 .and (address-*) <= 63
	subshort address
	.else
	sublong address
	.endif
.endmacro

	
	;; terminal node
.macro	rtn
	.byte SC_End
.endmacro

	;; choice between two alterantives
.macro	alternatively
	.byte SC_Alternative
.endmacro

	;; a specific operator whose token is given
.macro	operator token
	.byte token
.endmacro

	;; change a token to another token given by the argument
	;; if parsing succeeds
.macro	changeto token
	.byte SC_ChangeLastToken
	.byte token
.endmacro

;;; *** A generic expression (Atari Basic: EXP)
	.global ExpressionSyntax
ExpressionSyntax:	
expression:	
	operator BracketOpenToken
	sub expression
	operator BracketCloseToken
	subshort nothingoroperator
	alternatively
	subshort numericvalue
	subshort nothingoroperator
	alternatively
	subshort unaryoperator
	sub expression
	rtn

;;; *** A unary +,- or NOT (Atari Basic: UNARY)
unaryoperator:
	operator PlusToken
	changeto UnaryPlusToken
	alternatively
	operator MinusToken
	changeto UnaryMinusToken
	alternatively
	operator NotToken
	rtn

;;; *** Functions, variables, numeric constants or string comparisons (Atari Basic NV)
numericvalue:	
	subshort numericfunction
	alternatively
	subshort numericvariable
	alternatively
	callnative ParseNumber	;atari Basic TNCON
	alternatively
	sublong stringcomparison
	rtn
	
;;; *** An operator with another expression or nothing	(Atari Basic NOP)
nothingoroperator:
	subshort binaryoperator
	sub expression
	alternatively
	rtn

;;; *** An operator (Atari Basic OP)
binaryoperator:
	operator PowerToken
	alternatively
	operator PlusToken
	alternatively
	operator MinusToken
	alternatively
	operator MultiplyToken
	alternatively
	operator DivideToken
	alternatively
	operator LessOrEqualToken
	alternatively
	operator GreaterOrEqualToken
	alternatively
	operator NotEqualToken
	alternatively
	operator LessThanToken
	alternatively
	operator GreaterThanToken
	alternatively
	operator EqualsToken
	alternatively
	operator AndToken
	alternatively
	operator OrToken
	rtn

;;; *** A numeric variable (NVAR in Atari Basic)
numericvariable:
	callnative ParseNumericVariableName ;TNVAR in AtariBasic
	subshort numericarrayornothing
	rtn

;;; *** a numeric array, or rather the part around the brackets	(NMAT in Atari basic)
numericarrayornothing:
	operator BracketOpenToken
	changeto NumericArrayBracketOpenToken
	operator ExpressionToken
	subshort numericindexdim2ornothing
	operator BracketCloseToken
	alternatively
	rtn

;;; *** the second dimension for an array, or nothing (NMAT2 in Atari basic)
numericindexdim2ornothing:
	operator CommaToken
	changeto ArrayDimensionCommaToken
	operator ExpressionToken
	alternatively
	rtn

;;; **** functions returning numbers	(NFUN in Atari Basic)
numericfunction:
	operator GenericFunctionToken
	subshort numericargument	;NFP
	alternatively
	sublong numericfunctionsonstrings	;NFSP in Atari Basic
	subshort stringargument		;SFP
	alternatively
	subshort usrfunction		;NUSR in Atari basic
	rtn

;;; *** the USR function (with multiple arguments), (NFUSR in Atari Basic)
usrfunction:
	operator USRToken
	operator BracketOpenToken
	changeto FunctionBracketOpenToken
	sublong usrarguments		;PUSR in AtariBasic
	operator BracketCloseToken
	rtn

;;; *** parse a numeric argument of a function (NFP in Atari Basic)
numericargument:
	operator BracketOpenToken
	changeto FunctionBracketOpenToken
	operator ExpressionToken
	operator BracketCloseToken
	rtn

;;; *** Parse a string argument of a function taking a string (SFP in Atari basic)
stringargument:
	operator BracketOpenToken
	changeto FunctionBracketOpenToken
	subshort stringexpression
	operator BracketCloseToken
	rtn

;;; *** Comparisons of two strings (STCOMP in Atari basic)
stringcomparison:
	subshort stringexpression
	subshort stringoperator
	subshort stringexpression
	rtn
	
;;; *** Parse of a string value, given as either a function returning a string or a string variable (STR in Atari Basic)
stringexpression:
	subshort stringfunctioncall	;SFUN
	alternatively
	subshort stringvariable	;SVAR
	alternatively
	callnative ParseString	;parse a constant string (TSCON in Atari Basic)
	rtn

;;; *** Functions returning strings (SFUN in Atari Basic)
stringfunctioncall:
	sublong stringfunctions	;SFNP
	sub numericargument	;taking a number
	rtn

;;; *** String variables, or parts of string variables (SVAR in Atari Basic)
stringvariable:
	callnative ParseStringVariableName ;TSVAR in AtariBasic
	subshort substringornothing
	rtn

;;; *** A one or two-index argument of a string, forming a substring
substringornothing:		;SMAT in Atari Basic
	operator BracketOpenToken
	changeto StringBracketOpenToken
	operator ExpressionToken
	subshort stringindexdim2ornothing
	operator BracketCloseToken
	alternatively
	rtn

;;; *** The second dimension (end index) of a string, forming a substring
stringindexdim2ornothing:
	operator CommaToken
	changeto ArrayDimensionCommaToken
	operator ExpressionToken
	alternatively
	rtn

;;; *** A string operator between two strings (SOP in Atari Basic)
stringoperator:
	operator LessOrEqualToken
	changeto StringLessOrEqualToken
	alternatively
	operator GreaterOrEqualToken
	changeto StringGreaterOrEqualToken
	alternatively
	operator NotEqualToken
	changeto StringNotEqualToken
	alternatively
	operator LessThanToken
	changeto StringLessThanToken
	alternatively
	operator GreaterThanToken
	changeto StringGreaterThanToken
	alternatively
	operator EqualsToken
	changeto StringEqualsToken
	rtn

;;; *** The syntax scanner for PUT
putsyntax:
	operator IOCBToken
	operator ExpressionToken
	;; sub iocbexpression
	operator CommaToken
	;; runs into the following
;;; *** Syntax for a lot of statements only taking a single argument
trapsyntax:
gotosyntax:
gosubsyntax:
graphicssyntax:
colorsyntax:
	operator ExpressionToken
	;; runs into the following
;;; *** Syntax for a lot of statements taking no argument at all
csavesyntax:
cloadsyntax:
dossyntax:
clrsyntax:
returnsyntax:
stopsyntax:
popsyntax:
newsyntax:
endsyntax:	
byesyntax:
contsyntax:
degsyntax:
radsyntax:
	subshort endofstatement	;a statement end (EOS in Atari Basic)
	rtn
;;; *** Syntax of the let command and the silent let command
letsyntax:
silentletsyntax:
	sub numericvariable
	operator EqualsToken
	changeto NumericAssignmentToken
	operator ExpressionToken
	subshort endofstatement
	alternatively
	sub stringvariable
	operator EqualsToken
	changeto StringAssignmentToken
	sub stringexpression
	subshort endofstatement
	rtn

;;; *** Syntax of the FOR...TO statement
forsyntax:
	callnative ParseNumericVariableName ;TNVAR in AtariBasic, also TNAR
	operator EqualsToken
	changeto NumericAssignmentToken
	operator ExpressionToken
	operator ToToken
	operator ExpressionToken
	subshort stepornothing
	subshort endofstatement
	rtn

;;; *** Syntax of STEP, which is optional
stepornothing:
	operator StepToken
	operator ExpressionToken
	alternatively
	rtn

;;; *** Syntax of LOCATE
locatesyntax:
	operator ExpressionToken
	operator CommaToken
	operator ExpressionToken
	operator CommaToken
	sub numericvariable
	subshort endofstatement
	rtn

;;; *** Syntax of NEXT
nextsyntax:
	callnative ParseNumericVariableName
	subshort endofstatement
	rtn

;;; *** Syntax of RESTORE
restoresyntax:
	operator ExpressionToken
	subshort endofstatement
	alternatively
	subshort endofstatement
	rtn

;;; *** Syntax of INPUT
inputsyntax:
	subshort iocbornothing
	;; runs into the following
;;; *** Synax of READ
readsyntax:
	subshort variablelist
	subshort endofstatement
	rtn
	
;;; *** End of statement
endofstatement:
	operator ColonToken
	alternatively
	operator EndOfLineToken
	rtn
	
;;; *** Syntax of the print statement
printsyntax:
	subshort iocbexpression
	sub endofstatement	;an empty PRINT #IOCB
	alternatively
	subshort iocbornothing
	;; runs into the following
;;; *** Snytax of the lprint statement
lprintsyntax:
	sublong printbody
	sub endofstatement
	rtn
	
;;; *** Parse an IOCB channel (D1 in Atari basic)
iocbexpression:	
	operator IOCBToken
	operator ExpressionToken
	rtn

;;; *** a numeric or a string variable name (NSVAR in Atari Basic)
numericorstringvar:
	sub numericvariable
	alternatively
	callnative ParseStringVariableName
	rtn

;;; *** Parse a list of variables, string or numeric (NSVRL in Atari Basic)
variablelist:
	sub numericorstringvar
	subshort variablelistextension
	rtn

;;; *** Extension of the above: A comma, and then the same again
variablelistextension:
	operator CommaToken
	sub variablelist
	alternatively
	rtn

;;; *** Syntax of the XIO command
xiosyntax:
	operator ExpressionToken
	operator CommaToken
	;; runs into the following

;;; *** Syntax of the OPEN command
opensyntax:
	sub iocbexpression
	operator CommaToken
	subshort twoexpressions
	operator CommaToken
	subshort filename		;AtariBasic uses here a separate syntax element named FS, but it resolves to STR directly.
	sub endofstatement
	rtn

;;; *** Synax of the CLOSE command
closesyntax:
	sub iocbexpression
	sub endofstatement
	rtn

;;; *** Syntax of commands taking a single file name
entersyntax:
loadsyntax:
savesyntax:
	subshort filename
	sub endofstatement
	rtn

;;; *** Syntax of the RUN command. Can optionally take a filename
runsyntax:
	subshort filename
	sub endofstatement
	alternatively
	sub endofstatement
	rtn
	
;;; *** Parse an optional IOCB which is #iocb, or #iocb; (OPD in Atari Basic)
iocbornothing:
	sub iocbexpression
	operator CommaToken
	alternatively
	sub iocbexpression
	operator SemicolonToken
	alternatively
	rtn

;;; *** Parse the LIST statement
listsyntax:
	subshort filename
	sub endofstatement
	alternatively
	subshort filename
	operator CommaToken
	subshort listrangeandend
	alternatively
	subshort listrangeandend
	rtn

;;; *** A range of line numbers to be listed	(LIS in Atari Basic)
listrangeandend:	
	sublong listrange		;L1 in AtariBasic
	subshort endofstatement2
	rtn

;;; *** The synax of the Status command
statussyntax:
getsyntax:	
	subshort iocbandvariable
	subshort endofstatement2
	rtn

;;; *** An IOCB followed by a variable name (SSTAT in Atari Basic), used by status,point and note
iocbandvariable:
	sub iocbexpression
	operator CommaToken
simplenumericvariable:
	sub numericvariable
	rtn
	
;;; *** The syntax for point and note. They are strangely identical.
notesyntax:
	sub iocbandvariable
	operator CommaToken
	subshort simplenumericvariable
	subshort endofstatement2
	rtn
	
;;; *** filename (Atari basic FS or SFS) This is only a string.
filename:
	sub stringexpression
	rtn

;;; *** Two expressions separated by comma, used to simplify open
twoexpressions:
	operator ExpressionToken
	operator CommaToken
	operator ExpressionToken
	rtn

;;; *** The syntax of the SOUND command. Takes four expressions
soundsyntax:
	operator ExpressionToken
	operator CommaToken
	;; runs into the following
	
;;; *** The syntax of the SETCOLOR command. Takes three expressions
setcolorsyntax:
	operator ExpressionToken
	operator CommaToken
	;; runs into the following

;;; The syntax of plot,drawto,position and poke: Take two expressions
plotsyntax:
drawtosyntax:
positionsyntax:
pokesyntax:
	sub twoexpressions
	subshort endofstatement2
	rtn

;;; The syntax of DIM and COM, being identical
dimsyntax:
comsyntax:
	subshort arraylist			;NSML in Atari basic
	subshort endofstatement2
	rtn

;;; *** The syntax of ON x GOTO and ON x GOSUB
onsyntax:	
	operator ExpressionToken
	subshort gotoorgosub
	subshort linenumberlist
	subshort endofstatement2
	rtn

;;; *** A goto or gosub expression, (ON1 in AtariBasic)
gotoorgosub:
	operator GotoOperatorToken
	alternatively
	operator GosubOperatorToken
	rtn

;;; *** A list of line numbers, as used by ON x GOxx (EXPL in Atari Basic)
linenumberlist:
	operator ExpressionToken
	subshort linenumberornothing
	rtn

;;; *** An extension of a line number
linenumberornothing:
	operator CommaToken
	sub linenumberlist
	alternatively
	rtn

;;; *** End of statement (yet again)
endofstatement2:
	operator ColonToken
	alternatively
	operator EndOfLineToken
	rtn

;;; **** a one or two-dimensional numeric or a one-dimensional string array (NSMAT in Atari Basic)
arraydimension:	
	callnative ParseNumericVariableName
	operator BracketOpenToken
	changeto DimNumericBracketOpenToken
	operator ExpressionToken
	sub numericindexdim2ornothing
	operator BracketCloseToken
	alternatively
	callnative ParseStringVariableName
	operator BracketOpenToken
	changeto DimStringBracketOpen
	operator ExpressionToken
	operator BracketCloseToken
	rtn

;;; *** Several arrays, separated by commas (Atari Basic NSML) Atari Basic has a bug here allowing an empty list
arraylist:
	sub arraydimension
	subshort arraylistornothing
	rtn

;;; *** extension of a list of arrays (Atari Basic NSML2, broken there)
arraylistornothing:
	operator CommaToken
	sub arraylist
	alternatively
	rtn

;;; *** syntax of IF ... THEN
ifsyntax:
	operator ExpressionToken
	operator ThenToken
	subshort linenumberorstatement
	sub endofstatement2
	rtn

;;; *** What follows an IF/THEN: Either a line number, or a statement (IFA in Atari Basic)
linenumberorstatement:
	callnative ParseNumber
	alternatively
	callnative ParseIfStatement
	;; actually, an RTN could follow here, though the above Abort does not continue anyhow...

;;; *** Parse the body of a print statement (PR1 in Atari Basic)
printbody:	
	subshort printexpressionlist
	alternatively
	subshort commaorsemicolonlist
	subshort printexpressionlistornothing
	alternatively
	rtn

;;; *** A list of printable expressions, separated by arbitrarily many separators (PR2 in Atari Basic)
printexpressionlistornothing:
	subshort printexpressionlist
	alternatively
	rtn
	
;;; *** printexpressionlist (PEL in Atari basic)
printexpressionlist:
	subshort expressionorstringvalue
	subshort printexpressioncontinue
	rtn
	
;;; *** expressionorstringvalue (PES in Atari Basic)
expressionorstringvalue:
	operator ExpressionToken
	alternatively
	sub stringexpression
	rtn

;;; *** extension of a print expression with arbitrary separators in between (PELA in Atari Basic)
printexpressioncontinue:
	subshort commaorsemicolonlist
	sub printexpressionlistornothing
	alternatively
	rtn
	
;;; *** commaorsemicolonlist (PSL in Atari Basic)
commaorsemicolonlist:	
	subshort commaorsemicolon
	subshort commaorsemicolonornothing
	rtn

;;; *** A list of commas or semicolons or nothing at all (PSLA in Atari Basic)
commaorsemicolonornothing:
	sub commaorsemicolonlist
	alternatively
	rtn

;;; *** A comma or a semicolon (PS in Atari Basic)
commaorsemicolon:
	operator CommaToken
	alternatively
	operator SemicolonToken
	rtn
	
;;; **** a list of line numbers as used by list (L1 in Atari Basic)
listrange:
	operator ExpressionToken
	subshort listendrange
	alternatively
	rtn

;;; *** The second line in LIST if it is given. This should really also allow only the comma.... (L2 in Atari Basic)
listendrange:
	operator CommaToken
	operator ExpressionToken
	alternatively
	operator CommaToken	;new: a simple comma also works
	alternatively
	rtn

;;; *** The syntax of REM and DATA. Surprisingly, it is the same.
remsyntax:
datasyntax:
	callnative ParseREMDATA
	;; the above aborts parsing, so there is no need for an RTN

;;; *** Various functions on strings that return numbers
numericfunctionsonstrings:	
	operator ASCToken
	alternatively
	operator ADRToken
	alternatively
	operator VALToken
	alternatively
	operator LENToken
	rtn

;;; *** Various functions that return strings on numbers
stringfunctions:
	operator STRToken
	alternatively
	operator CHRToken
	rtn

;;; *** The var-ardig USR arguments (PUSR in Atari Basic)
usrarguments:
	operator ExpressionToken
	subshort usrargumentornothing
	rtn

;;; *** The extension of a USR expression list (PUSR1 in Atari Basic)
usrargumentornothing:
	operator CommaToken
	changeto ArrayDimensionCommaToken
	sub usrarguments
	alternatively
	rtn

	;; point takes arbitrary expressions, actually.
pointsyntax:
	sub iocbexpression
	operator CommaToken
	operator ExpressionToken ;new: an expression also works
	operator CommaToken
	operator ExpressionToken
	sub endofstatement2
	rtn

dirsyntax:
	subshort filenameornothing
	sub endofstatement2
	rtn

filenameornothing:
	sub filename
	alternatively
	rtn

	

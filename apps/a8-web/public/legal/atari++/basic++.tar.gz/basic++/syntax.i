;;; **********************************************************************
;;; ** THOR Basic++                                                     **
;;; ** A free Basic for the Atari 8 Bit series               		**
;;; ** (c) 2015 THOR Software, Thomas Richter                           **
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: syntax.i,v 1.4 2015/09/21 19:44:33 thor Exp $		**
;;; **                                                                  **
;;; ** In this module:   Definition of the syntax in ABML		**
;;; **********************************************************************

	.global StatementTable
	.global OperatorTable
	.global ExpressionSyntax

	;; Syntax table parser tokens. This is "ABML", Atari Basic Meta Language
	;; These tokens are used to drive the argument parser for statements
SC_CallVector		=	0 ;ANTV vector (absolute non-terminal GOSUB)
SC_CallNative		=	1 ;customized parsing (ERST)
SC_Alternative		=	2 ;OR (two alternative forms)
SC_End			=	3 ;RTN (end of a syntax string)
SC_Reserved1		=	4
SC_Expression		=	$0e ;An expression (VFXP, absolute non-terminal vector)
SC_ChangeLastToken	=	$0f ;update the last token presented (CHNG)
	;; tokens 10 to 7f are terminal tokens and compile directly into the atari token in the output buffer
ExpressionToken		=	$0e ;see above, the same
StringToken		=	$0f ;a string constant
DoubleQuoteToken	=	$10 ;the " around constant strings
EndOfExpression		=	$11 ;a dummy token on the argument stack used to indicate that the expression is now complete
CommaToken		=	$12 ;the ",", generic version
DollarToken		=	$13 ;the $ sign
ColonToken		=	$14 ;end of statement
SemicolonToken		=	$15 ;the semicolon for print and input
EndOfLineToken		=	$16 ;end of a line, EOL
GotoOperatorToken	=	$17 ;GOTO as in ON x GOTO
GosubOperatorToken	=	$18 ;GOSUB as in ON x GOSUB
ToToken			=	$19 ;TO as in FOR ... TO ...
StepToken		=	$1a ;STEP as in FOR ... TO ... STEP
ThenToken		=	$1b ;THEN as in IF ... THEN
IOCBToken		=	$1c ;the hashmark as in OPEN #1,...
LessOrEqualToken	=	$1d ;the numeric version of <=
NotEqualToken		=	$1e ;the numeric version of <>
GreaterOrEqualToken	=	$1f ;the numeric version of >=
LessThanToken		=	$20 ;the numeric version of <
GreaterThanToken	=	$21 ;the numeric version of >
EqualsToken		=	$22 ;the numeric version of =
PowerToken		=	$23 ;taking A to the power of B, i.e. A^B
MultiplyToken		=	$24 ;multiplication, indicated by *
PlusToken		=	$25 ;addition, indicated by +
MinusToken		=	$26 ;subtraction, indicated by -
DivideToken		=	$27 ;division, indicated by /
NotToken		=	$28 ;logical NOT
OrToken			=	$29 ;logical OR
AndToken		=	$2a ;logical AND
BracketOpenToken	=	$2b ;the generic version of (
BracketCloseToken	=	$2c ;the generic version of )
NumericAssignmentToken	=	$2d ;the numeric assignment
StringAssignmentToken	=	$2e ;the string assignment
StringLessOrEqualToken	=	$2f ;the <= on strings
StringNotEqualToken	=	$30 ;the <> on strings
StringGreaterOrEqualToken=	$31 ;the >= on strings
StringLessThanToken	=	$32 ;the < on strings
StringGreaterThanToken	=	$33 ;the > on strings
StringEqualsToken	=	$34 ;the = on strings
UnaryPlusToken		=	$35 ;the unary + sign
UnaryMinusToken		=	$36 ;the unary - sign
StringBracketOpenToken	=	$37 ;the ( on strings to form sub-strings
NumericArrayBracketOpenToken=	$38 ;the ( on arrays to index them
DimNumericBracketOpenToken=	$39 ;the ( to dimension arrays
FunctionBracketOpenToken=	$3a ;the ( on function calls around the arguments
DimStringBracketOpen	=	$3b ;the ( to dimension strings
ArrayDimensionCommaToken=	$3c ;the , to separate function arguments (for USR) or array dimensions
STRToken		=	$3d ;the STR$ function
CHRToken		=	$3e ;the CHR$ function
USRToken		=	$3f ;the USR function
ASCToken		=	$40 ;the ASC function
VALToken		=	$41 ;the VAL function
LENToken		=	$42 ;the LEN function
ADRToken		=	$43 ;the ADR function
GenericFunctionToken	=	$44 ;a generic prototype for all following numeric functions
ATNToken		=	$44 ;the arcus tangent function
COSToken		=	$45 ;the cosine
PEEKToken		=	$46 ;the mess-with-memory-though-you-should-not function
SINToken		=	$47 ;the sine
RNDToken		=	$48 ;the random function
FREToken		=	$49 ;free memory, too depressing
EXPToken		=	$4a ;exponential
LOGToken		=	$4b ;logarithm
CLOGToken		=	$4c ;logarithm to the base of 10
SQRToken		=	$4d ;square root
SGNToken		=	$4e ;sign
ABSToken		=	$4f ;absolute value
INTToken		=	$50 ;round to integer
PADDLEToken		=	$51 ;paddle position
STICKToken		=	$52 ;joystick position
PTRIGToken		=	$53 ;paddle trigger
STRIGToken		=	$54 ;joystick trigger
	
	;; tokens 80 and up are relative variants of ANTV but work otherwise identical

;;; Tokens for commands
REMToken		=	$00
DATAToken		=	$01 ;the DATA statement
INPUTToken		=	$02 ;the INPUT statement
COLORToken		=	$03
LISTToken		=	$04 ;the LIST token
ENTERToken		=	$05
LETToken		=	$06
IFToken			=	$07
FORToken		=	$08 ;the token for the FOR statement
NEXTToken		=	$09
GOTOToken		=	$0a ;GOTO as statement (not as operator)
GO_TOToken		=	$0b
GOSUBToken		=	$0c ;the GOSUB statement
TRAPToken		=	$0d
BYEToken		=	$0e
CONTToken		=	$0f
COMToken		=	$10
CLOSEToken		=	$11
CLRToken		=	$12
DEGToken		=	$13
DIMToken		=	$14
ENDToken		=	$15
NEWToken		=	$16
OPENToken		=	$17
LOADToken		=	$18
SAVEToken		=	$19
STATUSToken		=	$1a
NOTEToken		=	$1b
POINTToken		=	$1c
XIOToken		=	$1d
ONToken			=	$1e ;the ON from ON...GOSUB
POKEToken		=	$1f
PRINTToken		=	$20
RADToken		=	$21
READToken		=	$22 ;the READ token
RESTOREToken		=	$23
RETURNToken		=	$24
RUNToken		=	$25
STOPToken		=	$26
POPToken		=	$27
QuestionmarkToken	=	$28 ;for PRINT as ?
GETToken		=	$29
PUTToken		=	$2a
GRAPHICSToken		=	$2b
PLOTToken		=	$2c
POSITIONToken		=	$2d
DOSToken		=	$2e
DRAWTOToken		=	$2f
SETCOLORToken		=	$30
LOCATEToken		=	$31
SOUNDToken		=	$32
LPRINTToken		=	$33
CSAVEToken		=	$34
CLOADToken		=	$35
ImplicitLetToken	=	$36 ;the token for the LET command that is not written
ErrorToken		=	$37 ;the token for syntax errors
DirToken		=	$48 ;the TurboBasic DIR token
	

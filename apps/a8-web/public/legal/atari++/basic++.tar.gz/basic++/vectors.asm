;;; **********************************************************************
;;; ** THOR Basic++							**
;;; ** A free BASIC for the Atari 8 Bit series				**
;;; ** (c) 2008 THOR Software, Thomas Richter				**
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: vectors.asm,v 1.5 2015/11/04 11:20:29 thor Exp $		**
;;; **									**
;;; ** In this module:	 Os vectors for the BASIC ROM			**
;;; **********************************************************************

	.include "vectors.i"
	.include "basicmain.i"
	.include "basicstatements.i"
	.include "kernel.i"
	.segment "Vectors"

	.word BasicColdStart	; execution starts there
	.byte 0			; regular cart
	.byte 1+4		; run the cart instead of the DOS, bootstrap
	.word ExecuteRem

;;; **********************************************************************
;;; ** THOR Basic++							**
;;; ** A free BASIC for the Atari 8 Bit series				**
;;; ** (c) 2008 THOR Software, Thomas Richter				**
;;; ** This is based on Atari Basic, as developed by			**
;;; ** Paul Laughton and Kathleen O'Brien, Shepardson Microsystems	**
;;; ** as found in: The Atari BASIC SOURCE BOOK	by Bill Wilkinson	**
;;; ** Compute! Publications (1983)					**
;;; ** $Id: vectors.i,v 1.2 2015/09/05 20:28:48 thor Exp $		**
;;; **									**
;;; ** In this module:	 Os vectors for the BASIC ROM			**
;;; **********************************************************************

;; nothing exported here...

;;; **********************************************************************
;;; ** THOR Os								**
;;; ** A free operating system for the Atari 8 Bit series		**
;;; ** (c) 2003 THOR Software, Thomas Richter				**
;;; ** $Id: fmsosreloc.i,v 1.1 2020/04/12 10:53:14 thor Exp $		**
;;; **									**
;;; ** In this module:	 Implementation of the D: handler		**
;;; **********************************************************************

	;; internal variables used by the FMS Relocation
	
CIOOsReplacementEntry	=	$d800		; enters here when doing CIO work
POBOsReplacementEntry	=	$d803		; enters here for the put-one-byte entry
ResetOsReplacementEntry	=	$d806		; called on reset
FmsOsResident	=		$2300		; where the resident part starts for the code under the Os
	
	
